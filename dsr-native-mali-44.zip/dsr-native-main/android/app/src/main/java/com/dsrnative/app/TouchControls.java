package com.dsrnative.app;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.app.ActivityManager;
import android.os.BatteryManager;
import android.os.PowerManager;
import android.os.SystemClock;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.hardware.input.InputManager;
import android.util.SparseIntArray;
import android.view.HapticFeedbackConstants;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;

/**
 * On-screen gamepad drawn over the game. Left: movement stick, d-pad, L3. Right: face buttons, R1/R2, R3 (lock-on),
 * and a floating camera stick (drag anywhere in the middle-right area). The state goes to native code
 * (TouchControls.nativeTouchPad), which merges it with any physical controller. Hidden when a real gamepad is
 * connected.
 */
public class TouchControls extends View {
    // nn::hid::NpadButton bits (same as hle/input.h).
    private static final long A = 1L << 0, B = 1L << 1, X = 1L << 2, Y = 1L << 3, L3 = 1L << 4, R3 = 1L << 5,
            L = 1L << 6, R = 1L << 7, ZL = 1L << 8, ZR = 1L << 9, PLUS = 1L << 10, MINUS = 1L << 11,
            LEFT = 1L << 12, UP = 1L << 13, RIGHT = 1L << 14, DOWN = 1L << 15;

    private static final int STICK_L = -1, CAMERA = -2;

    // NativeActivity dlopen()s libdsr.so itself, which does not register it with this class loader, so the JNI
    // lookup of nativeTouchPad fails (UnsatisfiedLinkError) until the library is also loaded the normal way.
    private static boolean sNativeOk = false;
    static {
        try {
            System.loadLibrary("dsr");
            sNativeOk = true;
        } catch (Throwable t) {
            android.util.Log.e("DSR/touch", "System.loadLibrary(dsr) failed", t);
        }
    }

    private static final class Ctl {
        final String label;
        final long bit;
        final float px, py, pr;  // position and radius as fractions (x of width, y of height, r of height)
        float cx, cy, r;
        Ctl(String label, long bit, float px, float py, float pr) {
            this.label = label; this.bit = bit; this.px = px; this.py = py; this.pr = pr;
        }
    }

    private final Ctl[] ctls = {
        new Ctl("A", A, 0.86f + 0.0f, 0.68f, 0.065f),   // adjusted in layout(): east
        new Ctl("B", B, 0.86f, 0.68f, 0.065f),          // south
        new Ctl("X", X, 0.86f, 0.68f, 0.065f),          // north
        new Ctl("Y", Y, 0.86f, 0.68f, 0.065f),          // west
        new Ctl("L", L, 0.07f, 0.27f, 0.055f),
        new Ctl("ZL", ZL, 0.07f, 0.10f, 0.055f),
        new Ctl("R", R, 0.93f, 0.27f, 0.055f),
        new Ctl("ZR", ZR, 0.93f, 0.10f, 0.055f),
        new Ctl("-", MINUS, 0.46f, 0.07f, 0.045f),
        new Ctl("+", PLUS, 0.54f, 0.07f, 0.045f),
        new Ctl("^", UP, 0.40f, 0.73f, 0.05f),
        new Ctl("v", DOWN, 0.40f, 0.95f, 0.05f),
        new Ctl("<", LEFT, 0.40f, 0.84f, 0.05f),   // shifted in layout()
        new Ctl(">", RIGHT, 0.40f, 0.84f, 0.05f),  // shifted in layout()
        new Ctl("L3", L3, 0.29f, 0.84f, 0.055f),
        new Ctl("R3", R3, 0.71f, 0.84f, 0.06f),
    };

    private final SparseIntArray owner = new SparseIntArray();  // pointer id -> ctl index, STICK_L or CAMERA
    private float lcx, lcy, lR;                // left stick centre and radius (px)
    private float camX0, camY0, camX1, camY1;  // camera zone
    private float camOx, camOy, camX, camY, camR;
    private float lsx, lsy, rsx, rsy;
    private long pressed;
    private long sentB = -1;
    private int sentLx, sentLy, sentRx, sentRy;
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG),
            text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    // FPS / temperature meter (tap it to hide or show).
    private boolean showMeter = true, showControls = true;
    private String meterText = "FPS --";
    private String meterText2 = "";  // second line: GPU load, CPU load, RAM
    // GPU / CPU / RAM readout, recomputed over windows of about a second
    private long statMs = -1, statGpuUs, statCpuTicks, statFrames;
    private final java.util.HashMap<Integer, Long> threadTicks = new java.util.HashMap<>();
    private long ramMs = -1;
    private String ramText = "";
    private long lastFrames = -1, lastMs;
    private final RectF meterRect = new RectF();
    // MENU button (top centre-right): opens the graphics profile dialog of GameActivity. Always visible.
    private final RectF menuRect = new RectF();
    private Runnable menuListener;
    private final Runnable meterTick = new Runnable() {
        @Override
        public void run() {
            updateMeter();
            postDelayed(this, 500);
        }
    };

    public TouchControls(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setColor(0xB4FFFFFF);
        fill.setStyle(Paint.Style.FILL);
        text.setColor(0xDCFFFFFF);
        text.setTextAlign(Paint.Align.CENTER);
        text.setFakeBoldText(true);
        setFocusable(false);
        setFocusableInTouchMode(false);
        refresh();
    }

    /** Called (on the UI thread) when the MENU button is tapped. */
    public void setMenuListener(Runnable r) {
        menuListener = r;
    }

    /** Hides the overlay while a physical gamepad is connected. */
    public void refresh() {
        boolean pad = false;
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice d = InputDevice.getDevice(id);
            if (d != null && !d.isVirtual() && (d.getSources() & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD)
                pad = true;
        }
        showControls = !pad;  // the window stays up for the meter
        if (pad) releaseAll();
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        lastFrames = -1;
        post(meterTick);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(meterTick);
        super.onDetachedFromWindow();
    }

    private void updateMeter() {
        String fps = "FPS --";
        try {
            final long f = nativeFrames(), now = SystemClock.elapsedRealtime();
            if (lastFrames >= 0 && now > lastMs) fps = String.format("FPS %.0f", (f - lastFrames) * 1000f / (now - lastMs));
            lastFrames = f;
            lastMs = now;
        } catch (UnsatisfiedLinkError ignored) {
        }
        String temp = "";
        try {
            Intent b = getContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int t = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
                if (t != Integer.MIN_VALUE) temp = String.format("  |  bat %.1f\u00B0C", t / 10f);
            }
        } catch (Exception ignored) {
        }
        String thermal = "";
        try {
            PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
            int st = pm.getCurrentThermalStatus();
            if (st > PowerManager.THERMAL_STATUS_NONE) {
                String[] n = {"", "leve", "moderado", "severo", "critico", "emergencia", "desligando"};
                thermal = "  |  termico: " + n[Math.min(st, n.length - 1)];
            }
        } catch (Throwable ignored) {
        }
        meterText = fps + temp + thermal;
        try {
            updateStats();
        } catch (Throwable ignored) {
        }
        invalidate();
    }

    // CPU ticks (utime + stime) of a /proc stat line; the thread name comes back in name[0].
    private static long statTicks(String line, String[] name) {
        final int a = line.indexOf('('), b = line.lastIndexOf(')');
        if (a < 0 || b < a) return -1;
        if (name != null) name[0] = line.substring(a + 1, b);
        final String[] f = line.substring(b + 2).split(" ");
        if (f.length < 13) return -1;
        return Long.parseLong(f[11]) + Long.parseLong(f[12]);
    }

    private static String readFirstLine(String path) {
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader(path))) {
            return r.readLine();
        } catch (Exception e) {
            return null;
        }
    }

    // Second meter line: GPU busy % (and ms per frame), CPU of the whole process (% of all cores) with the busiest
    // thread, RAM of the process and what the device still has free.
    private void updateStats() {
        final long now = SystemClock.elapsedRealtime();
        if (statMs >= 0 && now - statMs < 1000) return;
        final long gpuUs = nativeGpuBusyUs(), frames = nativeFrames();
        long cpuTicks = -1;
        String l = readFirstLine("/proc/self/stat");
        if (l != null) cpuTicks = statTicks(l, null);
        // busiest thread over the window
        long peakTicks = 0;
        String peakName = "";
        final java.util.HashMap<Integer, Long> cur = new java.util.HashMap<>();
        String[] tids = new java.io.File("/proc/self/task").list();
        if (tids != null) {
            final String[] nm = new String[1];
            for (String t : tids) {
                String s = readFirstLine("/proc/self/task/" + t + "/stat");
                if (s == null) continue;
                long ticks = statTicks(s, nm);
                if (ticks < 0) continue;
                int tid = Integer.parseInt(t);
                cur.put(tid, ticks);
                Long prev = threadTicks.get(tid);
                if (prev != null && ticks - prev > peakTicks) {
                    peakTicks = ticks - prev;
                    peakName = nm[0];
                }
            }
        }
        threadTicks.clear();
        threadTicks.putAll(cur);
        if (statMs >= 0 && now > statMs) {
            final float wallMs = now - statMs;
            final float hz = (float) android.system.Os.sysconf(android.system.OsConstants._SC_CLK_TCK);
            final int cores = Math.max(1, Runtime.getRuntime().availableProcessors());
            final float gpuPct = 100f * (gpuUs - statGpuUs) / 1000f / wallMs;
            final long df = frames - statFrames;
            String mhz = "";  // GPU clock where the driver lets the app read it (kHz in /sys/kernel/gpu/gpu_clock)
            String clk = readFirstLine("/sys/kernel/gpu/gpu_clock");
            if (clk != null) {
                try {
                    long khz = Long.parseLong(clk.trim());
                    if (khz > 0) mhz = String.format(" %d MHz", khz / 1000);
                } catch (NumberFormatException ignored) {
                }
            }
            final String gpu = df > 0 ? String.format("GPU %.0f%% (%.0f ms)%s", Math.min(gpuPct, 100f), (gpuUs - statGpuUs) / 1000f / df, mhz)
                    : String.format("GPU %.0f%%%s", Math.min(gpuPct, 100f), mhz);
            String cpu = "CPU --";
            if (cpuTicks >= 0 && statCpuTicks >= 0) {
                final float cpuPct = 100f * ((cpuTicks - statCpuTicks) / hz) * 1000f / wallMs / cores;
                final float peakPct = 100f * (peakTicks / hz) * 1000f / wallMs;
                cpu = String.format("CPU %.0f%% (pico %.0f%% %s)", cpuPct, peakPct,
                        peakName.length() > 9 ? peakName.substring(0, 9) : peakName);
            }
            meterText2 = gpu + "  |  " + cpu + "  |  " + ramText;
        }
        statMs = now;
        statGpuUs = gpuUs;
        statCpuTicks = cpuTicks;
        statFrames = frames;
        // RAM: process resident size, and what Android says is still available (refreshed every ~2 s)
        if (ramMs < 0 || now - ramMs >= 2000) {
            ramMs = now;
            String r = "RAM --";
            try {
                String sm = readFirstLine("/proc/self/statm");
                float rssGb = 0;
                if (sm != null) {
                    final String[] f = sm.split(" ");
                    rssGb = Long.parseLong(f[1]) * (float) android.system.Os.sysconf(android.system.OsConstants._SC_PAGESIZE)
                            / (1024f * 1024f * 1024f);
                }
                ActivityManager am = (ActivityManager) getContext().getSystemService(Context.ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                r = String.format("RAM %.1f GB (livre %.1f)", rssGb, mi.availMem / (1024f * 1024f * 1024f));
            } catch (Throwable ignored) {
            }
            ramText = r;
        }
    }

    private static native long nativeFrames();
    private static native long nativeGpuBusyUs();

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        for (Ctl c : ctls) {
            c.cx = c.px * w;
            c.cy = c.py * h;
            c.r = c.pr * h;
        }
        // Face-button diamond (Nintendo layout: A east, B south, X north, Y west).
        float d = 0.15f * h;
        ctls[0].cx += d;
        ctls[2].cy -= d;
        ctls[1].cy += d;
        ctls[3].cx -= d;
        ctls[12].cx -= 0.075f * h * 1.0f + 0.04f * h;  // d-pad left
        ctls[13].cx += 0.075f * h * 1.0f + 0.04f * h;  // d-pad right
        lR = 0.17f * h;
        lcx = 0.15f * w;
        lcy = 0.66f * h;
        camX0 = 0.35f * w;
        camX1 = 0.72f * w;
        camY0 = 0.14f * h;
        camY1 = 0.70f * h;
        camR = 0.13f * h;
        text.setTextSize(0.05f * h);
        meterRect.set(0.12f * w, 0.01f * h, 0.12f * w + 0.9f * h, 0.01f * h + 0.105f * h);
        menuRect.set(0.62f * w, 0.025f * h, 0.62f * w + 0.19f * h, 0.115f * h);
        stroke.setStrokeWidth(Math.max(2f, 0.006f * h));
    }

    private void releaseAll() {
        owner.clear();
        pressed = 0;
        lsx = lsy = rsx = rsy = 0;
        send();
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        final int a = e.getActionMasked(), idx = e.getActionIndex();
        switch (a) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                down(e.getPointerId(idx), e.getX(idx), e.getY(idx));
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) move(e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                up(e.getPointerId(idx));
                break;
            case MotionEvent.ACTION_CANCEL:
                releaseAll();
                return true;
            default:
                break;
        }
        send();
        invalidate();
        return true;
    }

    private void down(int id, float x, float y) {
        if (meterRect.contains(x, y)) {
            showMeter = !showMeter;
            return;
        }
        if (menuRect.contains(x, y)) {
            if (menuListener != null) post(menuListener);
            return;
        }
        if (!showControls) return;
        int best = -1;
        float bestD = Float.MAX_VALUE;
        for (int i = 0; i < ctls.length; i++) {
            Ctl c = ctls[i];
            float dd = (float) Math.hypot(x - c.cx, y - c.cy);
            if (dd <= c.r * 1.3f && dd < bestD) { best = i; bestD = dd; }
        }
        if (best >= 0) {
            owner.put(id, best);
            pressed |= ctls[best].bit;
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            return;
        }
        if (Math.hypot(x - lcx, y - lcy) <= lR * 1.6f) {
            owner.put(id, STICK_L);
            move(id, x, y);
        } else if (x >= camX0 && x <= camX1 && y >= camY0 && y <= camY1) {
            owner.put(id, CAMERA);
            camOx = camX = x;
            camOy = camY = y;
            rsx = rsy = 0;
        }
    }

    private void move(int id, float x, float y) {
        int o = owner.get(id, Integer.MIN_VALUE);
        if (o == STICK_L) {
            float[] v = norm((x - lcx) / lR, (y - lcy) / lR);
            lsx = v[0];
            lsy = v[1];
        } else if (o == CAMERA) {
            camX = x;
            camY = y;
            float[] v = norm((x - camOx) / camR, (y - camOy) / camR);
            rsx = v[0];
            rsy = v[1];
        }
    }

    private void up(int id) {
        int o = owner.get(id, Integer.MIN_VALUE);
        if (o == Integer.MIN_VALUE) return;
        owner.delete(id);
        if (o == STICK_L) lsx = lsy = 0;
        else if (o == CAMERA) rsx = rsy = 0;
        else recomputePressed();
    }

    private void recomputePressed() {
        long p = 0;
        for (int i = 0; i < owner.size(); i++) {
            int o = owner.valueAt(i);
            if (o >= 0) p |= ctls[o].bit;
        }
        pressed = p;
    }

    /** Clamp to the unit circle with a small dead zone. */
    private static float[] norm(float dx, float dy) {
        float len = (float) Math.hypot(dx, dy);
        if (len > 1f) { dx /= len; dy /= len; len = 1f; }
        if (len < 0.12f) return new float[] {0f, 0f};
        float s = (len - 0.12f) / 0.88f / len;
        return new float[] {dx * s, dy * s};
    }

    private void send() {
        final int lx = Math.round(lsx * 32767f), ly = Math.round(-lsy * 32767f);  // +y = up
        final int rx = Math.round(rsx * 32767f), ry = Math.round(-rsy * 32767f);
        if (pressed == sentB && lx == sentLx && ly == sentLy && rx == sentRx && ry == sentRy) return;
        sentB = pressed; sentLx = lx; sentLy = ly; sentRx = rx; sentRy = ry;
        if (!sNativeOk) return;
        try {
            nativeTouchPad(pressed, lx, ly, rx, ry);
        } catch (UnsatisfiedLinkError t) {
            sNativeOk = false;
            android.util.Log.e("DSR/touch", "nativeTouchPad not found", t);
        }
    }

    private static native void nativeTouchPad(long buttons, int lx, int ly, int rx, int ry);

    @Override
    protected void onDraw(Canvas c) {
        if (showMeter) {
            fill.setColor(0x80000000);
            c.drawRoundRect(meterRect, 8f, 8f, fill);
            text.setTextAlign(Paint.Align.LEFT);
            text.setTextSize(0.04f * getHeight());
            final float pad = 0.012f * getHeight();
            c.drawText(meterText, meterRect.left + pad, meterRect.top + 0.045f * getHeight(), text);
            if (!meterText2.isEmpty()) {  // second line: shrink the text until it fits the box
                float size = 0.032f * getHeight();
                text.setTextSize(size);
                final float avail = meterRect.width() - 2 * pad;
                final float w = text.measureText(meterText2);
                if (w > avail) text.setTextSize(size * avail / w);
                c.drawText(meterText2, meterRect.left + pad, meterRect.top + 0.093f * getHeight(), text);
            }
            text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize(0.05f * getHeight());
        } else {
            fill.setColor(0x30FFFFFF);
            c.drawCircle(meterRect.left + 0.02f * getHeight(), meterRect.centerY(), 0.015f * getHeight(), fill);
        }
        // MENU button (also shown with a gamepad connected).
        fill.setColor(0x60000000);
        c.drawRoundRect(menuRect, 12f, 12f, fill);
        c.drawRoundRect(menuRect, 12f, 12f, stroke);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTextSize(0.04f * getHeight());
        c.drawText("MENU", menuRect.centerX(), menuRect.centerY() + 0.014f * getHeight(), text);
        text.setTextSize(0.05f * getHeight());
        if (!showControls) return;
        // Left stick.
        fill.setColor(0x28FFFFFF);
        c.drawCircle(lcx, lcy, lR, fill);
        c.drawCircle(lcx, lcy, lR, stroke);
        fill.setColor(0x78FFFFFF);
        c.drawCircle(lcx + lsx * lR * 0.7f, lcy + lsy * lR * 0.7f, lR * 0.38f, fill);
        // Camera stick (only while in use).
        if (owner.indexOfValue(CAMERA) >= 0) {
            fill.setColor(0x20FFFFFF);
            c.drawCircle(camOx, camOy, camR, fill);
            c.drawCircle(camOx, camOy, camR, stroke);
            fill.setColor(0x78FFFFFF);
            c.drawCircle(camOx + rsx * camR * 0.8f, camOy + rsy * camR * 0.8f, camR * 0.35f, fill);
        }
        // Buttons.
        for (Ctl b : ctls) {
            boolean on = (pressed & b.bit) != 0;
            fill.setColor(on ? 0x78FFFFFF : 0x28FFFFFF);
            c.drawCircle(b.cx, b.cy, b.r, fill);
            c.drawCircle(b.cx, b.cy, b.r, stroke);
            c.drawText(b.label, b.cx, b.cy + text.getTextSize() * 0.35f, text);
        }
    }
}
