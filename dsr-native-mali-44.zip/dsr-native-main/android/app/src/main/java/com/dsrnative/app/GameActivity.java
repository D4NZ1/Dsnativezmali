package com.dsrnative.app;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NativeActivity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.widget.Toast;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

/**
 * The native activity, full screen: the status and navigation bars are hidden while the game runs (immersive
 * mode: a swipe from the screen edge shows them for a moment), and the game may draw under a display cutout.
 */
public class GameActivity extends NativeActivity {
    // Access to Download/DSRNative (game files, saves, settings): 0 = waiting for the player's answer,
    // 1 = granted, 2 = refused (the game then falls back to the app's private folder). Read by native code.
    private static volatile int sStorage = 0;
    private boolean mAsked = false, mPausedSinceAsk = false;
    private TouchControls mTouch;

    public static int storageAccess() {
        return sStorage;
    }

    /**
     * Clock tests (settings boost_gamemode / boost_sustained), called by native code once settings.txt is read.
     * Results are collected in sBoostReport and copied by native code into the game log as "boost: ..." lines
     * (the logcat mirror is empty on Android 17, so logcat alone is not enough).
     */
    private static final StringBuilder sBoostReport = new StringBuilder();

    private static void rep(String msg) {
        android.util.Log.i("dsrboost", msg);
        synchronized (sBoostReport) {
            sBoostReport.append(msg).append('\n');
        }
    }

    /** Called by native code: returns the boost results gathered so far (and clears them) so they reach the game log. */
    public static String boostReport() {
        synchronized (sBoostReport) {
            String r = sBoostReport.toString();
            sBoostReport.setLength(0);
            return r;
        }
    }

    public static void applyBoost(final android.app.Activity a, final int gameMode, final int sustained) {
        rep("applyBoost called: gameMode=" + gameMode + " sustained=" + sustained + " sdk=" + Build.VERSION.SDK_INT);
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    android.content.pm.ApplicationInfo ai = a.getApplicationInfo();
                    rep("app isGame flag: " + ((ai.flags & android.content.pm.ApplicationInfo.FLAG_IS_GAME) != 0)
                            + ", category " + ai.category + " (0 = game), package " + a.getPackageName());
                    android.os.PowerManager pm0 = (android.os.PowerManager) a.getSystemService(Context.POWER_SERVICE);
                    if (pm0 != null) rep("thermal status " + pm0.getCurrentThermalStatus() + ", power save " + pm0.isPowerSaveMode());
                    if (Build.VERSION.SDK_INT >= 34) {
                        android.app.GameManager gm0 = a.getSystemService(android.app.GameManager.class);
                        if (gm0 != null) rep("GameManager game mode (read only): " + gm0.getGameMode());
                    }
                } catch (Throwable t) {
                    rep("app info failed: " + t);
                }
                if (gameMode != 0) {
                    try {
                        if (Build.VERSION.SDK_INT >= 34) {
                            android.app.GameManager gm = a.getSystemService(android.app.GameManager.class);
                            if (gm != null) {
                                rep("GameManager: current game mode " + gm.getGameMode() + " (1 standard, 2 performance, 3 battery, 0 unsupported)");
                                gm.setGameState(new android.app.GameState(false, android.app.GameState.MODE_GAMEPLAY_UNINTERRUPTIBLE));
                                rep("GameManager: setGameState(gameplay, uninterrupted) returned without error");
                            } else {
                                rep("GameManager: not available");
                            }
                        } else {
                            rep("GameManager game state needs Android 14 (API 34)");
                        }
                    } catch (Throwable t) {
                        rep("GameManager failed: " + t);
                    }
                }
                if (sustained != 0) {
                    try {
                        android.os.PowerManager pm = (android.os.PowerManager) a.getSystemService(Context.POWER_SERVICE);
                        boolean ok = pm != null && pm.isSustainedPerformanceModeSupported();
                        rep("sustained performance mode supported: " + ok);
                        if (ok) a.getWindow().setSustainedPerformanceMode(true);
                    } catch (Throwable t) {
                        rep("sustained performance failed: " + t);
                    }
                }
            }
        });
    }

    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStorageAccess() {
        if (hasStorageAccess()) {
            sStorage = 1;
            return;
        }
        mAsked = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Exception e2) {
                    sStorage = 2;
                }
            }
        } else {
            requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        sStorage = hasStorageAccess() ? 1 : 2;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mAsked) mPausedSinceAsk = true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestStorageAccess();
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
        lockRefreshRate();
        hideSystemBars();
    }

    /**
     * Pins the panel to a fixed 60 Hz mode. On panels with an adaptive rate (60/90 Hz LCDs) the system switches
     * the refresh rate while the game runs at 30 fps, which makes dark scenes (loading, menus) flicker.
     */
    private void lockRefreshRate() {
        try {
            android.view.Display d = getWindowManager().getDefaultDisplay();
            android.view.Display.Mode cur = d.getMode();
            int best = cur.getModeId();
            float bestDiff = Float.MAX_VALUE;
            for (android.view.Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() != cur.getPhysicalWidth() || m.getPhysicalHeight() != cur.getPhysicalHeight())
                    continue;
                float diff = Math.abs(m.getRefreshRate() - 60f);
                if (diff < bestDiff) {
                    bestDiff = diff;
                    best = m.getModeId();
                }
            }
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.preferredDisplayModeId = best;
            lp.preferredRefreshRate = 60f;
            getWindow().setAttributes(lp);
        } catch (Exception ignored) {
        }
    }

    // The game owns this window's surface (NativeActivity), so views inside it are never drawn: the on-screen
    // controls live in their own panel window on top of it.
    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (mTouch != null) return;
        try {
            mTouch = new TouchControls(this);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_PANEL,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    android.graphics.PixelFormat.TRANSLUCENT);
            lp.token = getWindow().getDecorView().getWindowToken();
            lp.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindowManager().addView(mTouch, lp);
            mTouch.setMenuListener(new Runnable() {
                @Override
                public void run() {
                    showMenu();
                }
            });
        } catch (Exception e) {
            mTouch = null;
        }
    }


    // ---------------------------------------------------------------------------------------------------
    // MENU button: graphics profile. render_scale sets the size of the game's render targets at start-up, so a
    // change is written to settings.txt and applied the next time the game starts (the game closes itself).
    // ---------------------------------------------------------------------------------------------------
    private static final String[] PROFILE_LABELS = {
        "Econ\u00f4mico 0.55 (menos calor)",
        "Equilibrado 0.65 (30 fps firmes)",
        "Alto 0.75 (pode cair no mar e chefes)",
    };
    private static final float[] PROFILE_SCALE = {0.55f, 0.65f, 0.75f};

    private java.io.File settingsFile() {
        java.io.File shared = new java.io.File(Environment.getExternalStorageDirectory(), "Download/DSRNative/settings.txt");
        if (sStorage == 1 && shared.exists()) return shared;
        java.io.File app = getExternalFilesDir(null);
        return app == null ? shared : new java.io.File(app, "settings.txt");
    }

    private static String readKey(java.io.File f, String key) {
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(
                new java.io.FileInputStream(f), "UTF-8"))) {
            String line, val = null;
            while ((line = r.readLine()) != null) {
                String t = line.trim();
                if (t.startsWith("#")) continue;
                int eq = t.indexOf('=');
                if (eq > 0 && t.substring(0, eq).trim().equals(key)) val = t.substring(eq + 1).trim();
            }
            return val;
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean writeKey(java.io.File f, String key, String val) {
        try {
            java.util.ArrayList<String> lines = new java.util.ArrayList<>();
            if (f.exists()) {
                try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(
                        new java.io.FileInputStream(f), "UTF-8"))) {
                    String line;
                    while ((line = r.readLine()) != null) lines.add(line);
                }
            }
            boolean done = false;
            for (int i = 0; i < lines.size(); i++) {
                String t = lines.get(i).trim();
                int eq = t.indexOf('=');
                if (!t.startsWith("#") && eq > 0 && t.substring(0, eq).trim().equals(key)) {
                    lines.set(i, key + " = " + val);
                    done = true;
                }
            }
            if (!done) lines.add(key + " = " + val);
            try (java.io.OutputStreamWriter w = new java.io.OutputStreamWriter(new java.io.FileOutputStream(f), "UTF-8")) {
                for (String l : lines) w.write(l + "\n");
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String thermalLabel() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    String[] n = {"normal", "leve", "moderado", "severo", "cr\u00edtico", "emerg\u00eancia", "desligando"};
                    int t = pm.getCurrentThermalStatus();
                    return n[Math.max(0, Math.min(n.length - 1, t))];
                }
            }
        } catch (Throwable ignored) {
        }
        return "?";
    }

    private void showMenu() {
        final java.io.File f = settingsFile();
        float cur = 0.65f;
        try {
            String v = readKey(f, "render_scale");
            if (v != null) cur = Float.parseFloat(v);
        } catch (Exception ignored) {
        }
        int sel = 0;
        for (int i = 1; i < PROFILE_SCALE.length; i++)
            if (Math.abs(PROFILE_SCALE[i] - cur) < Math.abs(PROFILE_SCALE[sel] - cur)) sel = i;
        final int current = sel;
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Qualidade gr\u00e1fica (calor: " + thermalLabel() + ")")
                .setSingleChoiceItems(PROFILE_LABELS, sel, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        d.dismiss();
                        if (which == current) return;
                        if (!writeKey(f, "render_scale", String.format(java.util.Locale.US, "%.2f", PROFILE_SCALE[which]))) {
                            Toast.makeText(GameActivity.this, "N\u00e3o consegui salvar o settings.txt", Toast.LENGTH_LONG).show();
                            return;
                        }
                        Toast.makeText(GameActivity.this, "Aplicado. O jogo vai fechar: abra de novo.", Toast.LENGTH_LONG).show();
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                finishAndRemoveTask();
                                android.os.Process.killProcess(android.os.Process.myPid());
                            }
                        }, 1500);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        if (mTouch != null) {
            try {
                getWindowManager().removeView(mTouch);
            } catch (Exception ignored) {
            }
            mTouch = null;
        }
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Back from the "All files access" settings screen: the answer is final for this launch.
        if (mAsked && mPausedSinceAsk && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            sStorage = hasStorageAccess() ? 1 : 2;
        hideSystemBars();
        if (mTouch != null) mTouch.refresh();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }
}
