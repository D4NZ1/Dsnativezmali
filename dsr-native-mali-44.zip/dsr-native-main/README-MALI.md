# dsr-native no Mali-G57: o que descobrimos

Notas de otimização do port nativo para Android (Galaxy A07, Helio G99, Mali-G57 MC2, Android 17).
Meta: **30 fps estáveis** com boa qualidade e, depois, **pouco calor e pouco consumo de bateria**.

> Tudo abaixo vem dos logs `dsr_*.txt` e capturas de frame (L3+R3) enviados nos testes mali-23 a mali-26.
> O `mali-30` (formatos dos alvos de cor) foi testado: ver 3.4c. O mali-38 (quem termina os passes) está em 3.4h. O mali-42c (bisseção dos shaders de 640x360:37) está em 3.4p. Nenhuma versão foi compilada fora do GitHub Actions do projeto.

---

## 1. Resumo em 8 linhas

1. Áreas fechadas já fecham 30 fps. O problema são cenas abertas pesadas (20–26 fps).
2. A GPU fica ~100% ocupada nessas cenas e o jogo espera por ela.
3. Na cena pesada, **um único passe** (o mundo, com 4 alvos de cor) custa ~28 ms de ~60 ms numa captura. O pós-processamento custa ~14 ms em ~30 passes.
4. A resolução quase não muda o resultado nas cenas leves (0,65 → 0,60 não reduziu a GPU), mas a cena pesada responde a `render_scale` (0,65: 36–41 ms; 0,75: 38–48 ms por lista).
5. O clock do aparelho é um fator grande: **parado 20–22 fps, com um dedo na tela 26 estáveis** (efeito de *touch boost*). A economia de energia do Galaxy estava ligada nos testes até o mali-34, mas o teste de confirmação do mali-35 (economia **desligada**, `power save false` no log) deu ~41,4 ms por lista, igual ao de antes: **a economia de energia não explica o gargalo** (ver 3.5d).
6. Resolução dinâmica funciona, mas dá glitch de canto e não trouxe ganho: fica **desligada**.
7. Cortar o write-back de alvos pequenos não ajudou: fica em **0**.
8. Pistas abertas (mali-42c: bisseção dos 8 shaders de 640x360:37 feita em 3.4p: `03cba9f2` dá a textura do mar, `22a6f6c6` o brilho, `e4eb576b`/`9a14cd3d`/`7a6ad674` são cortáveis; o `0fbd542c` é cortável (rodada B: imagem normal, frame 34 ms); falta separar `100a2de7` de `fcb25d17`, ver 6.1b); a fusão dos ~17 passes pequenos do pós (3.4h); o que faz a CPU little (cpu0/cpu4) ficar em 500 MHz sem dedo, `frame_rate_hint`/`boost_sustained` e o custo do passe principal de 4 alvos. `boost_gamemode` e ADPF foram aceitos pelo sistema e **não** mudaram o clock.

---

## 2. Ponto de partida (README anterior)

- 30 fps em área fechada, 22–26 em área aberta.
- GPU ocupada ~9,9 s a cada 10 s, ou seja, gargalo de GPU.
- Por lista: pós-processamento ~18–21 ms, cena principal ~8–11 ms, sombra ~2–8 ms.
- As shaders de fragmento `527cbc3c` e `a4224b32` custam ~5 ms cada; cortá-las dá −4 a −5 ms por lista.
- Configuração de referência com boa imagem: `skip_shaders = 527cbc3c,a4224b32`, `shadow_size = 1024`, `render_scale = 0.75`.

---

## 3. Experimentos e resultados

### 3.1 Resolução dinâmica (`dyn_res`, mali-24)

**Como funciona:** os alvos 1280x720 são alocados em `render_scale` (teto) e só o canto `[0,live]` é desenhado. O controlador roda 1x/s, compara os ms de GPU por frame com `dyn_target_ms` (31) e move a escala em passos de 1/40 entre `dyn_min` e `render_scale`. Só troca no `Present`.

**Resultado:**
- Mecanicamente funcionou: 0,65 → 0,625 → 0,60 em 2 s.
- Não ajudou: GPU 33–36 ms por frame em 0,65 e ~35 ms em 0,60.
- Deixou **glitch**: a cena 3D aparece em ~73% da imagem, com moldura cinza e restos de frames antigos. Algum passe lê ou escreve o canto escalado sem o fator certo. Causa **não confirmada**.
- Conclusão: nas cenas testadas, resolução não era o gargalo. `dyn_res = 0` por padrão.

### 3.2 Write-back dos alvos pequenos (`skip_writeback`, mali-25)

O jogo lê de volta, por lista, alvos de até 64x64 (cerca de 5 por lista) para a exposição automática.
- `0` = copia todos (padrão e seguro). `1` = só R32F (formato NVN 10). `2` = nenhum (imagem mais escura).
- Com `1`, os write-backs caíram só de ~1.310 para ~1.250 por 10 s (quase todos já eram R32F) e a GPU ficou em 38–41 ms por lista: sem ganho. Manter em `0`.

### 3.3 Custo fixo por passe

- ~10.000 passes e ~24.000 barreiras de imagem a cada 10 s: cerca de **38–40 passes** e **~95 barreiras por frame**.
- ~680 draws por frame na cena pesada.
- Várias quebras de passe só para ler alvos pequenos (320x180, 640x360, 160x90) numa GPU de tiles.

### 3.4 Capturas da cena pesada (fogueira, mali-25/26)

| Parte | Captura 2 | Captura 3 |
|---|---|---|
| Total (inflado pela captura) | 64,3 ms | 58,9 ms |
| Opaco (cor, tela) | 35,8 ms (7 passes, 240 draws) | 33,3 ms (6 passes, 142 draws) |
| Passes pequenos (pós) | 14,2 ms (32 passes) | 14,5 ms (30 passes) |
| Blended | 3,6 ms | 2,2 ms |
| Cópias/clears | 10,3 ms (19 passes) | 8,4 ms (17 passes) |
| Sombra (`shadow_size 512`) | 0,5 ms | 0,6 ms |

- O passe do mundo (4 alvos de cor, até 234 draws, lendo a sombra 2048) leva **~28 ms** nas duas capturas.
- **Hipótese não verificada:** na Mali, MRT acima de ~128 bits por pixel reduz o tamanho do tile e piora muito o desempenho. Faltam os formatos dos 4 alvos para confirmar.
- Estatística do período: o jogo esperou o render 1.550–3.100 ms a cada 10 s e a GPU ficou ~100% ocupada.

### 3.4b `diag_world` e teste de escala (mali-29)

- Cena muito pesada (56 ms por lista na base). Descartar, um por vez, os 6 fragment shaders mais usados do mundo (25–55 draws cada) rendeu 0 a 2 ms cada. Um deles (`9bc1c5c1`) deu −4,1 ms numa rodada e −0,6 na outra: o ruído das medições é de ~1–3 ms. **Nenhum shader isolado domina; o custo está espalhado por centenas de draws.**
- A/B de escala no mesmo ponto: `render_scale 0.65` ≈ 53 ms por lista; `0.50` ≈ 42 ms. **Cuidado:** em 0.50 o tamanho escalado (640x360) coincide com alvos nativos do jogo, a imagem encolhe para um canto (320x180) e o número subestima o custo real. Evite 0.50 (e 0.25); use 0.55 ou mais.
- Ordem de grandeza: reduzir ~40% dos pixels tirou só ~20% do tempo, então boa parte do custo é fixa (draws e passes), e só resolução não fecha 33 ms nessa cena.

### 3.4c Formatos dos alvos de cor (mali-30)

- Combinações logadas: RGBA8 1280x720 (32 bpp, o resto sem uso), R32F 640x360 (32), RG16F 320x180 (32), 4x R16F 320x180 (64).
- **Máximo 64 bits por pixel, abaixo dos ~128.** Nenhuma combinação nova apareceu em ~55 s de cena pesada. Com `trim_targets` ligado, os alvos extras do mundo (máscara 0) saem do passe. **Hipótese do MRT refutada**: a Mali não encolhe tiles por causa disso.
- Cena pesada deste teste (`render_scale 0.65`, `shadow 512`): 1.173 draws, ~45 passes e ~105 barreiras por frame; GPU 49–55 ms por lista (~18–19 fps), ~98% ocupada. Mais pesada que a do 3.4 (~680 draws).
- Quebras de passe para ler texturas, por frame: 320x180 ~8, 640x360 ~6, 160x90 ~4, 1280x720 ~4 (~25 quebras em ~45 passes).
- A captura L3+R3 pegou uma tela leve (6 draws, 3,6 ms); não serve para a cena pesada.
- ADPF aceito (`rc 0`), sem efeito.

### 3.4d A/B `diag_tiny_scissor` (mali-30, mesma cena: 631 draws, 61 trocas de alvo por frame)

| | Sem diagnóstico | Scissor 1x1 nos opacos |
|---|---|---|
| GPU por lista (regime) | 39–42 ms (~41,5) | 37–39 ms (~38,5) |
| Captura, total (inflado) | 63,1 ms | 57,0 ms |
| Passe 10 (156 draws, alpha test) | 24,5 ms | 9,5 ms |
| Opaco (7 passes) | 31,2 ms | 16,4 ms |
| Blended (3 passes) | 4,2 ms | 8,5 ms |
| Pós (32 passes) | 16,9 ms | 19,6 ms |
| Cópias/clears (19 passes) | 10,2 ms | 11,6 ms |
| Sombra | 0,6 ms | 0,8 ms |

- Tirar todo o fragmento opaco derruba o passe 10 em ~15 ms, mas o tempo ao vivo cai só ~3 ms (~7%) e o total da captura ~6 ms: os outros passes "engordam" (+9 ms) porque antes corriam em paralelo com o fragmento do passe 10.
- Leitura (hipótese): a GPU tem duas filas quase equilibradas, fragmento (~41 ms) e vértice/tiler/passes (~38 ms). Cortar só uma fila rende pouco (~3 ms). Para 33 ms é preciso cortar as duas em ~20%.
- O passe 10 sem fragmento ainda custa 9,5 ms por 156 draws (~60 µs por draw; a sombra faz 66 draws em 0,8 ms): custo de vértice/tiler.
- Passes pequenos do pós (1 draw): 0,2–0,9 ms cada, ~17–20 ms no total; 19 passes de cópia/clear com ~10 ms.
- **Teste `render_scale 0.55` (mesma cena, sem diagnóstico):** GPU 40,5–42,4 ms por lista, igual aos ~41,5 ms de 0,65. Previsão da hipótese das duas filas era ~38 ms: **refutada**. Na captura, o passe 10 caiu de 24,5 para 20,3 ms, mas o total foi 65,1 ms (63,1 em 0,65): o tempo reaparece em outros passes.
- Novo palpite: o clock da GPU se ajusta à carga (DVFS). Menos pixels, clock menor, mesmo tempo por frame. Combina com o touch boost (3.5): 20–22 fps parado e 26 com dedo. Todos os A/B (resolução, scissor, ADPF) ficam pequenos por isso. Para testar: repetir 0,65 vs 0,55 com o dedo apoiado na tela o tempo todo (clock alto fixo); se a resolução passar a render, o DVFS escondia o ganho.

- Primeiros ~20 s da cena: 45–46 ms por lista; depois estabiliza em ~41 ms.

### 3.4e Pré-passe de profundidade (`skip_depth_prepass`, mali-35, mesma cena, `render_scale 0.55`, sem dedo)

| | `skip_depth_prepass 1` (pula o pré-passe) | `skip_depth_prepass 0` (liga o pré-passe) |
|---|---|---|
| ms por lista em regime | 41–42 | 41,6–41,8 |
| Captura 4, total | 41,3 ms | 40,7 ms |
| Passe 10 (mundo) | 13,2 ms | 9,5 ms |
| Draws sem pixel no passe 10 | 93 de 156 | 112 de 156 (early-Z funcionou) |

- Sem o pré-passe, o passe 10 fica ~4 ms mais lento. Com ele, o tempo volta num passe novo (o pré-passe, 155 draws) e nos vizinhos: **ligar o pré-passe não rendeu nada. Decisão: voltar a `skip_depth_prepass 1`.**
- Confirma o padrão dos testes anteriores (3.4d): cortar fragmento num passe isolado (scissor 1x1, 0,55 de escala, pré-passe) quase não muda o tempo do frame. O gargalo não é o shading do passe 10, e sim algo que serializa os passes.
- Próxima alavanca (mali-36): `barrier_dst_fragment`, ver 6.0b.

### 3.4f Cena mais pesada, baseline para `barrier_dst_fragment` (mali-35, `dsr_20261112_104757`)

Config: `render_scale 0.55`, `shadow_size 512`, `skip_depth_prepass 1`, `barrier_dst_fragment off`, `power save false`, `adpf_graphics 1`, sem dedo.

- Em regime (28º a 70º s): **48–51,4 ms por lista (~19–20 fps)**, GPU ~100% ocupada, jogo esperou a GPU 1,7–2,3 s a cada 10 s, 51–65 hitches (>67 ms) a cada 10 s. Os primeiros 20 s ficaram abaixo (9–22 ms por lista: transição de cena).
- ~8.800 passes e ~21.000 barreiras a cada 10 s: cerca de **45 passes e 108 barreiras por lista**.
- Captura 2 (total 74,5 ms, inflado): passe 10 (mundo) **27,6 ms com 322 draws** (o dobro dos 156 de 3.4d), ~37% do total; o resto (~47 ms) espalhado por ~60 passes de 0,2 a 2 ms (p22: 3,35 ms); cópias/clears 13,5 ms (19 passes); sombra 0,6 ms (91 draws).
- Uso: base para o A/B de `barrier_dst_fragment` (6.0b). Mesma cena e posição, `barrier_dst_fragment 1`, sem dedo por 60 s, e comparar com ~50 ms por lista. Se `adpf_graphics` mudar entre rodadas, anote: o baseline de 3.5d foi sem ele.

### 3.4g `barrier_dst_fragment` (mali-36, `dsr_20261112_105226` e `dsr_20261112_105650`)

Cena de ~10,5 mil passes e ~25 mil barreiras por 10 s, `render_scale 0.55`, `skip_depth_prepass 1`, sem dedo.

| | `barrier_dst_fragment` | ms por lista em regime | Média |
|---|---|---|---|
| Baseline (3.5d) | 0 | 41,0–42,4 | ~41,4 |
| Rodada 105226 | 1 | 39,2–41,7 | ~40,5 |
| Rodada 105650 | 1 | 37,5–41,0 | ~39,6 |

- Ganho de ~1–2 ms (3–4%), repetido em duas rodadas, mas no limite do ruído (1–3 ms). Hitches (16–37 a cada 10 s) e espera da GPU (420–1.030 ms a cada 10 s) iguais aos de antes.
- Flicker: apareceu **uma vez** na primeira rodada (sem horário; não repetiu) e **não apareceu** na segunda. Provavelmente não é da barreira, mas não está provado.
- Ainda não foi feito o A/B na cena de ~50 ms (3.4f), onde o efeito deveria ser maior.
- Conclusão provisória: chave segura nos testes e com ganho pequeno; fica em 1 no `settings.txt` de teste, padrão do código em 0. Não fecha os 33 ms sozinha: o custo fixo dos ~45 passes por lista continua o alvo.

### 3.4h Quem termina os passes (mali-38, `dsr_20261112_153239`, `render_scale 0.55`, `barrier_dst_fragment 1`, sem dedo)

Cena pesada: 878 draws, 44 passes e 100 barreiras por lista; **40,3–41,1 ms por lista** (~24 fps), GPU ~98% ocupada, 33–39 hitches por 10 s, GPU a 990 MHz, cpu0/cpu4 a 500 MHz. ~240 listas por 10 s.

| Fim de passe (linha em `vk_backend.cpp`) | Por lista | Causa |
|---|---|---|
| 4152 | **32** | textura lida sem estar em `SHADER_READ_ONLY` (alvo de cor virando textura) |
| 3572 | 7 | troca do conjunto de alvos |
| 3808 | 2 | snapshot do depth 1280x720 (f54) para partículas/fog |
| 506 | 2 | `CopyTexture`: 1x 1280x720 f37 e 1x 16x16 f10 (exposição) |
| 3349 | 1 | write-back da exposição |

- Quebras por textura lida, por lista: 320x180 f37 ~8, 640x360 f37 ~5, 160x90 f37 ~4, 1280x720 f37 ~4, 16x16 f10 ~2, depth 640x360 / 320x180 e sombra 2048x2048 ~1 cada. Só as três resoluções pequenas somam ~17 passes (cadeia de downsample/blur/bloom do pós).
- Cópias: 4 por lista (2 depth f54, 1 cor f37 1280x720, 1 de 16x16). Clears separados: **1** por lista (640x360 f37, linha 4153). Os outros clears já viram `loadOp` ou ficam pendentes (3.346 em 10 s).
- **Alavanca 1 (clears/cópias) encerrada:** copy/clear são 6 dos 44 passes (13%); os "19 passes de cópia/clear" da captura 3.4 não são clears. Ganho realista <= 1-2 ms, dentro do ruído. Sem mudança de comportamento.
- `barrier_dst_fragment 1`: 40,3–41,1 ms, igual ao baseline (~41,4): o ganho de 1–2 ms de 3.4g não se repetiu. Fica como está (padrão do código 0).
- A captura L3+R3 desta rodada foi em tela leve (cópia 1920x1080 por volta de 15:33:00); não serve para a cena pesada.
- Diagnóstico novo no mali-38 (sem mudar comportamento): as linhas `copies/blits` agora trazem o endereço (32 bits baixos) de origem e destino, e cada snapshot de depth registra quantos clears/escritas de depth ocorreram desde o anterior. Serve para saber se os 2 snapshots por lista são o mesmo depth escrito entre as duas leituras (necessários) ou dois buffers.
- Código não compilado localmente (sem dependências do Android); depende do GitHub Actions.

### 3.4i Snapshots de depth e cópias, com endereços (mali-38 build a6bee81, `dsr_20261112_160950`, mesma config de 3.4h)

Cena pesada em regime: 41,0–42,0 ms por lista, ~10,6 mil passes por 10 s (~44 por lista), igual a 3.4h.

- Por lista (~237): **3 snapshots de depth** (linha 3816), não 2: depth principal `@70fbd000` 1280x720 **2x** (496 e 256 escritas/clears de depth desde o snapshot anterior) e depth `@88110000` 640x360 **1x** (752 escritas desde o anterior). Mais 1 cópia de cor 1280x720 f37 (`@70bfc000 -> @80e92000`) e 2 cópias de 16x16 f10 (exposição, 2 pares de endereços).
- **Causa provável do 3º snapshot:** `depth_gen_` era **global**: qualquer draw com escrita de depth ou `ClearDepth` em qualquer buffer invalidava o snapshot de todos. O 640x360 (752 = soma de 496 + 256, ou seja, todas as escritas do frame) era recopiado a cada frame mesmo sem ser escrito pelo jogo.
- **Mudança do mali-39:** contador por imagem (`Image::depth_write_gen`); o snapshot só é refeito se *aquela* imagem de depth foi escrita ou limpa desde a cópia. Esperado: some o snapshot 640x360 (-1 passe por lista, ~-2%); o do 1280x720 (2 por lista) continua se o jogo realmente escreve o depth entre as duas leituras. Comparar: `render passes ended by line 3816` por 10 s cai de ~710 para ~475 e passes por 10 s de ~10,6 mil para ~10,4 mil. O ganho em ms deve ficar no ruído; é correção de custo desnecessário, não resolve os 33 ms.
- Risco: se aparecer fog/partícula errada ou piscando, o contador por imagem está pulando um snapshot necessário (algum caminho que escreve depth sem passar por `ClearDepth` ou draw com `depth_write`): voltar ao contador global.
- A captura L3+R3 (16:10:13) pegou de novo uma tela leve (3,3 ms, 2 passes pós, 166 draws); não serve para a cena pesada. Para capturar a pesada, apertar L3+R3 só depois de ~40 s na cena (≥ 10 mil passes por 10 s no log).
- Não compilado localmente; depende do GitHub Actions.

### 3.4j Mali-39 (build 63861e8, `dsr_20261112_161829`): snapshot por imagem não mudou nada; primeira captura boa da cena pesada

Mesma config. Em regime: **39,2–40,8 ms por lista** (média ~39,7; 25–35 hitches por 10 s), ~10,3–10,9 mil passes por 10 s. É 1–2 ms abaixo de 3.4i, dentro do ruído (1–3 ms): **sem ganho comprovado**.

- **O snapshot por imagem (3.4i) não removeu nenhum snapshot:** continuam 3 por lista (depth principal 1280x720 2x, depth 640x360 1x) e `line 3821` segue em ~710 por 10 s. Logo a hipótese "contador global recopiava um depth que ninguém escreveu" está **refutada**: o depth 640x360 é escrito pelo jogo a cada frame antes de ser lido, o snapshot é necessário. A mudança fica (é correta e inofensiva), mas não rende; sem fog/partícula errada nesta rodada.
- **Captura 2 (16:19:47, cena pesada, total 67,8 ms inflado):** passes pequenos (pós) **40,1 ms em 43 passes (785 draws)**; "outros" (cópias/clears) **26,9 ms em 19 passes com 3 draws**; sombra 0,8 ms (91 draws).
  - Maiores passes: p10 (mundo, 322 draws) **16,5 ms**; p3 (sem draws) **10,4 ms**; p12 (sem draws) **4,6 ms**; p26 (250 draws) 2,6 ms; p1 2,0 ms; p11 2,0; p19 2,0; p20 2,1.
  - Cerca de **35 passes de 1 draw** (fullscreen: 1280x720, 640x360, 320x180, 160x90, 64x64, 16x16, 4x4), de **0,1 a 1,6 ms cada**, ~20 ms no total: a cadeia de bloom/blur/exposição/tonemap.
  - **Os passes sem draw p3 (10,4 ms) e p12 (4,6 ms) somam ~15 ms (22% da captura) e não sabemos o que são.** O que eu dizia em 3.4h (copy/clear = 13% dos passes) conta passes, não tempo: se p3/p12 forem cópia/clear de alvo grande, a alavanca 1 volta a valer. O tempo de um passe sem draw pode também ser espera do passe anterior (o timestamp é BOTTOM_OF_PIPE), então a atribuição não é certa.
- Diagnóstico do mali-39b: na captura, cada passe sem draw loga `capture pass N (no draws): [copy ...] [clear ...]` com tamanhos, formatos e endereços. Próxima rodada: mesma cena, L3+R3 depois de ~40 s, e comparar p3 e p12 com as linhas de 3.4h.
- Não compilado localmente; depende do GitHub Actions.

### 3.4k Mali-41 (build 250c389, `dsr_20261113_062909` e `dsr_20261113_063518`): VS x FS e cena pesada com captura

Config: `render_scale 0.55`, `shadow_size 512`, `skip_depth_prepass 1`, `barrier_dst_fragment 0`, `adpf off`, `power save true`, `skip_shaders 527cbc3c,a4224b32,c6fe85bf`, sem dedo.

- **Nenhuma textura é lida pelo vertex shader.** 0 linhas `stage VS` nas duas sessões (abertura, regime leve e cena pesada); todas são `stage FS`. Estreitar a barreira para fragmento (`barrier_dst_fragment`) não tem risco por VS nesta cena, mas o ganho medido (3.4g/3.4h) segue pequeno e instável: não é a alavanca.
- **Quebras por lista (regime, ~294 listas por 10 s):** 320x180 f37 ~7,4; 640x360 f37 ~4,2; 160x90 f37 ~4,1; 1280x720 f37 ~4,1; 640x360 f37 vindo de layout 5 ~2; 16x16 f10 ~2; depth f54 640x360 e 320x180 ~1 cada (~26 por lista). A linha `640x360 f37 from layout 5` já estava em `SHADER_READ_ONLY` e ainda quebra o passe; deve ser o clear separado `640x360 f37 line 4172 to-layout 5` (~400 a 600 por 10 s).
- **A cena muda no meio da sessão (cuidado ao comparar):** na 062909, 06:30:11 a 06:30:51 deu 27–29 ms por lista, frame médio 33,4 ms (30 fps), 0 hitches, ~295 listas por 10 s e só ~270 draws por lista (cena leve); de 06:31:21 em diante 38–49 ms por lista, 35–56 hitches por 10 s, ~200 listas por 10 s e ~1.000 a 1.333 draws por lista. Os passes por 10 s ficam parecidos (10–12 mil), então "passes por 10 s" sozinho não distingue cena leve de pesada: use **draws por lista** (`frames presented | per frame`).
- **Cena pesada estável (063518, 06:35:59 a 06:37:29):** 47–48 ms por lista (~21 fps), GPU ~99% ocupada, 52–61 hitches por 10 s, **880 draws, 52 passes e 100 barreiras por lista**, ~10,8 mil passes e ~21,5 mil barreiras por 10 s. GPU em 976–1003 MHz; cpu0 oscila entre 500 e 2000 MHz sem mudar o tempo e cpu4 fica em 2200 MHz: nesta cena o clock da CPU não explica nada.
- **Captura 2 (06:36:25, cena pesada, total 103,3 ms inflado):** p10 (mundo, 174 draws, 704x396) **20,4 ms**; p25 (320x180, 170 draws) 2,5 ms; p229 (640x360, 190 draws) 0,39 ms; sombra 0,4 ms (60 draws); passes de 1 draw em 16x16 a 704x396 de 0,5 a 0,9 ms cada (~20 ms no total); cópias/clears 17,5 ms (35 passes, 6 draws).
- **Correção importante sobre capturas:** a captura quebra os passes em grupos de até 4 draws, então a numeração vai até p250 e "pós = 85,4 ms em 215 passes" é artefato. **Não compare a contagem de passes da captura com os 52 passes ao vivo.** Vale a duração dos passes grandes e a forma geral. Isso também enfraquece a leitura dos "p3 10,4 ms e p12 4,6 ms sem draws" do 3.4j: ali o tempo pode ser de espera do passe anterior e a divisão em passes é da captura.
- As capturas L3+R3 feitas na abertura (06:29:29 e 06:35:38) pegaram a tela de carregamento (3,4 ms); só a captura 2 da 063518 é da cena pesada (167 MB, não enviada, o log já traz o resumo).
- Resumo: o custo ao vivo (~48 ms) é bem maior que a soma dos passes grandes da captura; está espalhado pelos ~50 passes e pelo custo fixo de cada quebra. A fusão/corte do pós continua sendo a alavanca.

### 3.4l `diag_cycle` com 12 shaders (mali-42, build 2b42335, `dsr_20261113_065911`): nenhuma shader isolada rende

Cena pesada estável (47 ms por lista, 1.224 draws por frame, 0 linhas `stage VS`), mesma config do 3.4k. Base 47,12 ms e base de novo 46,43 (média 46,78; o ruído entre as duas é 0,7 ms). Cada fase tira **uma** shader de fragmento (as 3 já em `skip_shaders` não entram):

| Shader | Alvo | Draws por lista | ms por lista | vs base |
|---|---|---|---|---|
| `0fbd542c` | 640x360 | 168,4 | 45,31 | −1,46 |
| `03cba9f2` | 640x360 | 4,0 | 45,40 | −1,37 |
| `e4eb576b` | 640x360 | 19,8 | 45,71 | −1,07 |
| `48b0815f` | 320x180 | 16,8 | 46,11 | −0,66 |
| `ef27c6d1` | 320x180 | 4,0 | 46,36 | −0,42 |
| `c62deccb` | 320x180 | 16,8 | 46,46 | −0,31 |
| `935fcd24`, `14a76d06`, `345b57d3`, `1cf6803f`, `13844528`, `e5c50613` | 320x180 | 8 a 35 | 46,1 a 46,9 | ≈ 0 |

- **Nenhuma passa de −3 ms.** O melhor é −1,5 ms (a `0fbd542c`, com 168 draws por lista, só dá isso). Cortar uma shader **não remove o passe**: sobram begin/end, barreiras e load/store, que é o custo fixo. Por isso a soma ficaria em ~−4 ms mesmo se aditiva.
- O corte por **tamanho de alvo** (mali-22, `diag_cycle` antigo) rendeu −18 a −21 ms justamente porque o passe deixa de existir (320x180 ≈ −10 ms, 640x360 ≈ −5, ≤ 160 ≈ −3). O custo está nos ~35 passes pequenos, não nas shaders.
- Fusão real de passes não é possível na camada Vulkan: cada passe lê o resultado do anterior (blur, downsample) e as shaders são do jogo. O que dá para fazer é **pular passes inteiros** (perde bloom/efeito) ou reduzir o custo fixo por passe.
- **Mali-42: `skip_targets`** (`skip_targets = 320x180` ou `320x180,160x90`): descarta todos os draws em alvos desses tamanhos; o passe nem começa (o código sai antes de `Begin()`). Nunca listar `16x16` (exposição automática). Protocolo no item 1b do README.
- A captura L3+R3 desta rodada (06:59:31) pegou de novo a tela de carregamento.

### 3.4m `skip_targets = 320x180` (mali-42, build 134df23, `dsr_20261113_072825`): ganho de ~10 ms, mas a imagem escurece

Mesma config do 3.4l, só `skip_targets = 320x180` e `diag_cycle = 0`; cena pesada estável (1.224 draws por frame).

| | Base (3.4k/3.4l) | `skip_targets 320x180` |
|---|---|---|
| ms por lista em regime | 46–48 (~47) | **36,0–36,7 (~36,5)** |
| Frame médio / FPS | ~47–49 ms | **37,0–37,7 ms (~27 fps)** |
| Passes por lista (~10,7 mil por 10 s) | ~51 | **~40** |
| Barreiras por lista | ~100 | **~77** |
| Hitches por 10 s | 45–61 | **15–20** |

- **Resultado: −10,5 ms por lista**, exatamente a previsão do `diag_cycle` antigo (320x180 ≈ −10 ms): 12 passes e 23 barreiras por lista a menos. **Confirma que o custo está nos passes, não nas shaders.** Ainda falta ~3,5 ms para 33 ms.
- **Imagem estragada** (print do usuário): muito escura, serrilhada, blocos duros nas sombras; a HUD fica normal. O valor final de exposição (`16x16 R32F`, texel 0) caiu para ~0,004 contra ~0,05 nas rodadas sem corte (cenas diferentes, cuidado), o que sugere que a cadeia de 320x180 alimenta a exposição ou o bloom que se soma à imagem.
- Os alvos de cor de 320x180 vistos até agora: nvn 5 (16 bit, 4x MRT), nvn 17 (32 bit) e leituras de nvn 37 (RGBA8). O formato 10 (R32F) aparece em 640x360 e 16x16 (cadeia da exposição).
- **Mali-42b: `skip_targets` aceita formato** (`320x180:5`, `320x180:17`, `320x180:37`) para separar quais passes de 320x180 causam o escurecimento e quais só custam tempo. Protocolo no 1b.

### 3.4n Bisseção de `skip_targets` por formato (mali-42b, logs `dsr_20261113_131202`, `_131512`, `_131759`)

Cena pesada, parado, `diag_cycle = 0`. **Atenção: esta cena tem 1.487 draws por frame (as rodadas 3.4k a 3.4m tinham 1.224), então não é comparável com os ~47 ms de antes. Falta uma rodada de base (`skip_targets` vazio) nesta cena.** (Nome dos zips de log: `_` no lugar de `:`, ex.: `320x180_37` = `320x180:37`.)

| `skip_targets` | ms por lista (regime) | Frame médio | Passes por 10 s | Hitches por 10 s | Imagem |
|---|---|---|---|---|---|
| `320x180:5` | ~48,0–49,4 | 49,1–50,0 ms | ~10.650–10.800 | 48–54 | (usuário não relatou) |
| `320x180:17` | ~46,2–47,5 | 47,9–48,8 ms | ~10.900–11.100 | 47–48 | **muito escura** |
| `320x180:37` | ~40,1–41,3 | 42,1–42,5 ms | ~10.400–10.500 | 20–26 | **boa** |
| `320x180` (todos, 3.4m, 1.224 draws) | ~36,5 | 37,3 ms | ~10.700 | 15–20 | escura |

- **O formato 37 (RGBA8) é o que importa:** é o único que dá ganho claro (≈ −6 a −9 ms em relação aos outros dois formatos e à base antiga) e mantém a imagem boa. O 17 escurece a imagem (é ele que alimenta a exposição/imagem final) e rende pouco; o 5 quase não rende. **Conclusão: o escurecimento do 3.4m vem do formato 17.** O corte útil é `320x180:37`.
- O valor de exposição final no log (`16x16 R32F`, texel 0) é 1,78 nas rodadas 17 e 37, igual; não distingue o escurecimento, então ele não vem da exposição auto. (A rodada 05 mostrou -2,64 numa linha intermediária.)
- As capturas L3+R3 (`dsr_frame_*.bin`, 460 KB) pegaram de novo a tela de carregamento.

### 3.4o Base, r2 e r3 (mali-42b, logs `dsr_20261113_132904`, `_133236`, `_133614`; cena de 1.487 draws)

| Rodada | `skip_targets` | ms por lista | Frame médio | Passes por 10 s | Barreiras por 10 s | Hitches por 10 s | Imagem |
|---|---|---|---|---|---|---|---|
| base | vazio | ~46,4–50,7 (~49,5) | 50,2–51,3 ms | ~10.600–10.750 | ~20.200–20.500 | 47–59 | normal |
| r2 | `320x180:37,160x90:37` | ~39,1–40,3 (~39,8) | 41,3–42,2 ms | ~9.600–9.700 | ~18.000–18.200 | 20–28 | (boa, não houve relato de problema) |
| r3 | `320x180:37,160x90:37,640x360:37` | **~29,6–32,3 (~31)** | 36,8–39,0 ms | ~8.450–8.800 | ~16.100–16.800 | **2–6** | **preto e branco** (print: cena cinza, sem cor) |

- **Ganho sobre a base:** r2 −9,7 ms por lista; r3 −18,5 ms. O `640x360:37` sozinho vale ≈ −8,8 ms (os 3 cortes somam bem, sem interferência).
- **O custo é por passe, não por shader:** o corte de 640x360 f37 tira ~6 passes por lista (4,2 + 2 quebras, 3.4k) e rende ~8,8 ms, ≈ 1,4 ms por passe. Cortar uma shader isolada de 640x360 (3.4l) rendeu só −1,1 a −1,5 ms porque o passe continua.
- **r3 estraga a cor:** algum passe de 640x360 f37 produz a cor/saturação (ou o ambiente colorido); sem ele a imagem sai preto e branco. O r3 é um limite de custo, não uma configuração jogável.
- **Gargalo mudou no r3:** a GPU ficou em ~77–86% ocupada (30–32 ms por lista), mas o frame médio ficou em 36,8–39,0 ms e subiu durante a rodada. Com a GPU livre, o limite deixa de ser só a GPU (CPU/gravação de ~1.487 draws, sincronismo com vsync); falta medir (log `profile = 1`).
- **Frame médio abaixo de 33,3 ms ainda não apareceu** em nenhuma rodada.

### 3.4p Quem dá a cor e o brilho em 640x360:37 (mali-42c, build 9086188, logs `dsr_20261113_135705` (A), `_140535` (A1), `_142334` (A5); A2, A3 e A4 só com foto)

`diag_cycle` listou os shaders que desenham em 640x360 f37 (draws por lista): **`0fbd542c` 227,5**; `e4eb576b` 12,9; `03cba9f2` 4,0; `9a14cd3d`, `7a6ad674`, `22a6f6c6`, `100a2de7`, `fcb25d17` 1 cada (passes de tela cheia). `diag_cycle` base: 49,5 ms por lista. Todas as rodadas usam `320x180:37,160x90:37` mais os cortes `640x360:37@hash` abaixo. Cena pesada, parado, 60 s, `diag_cycle = 0`.

| Rodada | Cortes `640x360:37@` | Imagem | Medição |
|---|---|---|---|
| A | todos menos `0fbd542c` | escura, HUD normal, sem preto e branco | log: ~35,2 ms por lista, frame 38,5-39,8 ms, 1.487 draws |
| A1 | `e4eb576b`, `03cba9f2`, `9a14cd3d`, `7a6ad674` | brilho normal, **mar liso sem textura** | log: 32,7-37,1 ms por lista, frame 39,5-43,5 ms, 1.487 draws |
| A2 | `e4eb576b`, `03cba9f2`, `22a6f6c6`, `100a2de7` | mar liso e mais escura | overlay: GPU 32 ms, 26 fps |
| A3 | `e4eb576b`, `22a6f6c6` | mar **com** textura, mas escura | overlay: GPU 30 ms, 20 fps |
| A4 | `e4eb576b`, `100a2de7`, `9a14cd3d`, `7a6ad674`, `fcb25d17` | **quase preta**, mar com textura | overlay: GPU 33 ms, 23 fps |
| **A5** | `e4eb576b`, `9a14cd3d`, `7a6ad674` | **perfeita, igual à original** | log: 34,0-35,0 ms por lista, frame 35,8-36,3 ms, 1.225 draws, 3-10 hitches por 10 s |
| **B** (log `dsr_20261114_044403`) | os da A5 + `0fbd542c` | **normal** (relato do usuário) | log: 32,0-32,5 ms por lista, frame 34,0-34,1 ms, 0 hitches, 8.530 passes por 10 s, 1.320 draws (cena não idêntica) |
| **C1** (log `dsr_20261114_045354`) | os da B + `100a2de7` | **normal** (foto: mar com textura, brilho ok; overlay 24 fps) | log: 32,9-33,1 ms por lista, frame 35,0-36,0 ms, 0-1 hitches, ~8.010 passes por 10 s, 1.501 draws (cena mais pesada que a da B, não comparável) |

**Conclusões (cruzando as rodadas, supondo um shader responsável por efeito):**
- **`03cba9f2` (4 draws) dá a textura do mar.** Mar liso na A1 e A2, que o cortam; com textura na A3, A4 e A5, que o mantêm.
- **`22a6f6c6` (1 draw) dá o brilho.** Escuro na A, A2 e A3, que o cortam; normal na A1 e A5, que o mantêm.
- **`100a2de7` e/ou `fcb25d17` não podem ser cortados** junto com a manutenção do `22a6f6c6`: a A4 ficou quase preta. Hipótese (não confirmada): o `22a6f6c6` lê o resultado deles; sem a entrada, o brilho vai a zero. Falta saber qual dos dois é o necessário.
- **Seguros de cortar:** `e4eb576b` (12,9 draws), `9a14cd3d`, `7a6ad674`.
- **Correção (rodada B):** cortar o `0fbd542c` deixou a imagem normal, então **a cor não vem dele** (a inferência anterior estava errada). O r3 de 3.4o (cortava todos os de 640x360:37) saiu preto e branco, então a cor vem de um dos que a B mantém: `03cba9f2`, `22a6f6c6`, `100a2de7` ou `fcb25d17` (os dois primeiros já têm função conhecida: mar e brilho). Não foi isolado qual.
- **Rodada C1:** cortar também o `100a2de7` manteve a imagem normal. Como a A4 (que cortava `100a2de7` e `fcb25d17` juntos) ficou quase preta, o necessário é o `fcb25d17` (ou os dois em conjunto). Não cortar `03cba9f2`, `22a6f6c6` e `fcb25d17`. Passes por 10 s caíram (8.530 → 8.010), mas a C1 mediu 1.501 draws contra 1.320 da B, então o ms por lista não separa o ganho do `100a2de7`.
- **Custo do `0fbd542c`:** só ~2-3 ms por lista (A5 → B), apesar dos 227,5 draws; o custo vem dos passes. **B é a melhor config jogável até agora** (frame 34,0 ms, 0 hitches).
- **Ganho da A5 é pequeno:** os 3 shaders cortados são baratos. A GPU continua em ~34-35 ms por lista, acima do orçamento de 33,3 ms. (A rodada B mostrou que o `0fbd542c` também é barato, ~2-3 ms.)
- **Cuidado ao comparar:** a A5 mediu 1.225 draws e 250 trocas de alvo por frame; A e A1 mediram 1.487 e 306. A cena não era a mesma, então o frame de 36 ms da A5 não é comparável diretamente com a A. Comparar só rodadas com o mesmo número de draws.
- A2, A3 e A4 não têm log (só foto e overlay), então a leitura delas é visual. A linha da A5 é a única com imagem normal e mar com textura.

**Config atual (C1; imagem normal):**
```
skip_targets = 320x180:37,160x90:37,640x360:37@e4eb576b,640x360:37@9a14cd3d,640x360:37@7a6ad674,640x360:37@0fbd542c,640x360:37@100a2de7
```
Opções mais conservadoras: B (sem o `100a2de7`) e A5 (sem o `0fbd542c`). A bisseção de shaders termina aqui: os 3 que restam (`03cba9f2`, `22a6f6c6`, `fcb25d17`) são necessários.

### 3.4q Config C1 com `profile = 1` (mali-42c, build 9086188, `dsr_20261114_045936`)

Mesma config da C1 (`render_scale 0.55`, `barrier_dst_fragment off`, `skip_depth_prepass on`), cena pesada, parado, regime depois de ~40 s.

- **Desempenho:** GPU busy 32,7-32,8 ms por lista; frame médio 34,2-34,3 ms (≈ 29,2 fps); 0 hitches por 10 s; `game step` 33,3 ms (travado em 30 fps).
- **Quem limita é a GPU, por pouco:** em 10 s, 4.293 ms executando listas, dos quais **3.230 ms esperando a GPU**. O `dsr-record` ficou 4.203 ms ocupado e a render thread esperou por ele só 1 ms. O jogo esperou a render thread 0-1 ms nos presents.
- **CPU não limita:** a thread com mais CPU é a `Thread-10` (execução das listas, 2,6 s de CPU em 10 s); `MainThread` 1,8 s; `dsr-record` 1,2 s; `MTR_0/1/2` 1,3-1,9 s cada. Nenhuma passa de 26% de um núcleo.
- **Fase por draw (10 s, ms):** setup 664, targets 216, textures 973, uniforms 172, vertices 420, pipeline 203, pass+queue 869. 92.272 draws no caminho rápido, 0 pipelines compilados.
- **Conclusão:** faltam ~1-2 ms por lista de GPU para ficar com folga abaixo de 33,3 ms. A alavanca mais barata ainda não testada nesta config é `barrier_dst_fragment 1` (ganho de 1-2 ms em 3.4g, sem flicker confirmado).

### 3.4r Config C1 + `barrier_dst_fragment 1` (mali-42c, build 9086188, `dsr_20261114_050354`, `profile = 1`)

Mesma cena e mesmos 1.320 draws por frame e 278 trocas de alvo da rodada B (comparável com a B; a C1 e a C1 com `profile` tinham 1.501 draws).

- **GPU busy 25,7-25,9 ms por lista** (B: 32,0-32,5; C1: ~33). Em 10 s, 3.514 ms executando listas e só **275 ms esperando a GPU** (antes 3.230 ms).
- **Frame médio 33,6 ms** (≈ 29,8 fps), 0 hitches nas duas primeiras janelas, `game step` 33,3 ms, o jogo esperou a render thread 0 ms. A terceira janela teve 35,0 ms médio e 5 hitches (pior 131 ms), no fim do log (provável fechamento do jogo; não confirmado).
- **Ganho de ~6,5 ms por lista sobre a B** (barreira só até o fragmento + corte do `100a2de7`); a parte de cada um não foi separada. Muito maior que o 1-2 ms de 3.4g: a barreira rende mais com menos passes.
- **Gargalo mudou:** a GPU agora tem folga (~26 ms contra 33,3), e o frame de 33,6 ms está no limite do `fps 30`/vsync, não da GPU.
- **Imagem:** relato do usuário pendente (flicker, imagem errada, brilho). Se aparecer problema, voltar `barrier_dst_fragment` a 0.

### 3.4s Escurecimento em outras áreas (mali-42c, sessão de jogo, logs `dsr_20261114_051139`, `_051726`, `_052956`)

Com a config da 3.4r, a cena do mar ficou boa, mas outras áreas (ponte/torres, arena do Taurus Demon) ficaram **meio pretas**, com flicker leve no chefe e inimigos aparecendo só de perto.

- **Pop-in e flicker no chefe:** `async_pipelines` ligado. Em uma janela de 10 s da primeira sessão, 88 pipelines compilaram em 4,6 s e 5.151 draws esperaram; na segunda (cache de pipelines 2,2 → 3,7 MB) só 45. Tende a cair conforme o cache cresce; `async_pipelines 0` trocaria o pop-in por travadas.
- **GPU em 50-60% é normal:** ~22-26 ms por lista num orçamento de 33,3 ms (cap de 30 fps). As quedas para 24 fps vêm dos hitches de compilação, não da GPU.
- **Bisseção do escurecimento (mesma área escura, parado):**

| Rodada | `skip_targets` | Imagem |
|---|---|---|
| E1 | só `320x180:37,160x90:37` | normal |
| D1 | E1 + `640x360:37@9a14cd3d`, `@7a6ad674`, `@100a2de7` | escura |
| **D2** | E1 + `640x360:37@9a14cd3d`, `@7a6ad674` | **normal** |

- **Conclusão:** `100a2de7` é necessário nessas áreas (na cena do mar era cortável, por isso a C1 enganou). `9a14cd3d` e `7a6ad674` são seguros nas duas.
- **D2:** GPU 23,6-24,8 ms por lista, frame 33,5-34,4 ms, 0 hitches, 1.118 draws. É a config geral atual.
- **Ainda não testados fora do mar:** `0fbd542c` e `e4eb576b` (também cortados na C1); podem escurecer outras áreas.


**`render_scale` com a D2 (mesma área escura, parado; log `dsr_20261114_053448`):**

| `render_scale` | Alvo 1280x720 | ms por lista | Frame médio | Hitches por 10 s |
|---|---|---|---|---|
| 0.55 | 704x396 | 23,6-24,8 | 33,5-34,4 ms | 0 |
| 0.60 | 768x432 | 25,8-26,1 | 33,5-33,6 ms | 0 |
| 0.65 | 832x468 | 26,6-26,7 | 33,5-33,6 ms | 0 |
| 0.70 | 896x504 | 28,7-28,8 | 33,6-33,9 ms | 0-1 |

**Pior caso: cena do mar com a D2** (1.320 draws, 278 trocas de alvo; log `dsr_20261114_055713`, imagem normal):

| `render_scale` | ms por lista | Frame médio | Hitches por 10 s | Espera da render thread |
|---|---|---|---|---|
| 0.70 | **33,8-34,0** | 35,1-35,4 ms | 1-4 | 100-180 ms |
| 0.65 (log `dsr_20261114_060225`) | 31,2-31,7 | 34,7-35,4 ms | 0 | 0 ms |
| 0.65 + corte `e4eb576b` (log `dsr_20261114_060720`) | 30,3-31,4 | 34,7-35,4 ms | 0-1 | 0 ms |
| 0.65 + corte `0fbd542c` (log `dsr_20261114_061148`; foto do mar normal) | 30,2 (1ª janela; depois 27,5 e 26,4 com a cena mudando para 1.176 draws) | 34,2 ms (1ª janela; 36,2 e 41,8 com 17 hitches na última) | 0 na 1ª | 0-10 ms |
| 0.60 (log `dsr_20261114_061651`, D2) | 30,0-30,3 | 34,1-34,3 ms | 0 | 0 ms |

No mar o 0.70 estoura o orçamento (a GPU passa de 33,3 ms). Os cortes `0fbd542c`, `e4eb576b` e `100a2de7` da C1 davam ~25,8 ms nessa cena a 0.55, mas `100a2de7` escurece outras áreas; `0fbd542c` e `e4eb576b` ainda não foram testados fora do mar.

O 0.60 custou só ~1,5 ms por lista e o 0.65 mais ~0,7 ms (cenas com 1.118 a 1.158 draws, quase iguais); o frame ficou em 33,5 ms nos dois. Usuário: nitidez melhor no 0.65 (log `dsr_20261114_053840`).

**Config geral atual (D2):**
```
skip_targets = 320x180:37,160x90:37,640x360:37@9a14cd3d,640x360:37@7a6ad674
barrier_dst_fragment = 1
```

### 3.4u Sessão na luta do Taurus Demon com a config final provisória (mali-42c, `dsr_20261114_063211`)

Config: `render_scale 0.65`, `barrier_dst_fragment 1`, D2. Relato do usuário: **flicker na luta do Taurus Demon**; GPU usando menos; FPS cai em áreas abertas (esperado); áreas fechadas ficam em 30 fps.

- **Janelas de áreas abertas e transições:** GPU 26-30 ms por lista, frame 33,9-37,5 ms, 0-3 hitches por 10 s.
- **Janelas da luta (últimas 3):** frame **39,3-42,9 ms**, **5-17 hitches** por 10 s, e a GPU **mais baixa (24-25 ms)**: ela fica ociosa porque os frames travam, não porque sobra desempenho.
- **Causa provável do flicker: compilação de pipelines novos com `async_pipelines`.** Uma janela compilou 12 pipelines em 7,46 s e deixou **2.229 draws esperando**; outra, 4 pipelines em 3,96 s (~1 s cada); outras tiveram 49 e 78 draws esperando. Enquanto compila, o objeto ou efeito não é desenhado. No Mali, esses pipelines pesados demoram ~0,6-1 s cada.
- **O cache de pipelines (3,77 MB carregados no início) é salvo sozinho em segundo plano** quando surgem pipelines novos; a segunda passagem pelo mesmo lugar deve compilar bem menos.
- **Complemento (áreas abertas, janelas 06:33-06:37 do mesmo log):** frame 38-50 ms e 7-40 hitches por 10 s com 1.100-1.450 draws por frame, **sem pipelines novos** e com a GPU em 24-29 ms por lista. Em uma delas, 8.276 ms executando listas em 10 s, só 172 ms esperando a GPU. O limite ali é a **CPU da thread que executa as listas** (por 10 s: textures 2.188 ms, pass+queue 1.428 ms, vertices 1.105 ms, targets 907 ms, setup 653 ms), não a GPU nem a compilação; baixar `render_scale` não ajuda. É um custo separado do flicker.
- **Repetição da luta (logs `dsr_20261114_160139` e `_160241`): teste inválido, cache de pipelines vazio.** O primeiro log carregou `pipeline cache: 0 bytes` (antes: 3,77 MB) e o segundo 16 KB, ou seja, o arquivo `cache/vk_pipelines.bin` da pasta `DSRNative` foi perdido (apagado ou pasta recriada) antes dessa rodada. Resultado com cache frio: 126 pipelines compilados em 6,6 s (45.167 draws esperando) e mais 8 em 18,3 s (32.837 esperando), frames de 44-54 ms e até 54 hitches por 10 s no início da luta; depois caiu para 34-42 ms com os pipelines novos diminuindo. Nas janelas finais sem pipelines novos, o limite voltou a ser a CPU (GPU 25-29 ms, frame 34-38 ms). **Não apagar a pasta `cache`** entre testes.
- **Terceira passagem da luta (log `dsr_20261115_071119`, cache carregado com 2,9 MB): o flicker continua, e já não é compilação.** Os pipelines novos pesaram pouco: no máximo 601 draws esperando por janela de 10 s (antes 45.167). Nas janelas da luta (07:12:3x-07:14:0x, 1.000-1.330 draws por frame) o frame ficou em 38-47 ms com 4-28 hitches, GPU 25-28 ms por lista e ~0-70 draws esperando por pipeline. Depois da luta o frame volta a 34-37 ms. O usuário relata o mesmo piscar no chefe.
- **Causa do flicker no chefe: `barrier_dst_fragment 1` (log `dsr_20261115_074734`, mesma luta com `barrier_dst_fragment 0`, cache de 3,1 MB, sem flicker segundo o usuário).** Com a barreira ligada, uma transição para SHADER_READ_ONLY só espera o estágio de fragmento; se um vertex shader amostrar essa textura (o risco já descrito em `runtime.h`), ele lê antes de a passada anterior terminar, e o resultado é o piscar. Custo de desligar: na luta a GPU subiu de 25-28 para 29-31 ms por lista (picos de 34,9-36,8), com o frame em 39-45 ms (a luta já era limitada pela CPU, 38-47 ms antes); no mar, ~6 ms a mais (3.4r).

### 3.4v Correção do flicker: `barrier_frag_targets` (patch `barrier_frag_targets.patch`, ainda não testado)

Novo setting `barrier_frag_targets` (usado junto com `barrier_dst_fragment = 1`): lista de tamanhos de imagem (`WxH` ou `WxH:formato`, tamanho do jogo, separados por vírgula, sem espaços) cuja transição para SHADER_READ_ONLY espera só o estágio de fragmento. Imagens fora da lista voltam a esperar vertex+fragment, então um vertex shader que amostre uma delas vê a passada terminada (causa do flicker, 3.4u). **Lista vazia = comportamento antigo** (todas as imagens). Arquivos tocados: `src/runtime/runtime.h` (campo), `src/platform/android/android_main.cpp` (leitura e log), `src/hle/nvn/vk_backend.cpp` (`RawBarrier`, `TightBarrierMasks` e `Transition` passam a receber `dst_frag`, calculado em `BarrierFragOnly`). Não compilado fora do GitHub Actions.

**Teste após o build** (luta do Taurus Demon e mar, mesma config de antes):
```
barrier_dst_fragment = 1
barrier_frag_targets = 640x360:37,320x180:37,160x90:37
```
Sem flicker e GPU do mar perto de 31 ms: pronto. Com flicker: reduzir a lista (só `640x360:37`, depois só `320x180:37,160x90:37`) até achar qual tamanho tem o vertex shader que amostra. Sem flicker mas sem ganho no mar: ampliar a lista aos poucos.

### 3.4w Custo de CPU por draw e por shader (patch `draw_cost_by_shader.patch`, ainda não testado)

Medido na luta do Taurus Demon (`dsr_20261115_074734`): ~1.170 draws por frame, 160 mil draws em 10 s, 7.033 ms executando listas (~44 µs por draw). As fases do `Draw()` ficam distribuídas, sem ponto único dominante (por 10 s: textures 1.597 ms, vertices 1.083, pass+queue 1.080, targets 797, setup 511, uniforms 482, pipeline 336). Os caminhos quentes já têm cache (views por hash em `fast_views`, descriptor sets reutilizados, scratch sem alocação), então microotimizar rende poucos por cento. O ganho grande está em **fazer menos draws**: cortar ou simplificar os shaders mais caros.

O patch acrescenta ao log de 10 s a linha `draw time by fragment shader (ms/draws, top 12 ...)`: os 12 fragment shaders com mais tempo de CPU no `Draw()` (hash curto, o mesmo de `skip_targets`/`skip_shaders`), com milissegundos e número de draws, amostrados 1 a cada 8 draws. Aplicar depois de `barrier_frag_targets.patch`.

**Uso:** jogar a luta do Taurus Demon com a config atual e mandar o log. Com o ranking, escolho os candidatos a `skip_shaders` (efeitos e partículas de baixo valor) e testo em ciclo, medindo ms por lista e a imagem.

### 3.5 Clock e touch boost

> **Nota (mali-35):** estes testes foram feitos com a economia de energia ligada, mas desligá-la não mudou o resultado; ver 3.5d.

Teste do usuário, mesma cena, câmera parada:
- Sem dedo: **20–22 fps**.
- Com um dedo apoiado na tela: **26 fps cravados**.

Interpretação: o toque faz o sistema subir o clock de CPU/GPU. A diferença também explica por que segurar o analógico direito parecia melhorar o FPS.

### 3.6 ADPF (dicas de desempenho ao Android)

- **mali-26:** sessão criada com 2 threads (`ok`), reportando o intervalo entre frames contra 33,3 ms. Cenas leves: 33,5 ms por frame (30 fps). Cena pesada: ~47 ms, GPU 100%. **Inconclusivo**: o teste usou `render_scale 0.75` (o anterior era 0,65) e o FPS parado não foi anotado.
- **mali-27:** reporta total, CPU e GPU via `APerformanceHint_reportActualWorkDuration2` e chama `notifyWorkloadIncrease(gpu)` quando a GPU passa de 33,3 ms por ~1 s. Resultado: o sistema **aceitou** (`report2 rc 0`, `notify rc 0`), mas a cena pesada seguiu em 39–44 ms por lista (22–25 fps) com a GPU a ~100%. Nesse aparelho o hint de GPU não vira clock; o touch boost é um caminho do sistema que o app não alcança.
- **Comparação `adpf 1` vs `0` (mali-26, `render_scale 0.65`):** ~39,8 vs ~41,9 ms por lista, ≈ 4%, dentro do ruído. O `adpf` fica ligado por ser inofensivo e útil ao térmico.

---

### 3.5c Clocks medidos (mali-31/32, sem nenhum boost ligado; amostra de 1 leitura a cada 10 s)

- `/sys/kernel/gpu/gpu_clock` é **legível** pelo app (os demais arquivos de GED/gpufreq dão Permission denied). Valores em kHz: parado/menu 390 MHz; cena pesada 976–1003 MHz.
- CPU: núcleos grandes (cpu6/7) em 2,2 GHz nas leituras; os pequenos (cpu0/4) oscilam entre 0,5 e 2,0 GHz.
- Portanto, nas leituras sem dedo a GPU já estava perto de ~1 GHz: a ideia de "GPU em clock baixo" não se confirma por si só. Falta saber o clock máximo da GPU e o que o dedo muda (CPU pequena, DRAM?). O mali-33 lista os arquivos legíveis de `/sys/kernel/gpu` e mostra o clock da GPU no medidor.
- Baseline sem boost: `render_scale 0.65` 35–43 ms por lista (últimos 20 s: 43,4); `0.55` 35–41 ms.

### 3.5d Clock sem dedo, `boost_gamemode` e economia de energia (mali-33 a mali-35, 2026-11-12)

Cena pesada, sem dedo, `render_scale 0.55`, `shadow_size 512`. Leitura de `ms por lista` em janelas de 10 s, em regime (depois dos ~20 s iniciais da cena).

| Teste | Economia de energia | ms por lista em regime | Clock cpu0/cpu4 |
|---|---|---|---|
| Baseline 0.65 (mali-33) | ligada | 43,4 / 43,4 (final); 35,0–40,5 no começo | 500 MHz no final |
| Baseline 0.55 (mali-33) | ligada | 35,4–41,6 (média ~38) | 500–2000 MHz |
| `boost_gamemode 1` (mali-33 e mali-34) | ligada | 41,0–42,1 (~41,6) | 500 MHz quase sempre |
| `boost_gamemode 0` (090608) | desligada (sem registro no log) | 33,3 / 34,9 / 35,7 / 37,2 / 38,2 / 39,6 / 40,8 / 41,0 (média ~37,6) | 500–2000 MHz |
| `boost_gamemode 0` (mali-35, 094842) | **desligada (`power save false` no log)** | 41,0 / 42,0 / 42,4 / 40,9 / 41,6 / 40,5 (média ~41,4) | 500–2000 MHz |

- **GPU já está no clock máximo sem dedo:** `/sys/kernel/gpu/gpu_clock` fica em 950–1003 MHz em cena pesada (parado/menu: 390 MHz). Em todos os testes. Logo, a hipótese de "DVFS da GPU segurando o clock" (3.4d) **não se confirma**; o clock da GPU não é o que o dedo muda.
- **CPU little acompanha o tempo:** nos logs com economia ligada, janelas com cpu0/cpu4 a 2000 MHz deram ~35 ms por lista e janelas a 500 MHz deram 39–43 ms. A diferença (~6 ms) é do mesmo tamanho do ganho do dedo. Hipótese: o toque sobe CPU little e/ou a frequência da memória (DRAM/barramento), que a GPU Mali divide com a CPU. O app não lê o clock da DRAM; não confirmado. Com a economia desligada, a relação ficou mais fraca.
- **`boost_gamemode 1` não funcionou (mali-34, com log no arquivo principal):** o app é reconhecido como jogo (`isGame true`, categoria 0), o `GameManager` está disponível (modo atual 1 = padrão) e `setGameState(gameplay, uninterrupted)` rodou sem erro. Mesmo assim o tempo ficou em ~41–42 ms e a CPU little em 500 MHz. Descartado como solução. O log do mali-33 não registrava esse resultado (o espelho do logcat vem vazio no Android 17); o mali-34 passou a gravar linhas `boost: ...` no log principal.
- **Economia de energia (mali-34/35): não é a causa.** O log do mali-34 mostrou `power save true`. O log `dsr_20261112_090608.txt` (economia desligada, mas sem registro do estado) deu ~37,6 ms, mas **não se repetiu**: o mali-35, com `power save false` registrado, ficou em ~41,4 ms (≈ 24 fps) em regime, igual aos ~41,7 ms de antes. O 090608 provavelmente pegou um ponto/câmera mais leve; ele também teve mais passes por 10 s (11–12 mil contra 10,4–10,7 mil nos outros dois), o que indica cena diferente. Conclusão: sem dedo, a cena pesada fica em ~41–42 ms com ou sem economia de energia.
- **Ressalvas:** a posição da câmera varia entre rodadas e muda o resultado em alguns ms; comparar só rodadas com ~10,4–10,7 mil passes por 10 s.
- **O que o app agora loga no começo (mali-35):** `boost: app isGame flag`, `thermal status N, power save true/false` e `GameManager game mode (read only)`, mesmo com `boost_gamemode 0`.
- As capturas de frame (`dsr_frame_*.bin`) dessas rodadas pegaram telas leves (vídeo/abertura), então não servem para a cena pesada.

### 3.5b Clock fixo (dedo apoiado) x `render_scale`, mesma cena (631 draws)

> **Nota (mali-35):** feito com a economia de energia ligada; sem dedo isso não fez diferença (3.5d). Não foi repetido com economia desligada.

| | Sem dedo | Dedo fixo |
|---|---|---|
| `render_scale 0.65` | ~41,5 ms por lista (24 fps) | 34,7–35,7 ms, oscila entre 26 e 30 fps |
| `render_scale 0.55` | ~41–42 ms (24 fps) | 32,3–33,7 ms, **30 fps cravados** (33,5 ms de média, 0 hitches) |

- **O clock é o fator dominante:** só o dedo na tela tira ~6 ms (41,5 para ~35). Com o clock fixo, a resolução passa a render (~2,4 ms de 0,65 para 0,55); sem ele, o ganho some (DVFS).
- Sem dedo, nenhuma variável testada (resolução, scissor, ADPF) moveu o tempo de forma útil.
- Atenção: com controle físico (Bluetooth) não há toque na tela, então o boost pode não acontecer e o FPS cair para ~24.
- Próximo: fazer o sistema subir o clock sem dedo (ver 6.0).

## 4. Referência de settings

| Chave | Padrão | Efeito |
|---|---|---|
| `render_scale` | 0.75 | Escala de renderização (teto quando `dyn_res=1`) |
| `shadow_size` | 1024 | Resolução da sombra |
| `skip_shaders` | lista | Corta shaders de fragmento por hash |
| `dyn_res` | 0 | Resolução dinâmica (glitch de canto, sem ganho) |
| `dyn_min` / `dyn_target_ms` | 0.6 / 31 | Piso e alvo do controlador |
| `skip_writeback` | 0 | 0 tudo, 1 só R32F, 2 nenhum |
| `adpf` | 1 | Dicas de desempenho ao Android |
| `diag_cycle` | 0 | Diagnóstico por shader dos passes pequenos de pós; mali-42: 12 candidatas, 14 fases de 7 s (~100 s), começa sozinho ~30 s em cena pesada ou por L3+R3 |
| `boost_gamemode` | 0 | Teste de clock: avisa o GameManager do Android (estado de jogo, Android 14+) |
| `boost_sustained` | 0 | Teste de clock: modo de desempenho sustentado da janela (pode BAIXAR o clock) |
| `adpf_target_ms` | 33.3 | Alvo de tempo de frame da sessão ADPF (10–40); menor, ex. 25, faz o sistema achar que está atrasado |
| `adpf_graphics` | 0 | Teste de clock: sessão ADPF marcada como pipeline gráfico com a janela anexada (Android 16+) |
| `frame_rate_hint` | 0 | 0 = informa `fps` à janela, 1 = não informa, 2 = informa 60 |
| `clock_log` | 1 | Loga clocks de GPU/CPU a cada 10 s onde o app conseguir ler |
| `diag_tiny_scissor` | 0 | Diagnóstico: draws opacos do mundo com scissor 1x1 (separa custo de fragmento do resto) |
| `barrier_dst_fragment` | 0 | Experimento (mali-36, exige `tight_barriers 1`): a transição para SHADER_READ_ONLY espera só o estágio de fragmento, não vértice+fragmento |
| `skip_depth_prepass` | 0 no código; **use 1** no `settings.txt` | 1 pula os draws só de profundidade da cena em tela cheia; ligar o pré-passe não rendeu (3.4e) |
| `skip_targets` | vazio | Mali-42: tamanhos de alvo de cor, com formato e shader opcionais (`320x180`, `320x180:37`, `640x360:37@0fbd542c`, separados por vírgula) cujos passes são pulados inteiros; perde o efeito (bloom?), ganha o custo fixo do passe. Nunca `16x16` |
| `diag_world` | 0 | Diagnóstico por shader do passe do mundo (começa sozinho após ~30 s em cena pesada, ou L3+R3) |

Medidor na tela (toque nele para esconder): linha 1 = FPS, temperatura da bateria e status térmico; linha 2 (mali-32) = `GPU X% (Y ms)` (tempo ocupado da GPU e ms por frame), `CPU X% (pico Y% nome)` (processo em % de todos os núcleos e a thread mais carregada) e `RAM X GB (livre Y)` (residente do jogo e memória disponível no aparelho). Atualiza a cada ~1 s.

Captura de frame: **L3+R3** (com `diag_cycle = 0`).

---

## 5. Como ler o log

- `GPU busy X ms in the last 10 s (Y ms per list)`: Y acima de 33 ms = abaixo de 30 fps.
- `frame times: ... game waited for the render thread N ms`: N alto = jogo esperando a GPU.
- `last 10 s: N render passes, M image barriers`: custo fixo por passe.
- `capture N GPU ms per pass` e `SUMMARY`: custo de cada passe; compare as partes (a captura infla o total).
- `adpf: ...`: disponibilidade da API, `rc` dos reports (0 = aceito).

**Protocolo de teste que funcionou:** mesma posição e câmera, sem tocar na tela por 30 s, anotar o FPS; depois 10 s com um dedo apoiado; repetir com uma variável alterada por vez (mesmo `render_scale`).

---

## 6. Próximos passos

0. **Clock sem dedo (prioridade).** Já feito: `boost_gamemode` (sem efeito, ver 3.5d), ADPF (sem efeito, 3.6) e economia de energia (sem efeito, 3.5d). Falta, nesta ordem, mesma cena, `render_scale 0.55`, sem dedo 60 s, um setting por vez, lendo `ms por lista` e o clock da cpu0/cpu4 no log:
   1. (feito) Baseline do mali-35: ~41,4 ms por lista, `power save false`.
   2. `frame_rate_hint 2`, depois `frame_rate_hint 1`.
   3. `boost_sustained 1` (pode até baixar o clock).
   4. `adpf_target_ms 25` e `adpf_graphics 1`.
   5. Se nada subir a CPU little: fixar as threads de render e do driver nos núcleos 6/7 (já a 2,2 GHz); hoje só a thread do jogo e a de gravação ficam lá.
   6. Repetir o A/B `render_scale` 0.65 × 0.55 e o A/B com dedo (3.5b) com a economia desligada.
   7. Medir a cena pesada em um ponto fixo (mesma posição da câmera) para comparar rodadas.
8. (feito no mali-35) `skip_depth_prepass 0` não rendeu: voltar a 1 (3.4e).

1a. **Fusão dos passes do pós (prioridade, mali-39+).** 32 de 44 passes por lista acabam por leitura de alvo renderizado (3.4h), ~17 só na cadeia 320x180 / 640x360 / 160x90. Ordem: (1) rodar o mali-38 por 60 s e ler as linhas de snapshot/cópia com endereço; (2) (feito, 3.4i/3.4j) snapshot de depth por imagem: sem efeito, os 3 snapshots por lista são necessários; antes de fundir o pós, ler `capture pass N (no draws)` do mali-39b e descobrir o que são p3 (10 ms) e p12 (4,6 ms); (3) identificar os shaders de cada passe pequeno do pós (`diag_cycle`) e fundir os que lêem o resultado do anterior com a mesma resolução, ou trocar blur separável por um passe só; (4) medir ms por lista contra ~41 e passes por lista contra 44.
1. **Geometria e passes (resultado em 3.4d: não é fragmento).** A/B na mesma sessão com `diag_tiny_scissor` 0 e 1; depois um diagnóstico que pule os draws do passe p10 para confirmar o custo por draw. (Texto antigo:) **Fragmento ou vértice/draw?** Na cena pesada, medir com `diag_tiny_scissor = 1` (draws opacos do mundo com scissor 1x1: vértices ficam, fragmentos saem), parado por 30 s, contra a base de 49–55 ms por lista. Queda grande = custo de fragmento (overdraw, shaders, alpha test). Queda pequena = custo de vértices/tiler/draws; aí reduzir a contagem de draws. (O formato dos alvos já foi descartado, ver 3.4c.)
2. **Custo fixo por draw/passe:** ~680 draws, ~57 trocas de alvo e ~38 passes por frame. (`trim_targets`, `anisotropy 1` e `texture_drop 2` já estão em uso.)
3. **Custo fixo do pós:** fundir ou cortar passes pequenos (~30 passes, ~14 ms).
4. **Glitch do `dyn_res`:** só vale retomar se a cena pesada responder bem à resolução.

0b. **Barreiras só até o fragmento (mali-36).** Em `TightBarrierMasks` (`vk_backend.cpp`), a transição para `SHADER_READ_ONLY_OPTIMAL` usa como destino vértice + fragmento. Os passes de pós só amostram a textura no fragmento; esperar o vértice impede que o tiler do passe seguinte comece enquanto o fragmento do anterior ainda roda (~44 passes e ~100 barreiras por frame). Chave `barrier_dst_fragment = 1`. Protocolo: mesma cena, `render_scale 0.55`, `skip_depth_prepass 1`, sem dedo 60 s, A/B 0 × 1 na mesma sessão, comparando ms por lista (base ~41,5). **Risco:** se algum vertex shader amostrar textura, pode aparecer imagem errada/piscando; nesse caso volte a 0. O log principal mostra `barrier_dst_fragment on/off`.

1b. **Achar qual passe de 640x360:37 dá a cor e cortar os outros (prioridade, mali-42c; passos 1-2 feitos, ver 3.4p).** Meta: ~30–31 ms por lista e frame médio ≤ 33,3 ms com imagem boa. r2 (`320x180:37,160x90:37`) é a melhor config jogável (−9,7 ms) e r3 prova que cortar também `640x360:37` rende −8,8 ms, mas perde a cor. Passos, mesma cena pesada, parado, sem dedo, 60 s por rodada, regime depois de ~40 s:
   1. **Listar as shaders:** `diag_cycle = 1`, `skip_targets` vazio. O ciclo começa sozinho depois de ~30 s e o log (`diag_cycle: small-target fragment shader HASH: N draws/list, target WxH fNN`) agora lista até 64 shaders com formato. Basta ~45 s na cena pesada; pode fechar o jogo depois. Enviar o log.
   2. **Bisseção:** o `skip_targets` aceita filtro por shader (`640x360:37@0fbd542c`). Com os hashes do passo 1, cortar um a um os passes de 640x360:37 (somando `320x180:37,160x90:37`) e ver qual deixa a imagem sem cor; os outros ficam cortados.
   3. **Medir o resto:** `profile = 1` numa rodada boa, para ver se a CPU passa a limitar abaixo de ~33 ms.
   4. Se algum passe de 640x360:37 sobrar necessário, o ganho será parcial; o resto é custo fixo por passe (load/store e barreiras), ainda não tocado.

   **Próximos passos após 3.4p (mali-42c), nesta ordem:**
   1. (feito) Rodada B: `0fbd542c` é cortável, imagem normal, GPU 32 ms por lista, frame 34 ms.
   2. (feito) Rodada C1: `100a2de7` é cortável, imagem normal. `fcb25d17` fica (necessário na A4). Bisseção de shaders encerrada.
   3. **Medir com o mesmo número de draws** (mesma posição de câmera) antes de comparar com a base de 49,5 ms; as cenas das últimas rodadas tinham 1.225 a 1.487 draws.
   4. (feito, 3.4q) `profile = 1`: a CPU não limita; a GPU está em ~32,7 ms por lista e o frame em 34,3 ms.
   4b. (feito, 3.4r) `barrier_dst_fragment 1`: GPU 25,8 ms por lista, frame 33,6 ms. Falta confirmar a imagem (flicker) e jogar alguns minutos em áreas diferentes.
   4c. (feito, 3.4s) Sessão de jogo: escurecimento nas outras áreas vinha do `100a2de7`; config geral = D2.
   4d. (feito) `render_scale 0.60`: GPU 26 ms, frame 33,5 ms, 0 hitches.
   4e. (feito) `render_scale 0.65`: GPU 26,7 ms, frame 33,5 ms, 0 hitches, nitidez melhor.
   4f. (feito) `render_scale 0.70` (log `dsr_20261114_054216`): GPU 28,8 ms (+2,1 ms sobre o 0.65), frame 33,6-33,9 ms, 0-1 hitch; margem de GPU cai para ~14%.
   4g. (feito) Mar com 0.70: GPU 34 ms, frame 35,2 ms, 1-4 hitches: **0.70 não segura o mar**.
   4h. (feito) Mar com 0.65: GPU 31,5 ms, frame 34,7-35,4 ms, 0 hitches. Abaixo do orçamento de GPU, mas o frame ainda passa de 34 ms (~28,6 fps). (O log `dsr_20261114_060121` é de menu/carregamento, 70 draws: ignorar.)
   4i. (feito) Corte de `e4eb576b` no mar a 0.65: ganho de só ~0,5 ms por lista, frame igual (34,7-35,4 ms). **Não vale o risco: fica fora da config.**
   4j. (feito) Corte de `0fbd542c` a 0.65 no mar: imagem normal na foto, mas ganho de só ~1,3 ms por lista (30,2 contra 31,5). Não foi checado nas áreas escuras. **Descartado**: ganho pequeno para o risco; a D2 continua a config geral. O log `dsr_20261114_061141` não tem estatísticas (sessão curta).
   4k. (feito) Mar com 0.60: GPU 30,0-30,3 ms (esperado ~29), frame 34,1-34,3 ms, 0 hitches. Ganho de só ~0,7 ms no frame sobre o 0.65 (35,0); o frame fica um pouco acima de 33,3 mesmo com a GPU a ~30 ms (perda ocasional de vsync).
   4l. **Decisão provisória:** `render_scale 0.65` como padrão (nitidez bem melhor, ~28,6 fps só no mar e 33,5 ms firmes nas outras áreas); `0.60` se preferir ~29,2 fps no mar; `0.70` só em áreas leves.
   4m. (feito, 3.4u) Sessão com o Taurus Demon: flicker explicado por pipelines em compilação (2.229 draws esperando numa janela).
   4n. (feito) Cache cheio: flicker continua, então não era só compilação.
   4o. (feito, 3.4u) `barrier_dst_fragment 0` na luta: sem flicker. O culpado é a barreira.
   4p. (decidido) Caminho (c): patch `barrier_frag_targets.patch` (3.4v). Enquanto não houver build novo, jogar com `barrier_dst_fragment = 0` e `render_scale 0.60` (sem flicker).
   4q. **Próximo:** aplicar o patch, gerar o APK no GitHub Actions e testar a lista `640x360:37,320x180:37,160x90:37` na luta do Taurus Demon e no mar.

**Config final provisória:**
```
render_scale = 0.65
barrier_dst_fragment = 1
skip_depth_prepass = 1
skip_targets = 320x180:37,160x90:37,640x360:37@9a14cd3d,640x360:37@7a6ad674
```
   5. Fixar B como padrão do `settings.txt` e confirmar FPS em jogo (overlay).

### Térmico e bateria (depois dos 30 fps)

- Medir antes de mexer: temperatura da bateria, status térmico, `getThermalHeadroom` e corrente em mA, a cada 10 s, em sessões de 15–20 min.
- CPU: cache em disco das texturas BC já decodificadas; rever espera ocupada e número de threads.
- Dicas ao sistema (ADPF, modo sustentado) para clocks estáveis em vez de picos.
- Adaptar ao calor: reduzir `render_scale` ou efeitos opcionais quando o headroom cair.
- Modo econômico opcional (limite de 20–25 fps ou sombra menor).
- Medidas até agora: bateria em 32–37 °C com status "leve" em sessões curtas; o aquecimento forte deve aparecer em sessões longas.
