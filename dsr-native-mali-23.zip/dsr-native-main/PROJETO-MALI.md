# DSR Native — fork Mali (Galaxy A07 / Helio G99, Mali-G57 MC2)

Dark Souls Remastered (Switch) rodando nativo no Android via Vulkan (HLE do NVN). Alvo: **30 fps estáveis**.
Hoje: ~30 fps em áreas fechadas, **18–26 fps em áreas abertas** (média ~22).

## O que foi descoberto
- O gargalo é a **GPU** (ocupada ~9,9 s a cada 10 s). Não é CPU, nem calor (35 °C, "térmico: leve").
- **Não** eram o problema: texturas, anisotropia, descarte de mip (`texture_drop`), `trim_targets`, `tight_barriers`. Nenhum mexeu no FPS.
- Cada frame: ~1.100–1.300 draws, ~45–62 passes, ~98 barreiras de imagem. Base medida: **~40–46 ms por lista** (meta: ~33 ms).
- Custo medido pelo `diag_cycle` (corta um grupo por vez e mede a queda):

| Grupo cortado | Ganho por lista |
|---|---|
| Passes pequenos de pós-processamento (alvos ≤ 640 px, ~31 passes) | **−18 a −21 ms** |
| Desenhos da cena principal (3 vertex shaders) | −8 a −11 ms |
| Passe de sombra (2048², `shadow_size` 1024) | −2 a −8 ms (ruidoso) |

- Dentro dos passes pequenos (mali-22, 3 ciclos, ruidoso): **320x180 ≈ −10 ms**, 640x360 ≈ −5 ms, ≤160 px ≈ −3 ms.
- O pós-processamento é uma cadeia (cada passe lê o anterior), então o custo vem da **quantidade de passes**, não das barreiras.
- Piscada: só no menu do jogo. Suspeitas: texturas de substituição pretas, leitura de vértice fora do buffer, alvo 1920x1080 visto uma vez.

## O que já está no zip (mali-22)
- Decodificador BC ~2,3x mais rápido (saída idêntica).
- Opções no `settings.txt`: `anisotropy`, `texture_drop`, `trim_targets`, `tight_barriers`.
- `diag_cycle` por tamanho de alvo (640x360 / 320x180 / ≤160 px).
- Este zip ainda **não foi compilado**: se der erro no Actions, me mande a mensagem.

## O que pretendo fazer
1. **mali-23 (pronto, no zip)**: `diag_cycle` por hash do shader de fragmento nos passes 320x180/640x360, para achar quais são opcionais (bloom, profundidade de campo, etc.).
2. Opção `skip_post` no `settings.txt` para cortar ou fundir esses passes (ex.: menos iterações de desfoque).
3. Testar `render_scale` 0.7–0.75 junto, e `shadow_size` 512 se a sombra pesar.
4. Capturar o menu aberto (L3+R3) para achar a causa da piscada.
5. Meta: base ≤ 33 ms por lista = 30 fps estáveis em área aberta.

## settings.txt atual
`fps=30, async_pipelines=1, present_mode=fifo, render_scale=0.75, shadow_size=1024, skip_depth_prepass=1, texture_drop=2, trim_targets=1, tight_barriers=1, diag_cycle=1` (ponha `diag_cycle=0` para jogar).

## Como compilar
Suba `dsr-native-main/` num repositório GitHub e baixe o APK em Actions → Artifacts. Arquivos do jogo ficam em `Download/DSRNative/game/` (não suba).
