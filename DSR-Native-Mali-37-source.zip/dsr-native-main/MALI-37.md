# DSR Native — Mali-37 (source experimental)

## O que muda
- Preserva Mali-36: `tight_barriers` + `barrier_dst_fragment`.
- Adiciona `skip_post_320`, desligado por padrão. Ativado, descarta draws sem depth para alvos de cor até 320x180.
- Log: `Mali-37: skipping <=320x180 post-process draws`.

## Teste A/B
1. Compile este código no GitHub Actions. Este ZIP é fonte, não APK.
2. Faça backup de `settings.txt`.
3. Use `tight_barriers = 1` e `barrier_dst_fragment = 1`.
4. Compare a mesma cena/câmera por 30–60 s:
   - `skip_post_320 = 0` (baseline)
   - `skip_post_320 = 1` (diagnóstico)
5. Compare `GPU busy ... ms per list`. Volte a `0` para jogar normalmente.

## Limitações
- Não funde passes: descarta draws para medir o potencial de ganho.
- Pode remover exposição, tone mapping, blur ou efeitos essenciais; imagem pode ficar escura/errada.
- Não garante 30 FPS e não foi compilado nem validado no aparelho nesta entrega.
