#pragma once
#include <atomic>
#include <cstdint>

namespace dsr::video {
// Platform layer: the surface the game renders into (ANativeWindow* on Android). May change when the
// app is paused/resumed; the NVN backend re-reads it when (re)creating the swapchain.
void SetNativeWindow(void* window);
void* GetNativeWindow();
// Frames the game has presented so far (the on-screen FPS meter reads this).
std::atomic<uint64_t>& FramesPresented();
}  // namespace dsr::video
