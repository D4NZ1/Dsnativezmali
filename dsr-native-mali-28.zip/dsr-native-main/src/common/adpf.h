#pragma once
// Android Dynamic Performance Framework (APerformanceHint, API 33+, resolved at run time so minSdk 29 still loads).
// The frame interval is reported against a 30 fps target: while the game runs below it the system raises CPU (and,
// on some devices, GPU) clocks, the same boost a touch on the screen gives; at or above it the system relaxes again.
#include <cstddef>
#include <cstdint>

#ifdef __ANDROID__
#include <dlfcn.h>
#include <time.h>
#include <unistd.h>

#include <algorithm>
#include <chrono>
#include <mutex>
#include <vector>

#include "common/log.h"

namespace dsr::adpf {

struct State {
    std::mutex m;
    void* (*get_manager)() = nullptr;
    void* (*create)(void*, const int32_t*, size_t, int64_t) = nullptr;
    void (*close)(void*) = nullptr;
    int (*report)(void*, int64_t) = nullptr;
    // ADPF 2 (API 35+): CPU and GPU durations of the cycle, and a hint that the GPU load went up (API 36+)
    int (*report2)(void*, void*) = nullptr;
    void* (*wd_create)() = nullptr;
    void (*wd_release)(void*) = nullptr;
    void (*wd_start)(void*, int64_t) = nullptr;
    void (*wd_total)(void*, int64_t) = nullptr;
    void (*wd_cpu)(void*, int64_t) = nullptr;
    void (*wd_gpu)(void*, int64_t) = nullptr;
    int (*notify_increase)(void*, bool, bool, const char*) = nullptr;
    void* wd = nullptr;
    uint64_t frames = 0, last_cpu_ns = 0, last_notify_frame = 0;
    int report2_rc = 0, notify_rc = 0;
    void* mgr = nullptr;
    void* session = nullptr;
    bool tried = false;
    std::vector<int32_t> tids;
    std::chrono::steady_clock::time_point last{};
    int64_t target_ns = 33333333;
};

inline State& S() {
    static State s;
    return s;
}

inline void Ensure(State& s) {
    if (s.tried) return;
    s.tried = true;
    void* h = dlopen("libandroid.so", RTLD_NOW);
    if (!h) return;
    s.get_manager = reinterpret_cast<void* (*)()>(dlsym(h, "APerformanceHint_getManager"));
    s.create = reinterpret_cast<void* (*)(void*, const int32_t*, size_t, int64_t)>(dlsym(h, "APerformanceHint_createSession"));
    s.close = reinterpret_cast<void (*)(void*)>(dlsym(h, "APerformanceHint_closeSession"));
    s.report = reinterpret_cast<int (*)(void*, int64_t)>(dlsym(h, "APerformanceHint_reportActualWorkDuration"));
    s.report2 = reinterpret_cast<int (*)(void*, void*)>(dlsym(h, "APerformanceHint_reportActualWorkDuration2"));
    s.wd_create = reinterpret_cast<void* (*)()>(dlsym(h, "AWorkDuration_create"));
    s.wd_release = reinterpret_cast<void (*)(void*)>(dlsym(h, "AWorkDuration_release"));
    s.wd_start = reinterpret_cast<void (*)(void*, int64_t)>(dlsym(h, "AWorkDuration_setWorkPeriodStartTimestampNanos"));
    s.wd_total = reinterpret_cast<void (*)(void*, int64_t)>(dlsym(h, "AWorkDuration_setActualTotalDurationNanos"));
    s.wd_cpu = reinterpret_cast<void (*)(void*, int64_t)>(dlsym(h, "AWorkDuration_setActualCpuDurationNanos"));
    s.wd_gpu = reinterpret_cast<void (*)(void*, int64_t)>(dlsym(h, "AWorkDuration_setActualGpuDurationNanos"));
    s.notify_increase = reinterpret_cast<int (*)(void*, bool, bool, const char*)>(dlsym(h, "APerformanceHint_notifyWorkloadIncrease"));
    if (s.get_manager && s.create && s.close && s.report) s.mgr = s.get_manager();
    const bool two = s.report2 && s.wd_create && s.wd_release && s.wd_start && s.wd_total && s.wd_cpu && s.wd_gpu;
    if (two) s.wd = s.wd_create();
    LOGI("adpf", "performance hints %s; CPU+GPU durations (ADPF 2): %s; workload increase hint: %s",
         s.mgr ? "available" : "not available on this device", (two && s.wd) ? "yes" : "no", s.notify_increase ? "yes" : "no");
}

// Adds the calling thread to the hint session (once per thread).
inline void AddCurrentThread() {
    State& s = S();
    std::lock_guard<std::mutex> lk(s.m);
    Ensure(s);
    if (!s.mgr) return;
    const int32_t tid = int32_t(gettid());
    if (std::find(s.tids.begin(), s.tids.end(), tid) != s.tids.end()) return;
    s.tids.push_back(tid);
    if (s.session) s.close(s.session);
    s.session = s.create(s.mgr, s.tids.data(), s.tids.size(), s.target_ns);
    LOGI("adpf", "hint session with %zu thread(s): %s", s.tids.size(), s.session ? "ok" : "refused");
}

// Call once per presented frame from the same thread. gpu_ns: GPU time of the finished frame(s), 0 if unknown.
inline void FrameDone(int64_t gpu_ns = 0) {
    State& s = S();
    std::lock_guard<std::mutex> lk(s.m);
    if (!s.session) return;
    const auto now = std::chrono::steady_clock::now();
    timespec ts{};
    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts);
    const uint64_t cpu_now = uint64_t(ts.tv_sec) * 1000000000ull + uint64_t(ts.tv_nsec);
    if (s.last.time_since_epoch().count() != 0) {
        int64_t total = std::chrono::duration_cast<std::chrono::nanoseconds>(now - s.last).count();
        total = std::clamp<int64_t>(total, 1000000, 500000000);
        int64_t cpu = std::clamp<int64_t>(int64_t(cpu_now - s.last_cpu_ns), 1000000, total);  // CPU time this thread used
        s.frames++;
        if (s.wd && gpu_ns > 0) {
            const int64_t gpu = std::clamp<int64_t>(gpu_ns, 1000000, 500000000);
            s.wd_start(s.wd, std::chrono::duration_cast<std::chrono::nanoseconds>(s.last.time_since_epoch()).count());
            s.wd_total(s.wd, total);
            s.wd_cpu(s.wd, cpu);
            s.wd_gpu(s.wd, gpu);
            s.report2_rc = s.report2(s.session, s.wd);
            // GPU over budget for a second: tell the system the GPU load went up (rate limited by the framework)
            if (s.notify_increase && gpu > s.target_ns && s.frames - s.last_notify_frame >= 30) {
                s.last_notify_frame = s.frames;
                s.notify_rc = s.notify_increase(s.session, false, true, "gpu-heavy-view");
            }
        } else {
            s.report(s.session, total);
        }
        if (s.frames == 120 || s.frames % 1800 == 0)
            LOGI("adpf", "frame %llu: total %.1f ms, cpu %.1f ms, gpu %.1f ms, report2 rc %d, notify rc %d",
                 (unsigned long long)s.frames, total / 1e6, cpu / 1e6, gpu_ns / 1e6, s.report2_rc, s.notify_rc);
    }
    s.last = now;
    s.last_cpu_ns = cpu_now;
}

}  // namespace dsr::adpf
#else
namespace dsr::adpf {
inline void AddCurrentThread() {}
inline void FrameDone() {}
}  // namespace dsr::adpf
#endif
