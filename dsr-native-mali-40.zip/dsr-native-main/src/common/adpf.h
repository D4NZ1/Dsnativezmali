#pragma once
// Android Dynamic Performance Framework (APerformanceHint, API 33+, resolved at run time so minSdk 29 still loads).
// The frame interval is reported against a 30 fps target: while the game runs below it the system raises CPU (and,
// on some devices, GPU) clocks, the same boost a touch on the screen gives; at or above it the system relaxes again.
#include <cstddef>
#include <cstdint>

#ifdef __ANDROID__
#include <dlfcn.h>
#include <time.h>
#include <unistd.h>

#include <algorithm>
#include <chrono>
#include <mutex>
#include <vector>

#include "common/log.h"

namespace dsr::adpf {

struct State {
    std::mutex m;
    void* (*get_manager)() = nullptr;
    void* (*create)(void*, const int32_t*, size_t, int64_t) = nullptr;
    void (*close)(void*) = nullptr;
    int (*report)(void*, int64_t) = nullptr;
    // API 35+: let Android prefer power-efficient CPU cores when frame-time headroom is consistently large.
    int (*prefer_efficiency)(void*, bool) = nullptr;
    // ADPF 2 (API 35+): CPU and GPU durations of the cycle, and a hint that the GPU load went up (API 36+)
    int (*report2)(void*, void*) = nullptr;
    void* (*wd_create)() = nullptr;
    void (*wd_release)(void*) = nullptr;
    void (*wd_start)(void*, int64_t) = nullptr;
    void (*wd_total)(void*, int64_t) = nullptr;
    void (*wd_cpu)(void*, int64_t) = nullptr;
    void (*wd_gpu)(void*, int64_t) = nullptr;
    int (*notify_increase)(void*, bool, bool, const char*) = nullptr;
    void* wd = nullptr;
    uint64_t frames = 0, last_cpu_ns = 0, last_notify_frame = 0;
    int report2_rc = 0, notify_rc = 0;
    bool efficiency_requested = true, efficiency_on = false, efficiency_api_failed = false;
    int efficiency_frames = 0, efficiency_easy_runs = 0;
    int64_t efficiency_sum_ns = 0, efficiency_max_ns = 0;
    void* mgr = nullptr;
    void* session = nullptr;
    bool tried = false;
    std::vector<int32_t> tids;
    std::chrono::steady_clock::time_point last{};
    int64_t target_ns = 33333333;
    // ADPF session config (API 36+): graphics pipeline flag and the game's window attached to the session
    void* (*cfg_create)() = nullptr;
    int (*cfg_release)(void*) = nullptr;
    int (*cfg_tids)(void*, const int32_t*, size_t) = nullptr;
    int (*cfg_target)(void*, int64_t) = nullptr;
    int (*cfg_graphics)(void*, bool) = nullptr;
    int (*cfg_surfaces)(void*, void**, int) = nullptr;
    int (*create_cfg)(void*, void*, void**) = nullptr;
    bool graphics = false;
    void* window = nullptr;
};

inline State& S() {
    static State s;
    return s;
}

inline void Ensure(State& s) {
    if (s.tried) return;
    s.tried = true;
    void* h = dlopen("libandroid.so", RTLD_NOW);
    if (!h) return;
    s.get_manager = reinterpret_cast<void* (*)()>(dlsym(h, "APerformanceHint_getManager"));
    s.create = reinterpret_cast<void* (*)(void*, const int32_t*, size_t, int64_t)>(dlsym(h, "APerformanceHint_createSession"));
    s.close = reinterpret_cast<void (*)(void*)>(dlsym(h, "APerformanceHint_closeSession"));
    s.report = reinterpret_cast<int (*)(void*, int64_t)>(dlsym(h, "APerformanceHint_reportActualWorkDuration"));
    s.prefer_efficiency = reinterpret_cast<int (*)(void*, bool)>(dlsym(h, "APerformanceHint_setPreferPowerEfficiency"));
    s.report2 = reinterpret_cast<int (*)(void*, void*)>(dlsym(h, "APerformanceHint_reportActualWorkDuration2"));
    s.wd_create = reinterpret_cast<void* (*)()>(dlsym(h, "AWorkDuration_create"));
    s.wd_release = reinterpret_cast<void (*)(void*)>(dlsym(h, "AWorkDuration_release"));
    s.wd_start = reinterpret_cast<void (*)(void*, int64_t)>(dlsym(h, "AWorkDuration_setWorkPeriodStartTimestampNanos"));
    s.wd_total = reinterpret_cast<void (*)(void*, int64_t)>(dlsym(h, "AWorkDuration_setActualTotalDurationNanos"));
    s.wd_cpu = reinterpret_cast<void (*)(void*, int64_t)>(dlsym(h, "AWorkDuration_setActualCpuDurationNanos"));
    s.wd_gpu = reinterpret_cast<void (*)(void*, int64_t)>(dlsym(h, "AWorkDuration_setActualGpuDurationNanos"));
    s.notify_increase = reinterpret_cast<int (*)(void*, bool, bool, const char*)>(dlsym(h, "APerformanceHint_notifyWorkloadIncrease"));
    s.cfg_create = reinterpret_cast<void* (*)()>(dlsym(h, "ASessionCreationConfig_create"));
    s.cfg_release = reinterpret_cast<int (*)(void*)>(dlsym(h, "ASessionCreationConfig_release"));
    s.cfg_tids = reinterpret_cast<int (*)(void*, const int32_t*, size_t)>(dlsym(h, "ASessionCreationConfig_setTids"));
    s.cfg_target = reinterpret_cast<int (*)(void*, int64_t)>(dlsym(h, "ASessionCreationConfig_setTargetWorkDurationNanos"));
    s.cfg_graphics = reinterpret_cast<int (*)(void*, bool)>(dlsym(h, "ASessionCreationConfig_setGraphicsPipeline"));
    s.cfg_surfaces = reinterpret_cast<int (*)(void*, void**, int)>(dlsym(h, "ASessionCreationConfig_setNativeSurfaces"));
    s.create_cfg = reinterpret_cast<int (*)(void*, void*, void**)>(dlsym(h, "APerformanceHint_createSessionUsingConfig"));
    if (s.get_manager && s.create && s.close && s.report) s.mgr = s.get_manager();
    const bool two = s.report2 && s.wd_create && s.wd_release && s.wd_start && s.wd_total && s.wd_cpu && s.wd_gpu;
    if (two) s.wd = s.wd_create();
    LOGI("adpf", "performance hints %s; CPU+GPU durations (ADPF 2): %s; workload increase hint: %s; power-efficiency preference (API 35+): %s",
         s.mgr ? "available" : "not available on this device", (two && s.wd) ? "yes" : "no",
         s.notify_increase ? "yes" : "no", s.prefer_efficiency ? "available" : "unavailable");
}

// (Re)creates the hint session for the threads added so far. With `graphics` set and the API present (Android 16+)
// the session is made from a config: graphics-pipeline flag and the game's window attached. Falls back to the plain
// session when that is not available or refused.
inline void MakeSession(State& s) {
    if (s.session) {
        s.close(s.session);
        s.session = nullptr;
    }
    s.efficiency_on = false;
    s.efficiency_frames = s.efficiency_easy_runs = 0;
    s.efficiency_sum_ns = s.efficiency_max_ns = 0;
    if (s.tids.empty()) return;
    if (s.graphics && s.cfg_create && s.cfg_release && s.cfg_tids && s.cfg_target && s.cfg_graphics && s.create_cfg) {
        void* c = s.cfg_create();
        if (c) {
            s.cfg_tids(c, s.tids.data(), s.tids.size());
            s.cfg_target(c, s.target_ns);
            const int rg = s.cfg_graphics(c, true);
            int rs = -1;
            if (s.window && s.cfg_surfaces) {
                void* surfaces[1] = {s.window};
                rs = s.cfg_surfaces(c, surfaces, 1);
            }
            void* out = nullptr;
            const int rc = s.create_cfg(s.mgr, c, &out);
            s.cfg_release(c);
            LOGI("adpf", "graphics session (flag rc %d, window rc %d): createSessionUsingConfig rc %d, %s", rg, rs, rc,
                 out ? "ok" : "refused");
            if (out) {
                s.session = out;
                if (s.prefer_efficiency) {
                    const int rc = s.prefer_efficiency(s.session, false);
                    if (rc != 0) s.efficiency_api_failed = true;
                }
                return;
            }
        }
    } else if (s.graphics) {
        LOGI("adpf", "graphics session: API not available (needs Android 16+), using the plain session");
    }
    s.session = s.create(s.mgr, s.tids.data(), s.tids.size(), s.target_ns);
    if (s.session && s.prefer_efficiency) {
        const int rc = s.prefer_efficiency(s.session, false);
        if (rc != 0) s.efficiency_api_failed = true;
    }
    LOGI("adpf", "hint session with %zu thread(s), target %.1f ms: %s; power-efficiency API: %s", s.tids.size(), s.target_ns / 1e6,
         s.session ? "ok" : "refused", s.prefer_efficiency && !s.efficiency_api_failed ? "available" : "unavailable");
}

// Settings of the hint session (adpf_target_ms, adpf_graphics) and the game's window. May be called after threads
// were added: the session is then recreated.
inline void Configure(float target_ms, bool graphics, void* window, bool efficiency = true) {
    State& s = S();
    std::lock_guard<std::mutex> lk(s.m);
    Ensure(s);
    const int64_t t = int64_t(std::clamp(target_ms, 10.0f, 40.0f) * 1e6f);
    const bool changed = t != s.target_ns || graphics != s.graphics || window != s.window;
    s.target_ns = t;
    s.graphics = graphics;
    s.window = window;
    s.efficiency_requested = efficiency;
    if (!efficiency && s.session && s.efficiency_on && s.prefer_efficiency && !s.efficiency_api_failed) {
        const int rc = s.prefer_efficiency(s.session, false);
        if (rc == 0) LOGI("adpf", "power-efficient CPU preference disabled by settings");
        s.efficiency_on = false;
    }
    if (changed && s.mgr && !s.tids.empty()) MakeSession(s);
}

// Adds the calling thread to the hint session (once per thread).
inline void AddCurrentThread() {
    State& s = S();
    std::lock_guard<std::mutex> lk(s.m);
    Ensure(s);
    if (!s.mgr) return;
    const int32_t tid = int32_t(gettid());
    if (std::find(s.tids.begin(), s.tids.end(), tid) != s.tids.end()) return;
    s.tids.push_back(tid);
    MakeSession(s);
}

// MHGU-style hysteresis: only ask for power-efficient CPU cores after five consecutive 60-frame
// windows with average frame work below 50% of target and no frame above 80%. Revert immediately
// when a window averages above 70% or contains a frame over target. This avoids oscillation and
// never trades away CPU headroom in GPU-heavy scenes that are already missing the frame budget.
inline void UpdateEfficiency(State& s, int64_t work_ns) {
    if (!s.efficiency_requested || !s.session || !s.prefer_efficiency || s.efficiency_api_failed) return;
    s.efficiency_sum_ns += work_ns;
    s.efficiency_max_ns = std::max(s.efficiency_max_ns, work_ns);
    if (++s.efficiency_frames < 60) return;
    const int64_t avg = s.efficiency_sum_ns / s.efficiency_frames;
    const bool tight = avg > s.target_ns * 7 / 10 || s.efficiency_max_ns > s.target_ns;
    const bool easy = avg < s.target_ns / 2 && s.efficiency_max_ns < s.target_ns * 8 / 10;
    s.efficiency_easy_runs = easy ? s.efficiency_easy_runs + 1 : 0;
    const bool want = !tight && (s.efficiency_on || s.efficiency_easy_runs >= 5);
    s.efficiency_frames = 0;
    s.efficiency_sum_ns = s.efficiency_max_ns = 0;
    if (want == s.efficiency_on) return;
    const int rc = s.prefer_efficiency(s.session, want);
    if (rc == 0) {
        s.efficiency_on = want;
        if (want) s.efficiency_easy_runs = 0;
        LOGI("adpf", "power-efficient CPU preference %s (60-frame window, target %.1f ms)",
             want ? "enabled" : "disabled", s.target_ns / 1e6);
    } else {
        s.efficiency_api_failed = true;
        LOGI("adpf", "power-efficiency request failed (%d); adaptive preference disabled", rc);
    }
}

// Call once per presented frame from the same thread. gpu_ns: GPU time of the finished frame(s), 0 if unknown.
inline void FrameDone(int64_t gpu_ns = 0) {
    State& s = S();
    std::lock_guard<std::mutex> lk(s.m);
    if (!s.session) return;
    const auto now = std::chrono::steady_clock::now();
    timespec ts{};
    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &ts);
    const uint64_t cpu_now = uint64_t(ts.tv_sec) * 1000000000ull + uint64_t(ts.tv_nsec);
    if (s.last.time_since_epoch().count() != 0) {
        int64_t total = std::chrono::duration_cast<std::chrono::nanoseconds>(now - s.last).count();
        total = std::clamp<int64_t>(total, 1000000, 500000000);
        int64_t cpu = std::clamp<int64_t>(int64_t(cpu_now - s.last_cpu_ns), 1000000, total);  // CPU time this thread used
        s.frames++;
        if (s.wd && gpu_ns > 0) {
            const int64_t gpu = std::clamp<int64_t>(gpu_ns, 1000000, 500000000);
            s.wd_start(s.wd, std::chrono::duration_cast<std::chrono::nanoseconds>(s.last.time_since_epoch()).count());
            s.wd_total(s.wd, total);
            s.wd_cpu(s.wd, cpu);
            s.wd_gpu(s.wd, gpu);
            s.report2_rc = s.report2(s.session, s.wd);
            // GPU over budget for a second: tell the system the GPU load went up (rate limited by the framework)
            if (s.notify_increase && gpu > s.target_ns && s.frames - s.last_notify_frame >= 30) {
                s.last_notify_frame = s.frames;
                s.notify_rc = s.notify_increase(s.session, false, true, "gpu-heavy-view");
            }
        } else {
            s.report(s.session, total);
        }
        UpdateEfficiency(s, total);
        if (s.frames == 120 || s.frames % 1800 == 0)
            LOGI("adpf", "frame %llu: total %.1f ms, cpu %.1f ms, gpu %.1f ms, report2 rc %d, notify rc %d",
                 (unsigned long long)s.frames, total / 1e6, cpu / 1e6, gpu_ns / 1e6, s.report2_rc, s.notify_rc);
    }
    s.last = now;
    s.last_cpu_ns = cpu_now;
}

}  // namespace dsr::adpf
#else
namespace dsr::adpf {
inline void AddCurrentThread() {}
inline void FrameDone(int64_t = 0) {}
inline void Configure(float, bool, void*, bool = true) {}
}  // namespace dsr::adpf
#endif
