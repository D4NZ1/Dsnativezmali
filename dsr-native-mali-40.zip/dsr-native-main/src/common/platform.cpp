#include "common/platform.h"

#include <atomic>
#include <chrono>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#if defined(__linux__)
#include <pthread.h>
#include <sched.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <cstdio>
#endif

#include "common/log.h"
#include "runtime/runtime.h"

namespace dsr::platform {
namespace {
std::atomic<CreateUserFileFn> g_create{nullptr};
}
void PreferFastCores(const char* who) {
#if defined(__ANDROID__)
    thread_local bool done = false;
    if (done) return;
    done = true;
    if (!dsr::GetRuntime().config.fast_cores) return;
    static cpu_set_t set;
    static int count = -1;
    static std::once_flag once;
    static std::string list;
    std::call_once(once, [] {
        long khz[32] = {}, lowest = 0, highest = 0;
        for (int cpu = 0; cpu < 32; cpu++) {
            char path[96];
            snprintf(path, sizeof(path), "/sys/devices/system/cpu/cpu%d/cpufreq/cpuinfo_max_freq", cpu);
            if (FILE* f = fopen(path, "r")) {
                if (fscanf(f, "%ld", &khz[cpu]) != 1) khz[cpu] = 0;
                fclose(f);
            }
            if (khz[cpu] > 0 && (!lowest || khz[cpu] < lowest)) lowest = khz[cpu];
            if (khz[cpu] > highest) highest = khz[cpu];
        }
        CPU_ZERO(&set);
        count = 0;
        if (!lowest || lowest == highest) return;  // one kind of core: nothing to avoid
        for (int cpu = 0; cpu < 32; cpu++)
            if (khz[cpu] > lowest) {
                CPU_SET(cpu, &set);
                list += " " + std::to_string(cpu);
                count++;
            }
    });
    if (count <= 0) return;
    const int r = sched_setaffinity(0, sizeof(set), &set);
    LOGI("platform", "%s kept on CPUs%s: %s", who, list.c_str(), r == 0 ? "ok" : "refused");
    // Android may reset the affinity (cpuset changes, thermal core control): a watchdog restores it every second,
    // so the busy threads do not end up on the efficiency cores for the rest of the session.
    static std::mutex wm;
    static std::vector<std::pair<pid_t, std::string>> watched;
    static std::once_flag wonce;
    {
        std::lock_guard<std::mutex> lk(wm);
        watched.emplace_back(pid_t(syscall(SYS_gettid)), who);
    }
    std::call_once(wonce, [] {
        std::thread([] {
            pthread_setname_np(pthread_self(), "dsr-affinity");
            int restores = 0;
            for (;;) {
                std::this_thread::sleep_for(std::chrono::seconds(1));
                std::lock_guard<std::mutex> lk(wm);
                for (size_t i = 0; i < watched.size();) {
                    cpu_set_t cur;
                    if (sched_getaffinity(watched[i].first, sizeof(cur), &cur) != 0) {  // thread gone
                        watched.erase(watched.begin() + long(i));
                        continue;
                    }
                    if (!CPU_EQUAL(&cur, &set)) {
                        const int rr = sched_setaffinity(watched[i].first, sizeof(set), &set);
                        if (++restores <= 5 || restores % 50 == 0)
                            LOGI("platform", "%s: CPU affinity reset by the system, restored %d times (%s)",
                                 watched[i].second.c_str(), restores, rr == 0 ? "ok" : "refused");
                    }
                    i++;
                }
            }
        }).detach();
    });
#else
    (void)who;
#endif
}
void SetCreateUserFile(CreateUserFileFn fn) { g_create.store(fn); }
int CreateUserFile(const char* name, const char* mime_type) {
    CreateUserFileFn fn = g_create.load();
    return fn ? fn(name, mime_type) : -1;
}
namespace {
std::atomic<RequestTextFn> g_request_text{nullptr};
std::mutex g_text_mutex;
bool g_text_ready = false, g_text_ok = false;
std::u16string g_text;
}  // namespace
void SetRequestText(RequestTextFn fn) { g_request_text.store(fn); }
bool RequestText(const char* title, const std::u16string& initial, int max_length) {
    {
        std::lock_guard<std::mutex> lk(g_text_mutex);
        g_text_ready = false;
    }
    RequestTextFn fn = g_request_text.load();
    return fn && fn(title, initial, max_length);
}
void DeliverText(bool ok, const std::u16string& text) {
    std::lock_guard<std::mutex> lk(g_text_mutex);
    g_text_ready = true;
    g_text_ok = ok;
    g_text = text;
}
bool TakeText(bool* ok, std::u16string* text) {
    std::lock_guard<std::mutex> lk(g_text_mutex);
    if (!g_text_ready) return false;
    g_text_ready = false;
    *ok = g_text_ok;
    *text = g_text;
    return true;
}
}  // namespace dsr::platform

namespace dsr::platform {
bool NativeCodeOptimized() {
#ifdef __OPTIMIZE__
    return true;
#else
    return false;
#endif
}
}  // namespace dsr::platform
