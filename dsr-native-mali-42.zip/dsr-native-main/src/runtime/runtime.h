#pragma once
// Process-wide state for the native runtime: loaded modules, configured paths, guest allocator hooks.

#include <cstdint>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "loader/module.h"
#include "loader/nso.h"

namespace dsr {

struct RuntimeConfig {
    std::string game_dir;     // directory holding exefs/ and the romfs contents (dvdbnd*.bdt, ...)
    std::string save_dir;     // writable directory for save data
    std::string cache_dir;    // writable directory for caches (shaders etc.)
    bool dry_run = false;     // map + relocate + bind only, never execute guest code
    bool abort_on_unimplemented = false;
    bool docked = false;      // nn::oe::GetOperationMode: false = handheld (720p), true = console
    std::string language = "en-US";
    // User settings (settings.txt next to the game folder on Android).
    int target_fps = 60;          // presentation pace: 30 (the Switch rate) or 60
    bool async_pipelines = true;  // compile new GPU pipelines off the render thread (no hitch; the draw waits a frame)
    bool auto_capture = false;    // diagnostics: save a few frame captures automatically during play
    bool profile = true;          // diagnostics: sampling CPU profile of the busy threads, logged every 10 s
    float gamma = 1.0f;           // extra display gamma applied through the game's brightness ramp (> 1 lifts shadows)
    std::string present_mode = "mailbox";  // swapchain present mode: mailbox, fifo, fifo_relaxed, immediate (FIFO if unsupported)
    bool audio_smooth = false;  // release audio buffers at a smoothed pace (experiment; movies were not timed by it)
    bool fast_cores = true;  // keep the game's frame-critical threads off the efficiency cores
    bool record_thread = true;  // record Vulkan commands on a second thread (draw preparation stays on the render thread)
    bool pin_render_thread = false;  // keep the render thread on the fastest CPU core(s) (slower on 8 Gen 2: off)
    float exposure = 1.37f;       // scales the tone-mapping exposure (1.0 = as the game draws it)
    int max_anisotropy = 1;       // caps the game's anisotropic filtering: 0 = as the game asks, 1 = off, 2/4/8 = cap
    int shadow_size = 0;  // settings: shadow_size: 0 = as the game asks; 512-1536 = allocate the 2048x2048 shadow map at this size
    std::vector<uint32_t> skip_vs;  // settings: skip_vs: first 8 hex digits of vertex shader hashes whose draws are dropped (diagnostic)
    std::vector<std::pair<int, int>> skip_targets;  // settings: skip_targets (mali-42): colour target sizes (WxH, game size) whose draws are all dropped, so those passes never start (experiment)
    std::vector<uint32_t> skip_shaders;  // settings: skip_shaders: first 8 hex digits of fragment shader hashes whose draws are dropped (experiment)
    bool diag_tiny_scissor = false;  // settings: diag_tiny_scissor: diagnostic. Opaque colour draws of the main scene get a 1x1 scissor (vertex work stays, fragment work goes)
    bool diag_world = false;  // settings: diag_world: like diag_cycle, but the fragment shaders tested are the ones drawing the 3D world (large targets, depth test on, some colour channel written), not the small post-process targets
    bool diag_cycle = false;  // settings: diag_cycle: diagnostic. L3+R3 starts an automatic A/B run: the backend alternates between skip sets every ~8 s and logs GPU ms per list of each
    bool skip_depth_prepass = false;  // settings: skip_depth_prepass: drop the depth-only pass of the full-screen scene (see Draw)
    float render_scale = 1.0f;    // settings: render_scale (0.5-1.0): full-screen 1280x720 targets are allocated and drawn at this fraction per axis
    int boost_gamemode = 0;       // settings: boost_gamemode (clock test): 1 = tell Android's GameManager the game is in uninterrupted gameplay (API 34+)
    int boost_sustained = 0;      // settings: boost_sustained (clock test): 1 = Window.setSustainedPerformanceMode (may LOWER the clocks on some devices)
    float adpf_target_ms = 33.3f; // settings: adpf_target_ms (10-40): target frame time of the performance-hint session; a lower target makes the system see "behind" and raise the clocks
    int adpf_graphics = 0;        // settings: adpf_graphics (clock test, API 36+): 1 = create the hint session with the graphics-pipeline flag and the game's window attached
    int frame_rate_hint = 0;      // settings: frame_rate_hint (clock test): 0 = tell Android the window runs at `fps`, 1 = do not call setFrameRate, 2 = say 60 fps
    bool clock_log = true;        // settings: clock_log: log the GPU/CPU clocks every 10 s when /sys lets the app read them
    bool adpf = true;             // settings: adpf: report the frame time to Android (performance hints) so the clocks rise below 30 fps like they do while the screen is touched
    int skip_writeback = 0;       // settings: skip_writeback (experiment): 0 = copy every small render target back to game memory after each list, 1 = only R32F luminance (NVN format 10: what auto exposure reads), 2 = none (picture gets darker)
    bool dyn_res = false;         // settings: dyn_res: dynamic resolution. render_scale becomes the ceiling (targets are allocated at it); the drawn area shrinks towards dyn_min when the GPU is slow
    float dyn_min = 0.6f;         // settings: dyn_min (0.4-1.0): lowest dynamic render scale
    float dyn_target_ms = 31.0f;  // settings: dyn_target_ms (16-60): GPU ms per frame the controller aims for (30 fps = 33.3)
    float live_scale = 1.0f;      // runtime (written by the Vulkan backend): scale of the area drawn now, <= render_scale
    bool viewport_test = false;   // diagnostics: draw full-resolution passes into a quarter of the area (image garbled; measures if the GPU is pixel-bound)
    int present_test = 0;         // diagnostics: 1 = ignore the game, present solid alternating colours; 2 = probe pixels of game frame and swapchain (log)
    bool debug_sync = false;      // diagnostics: wait for the GPU to finish every frame (flicker test; slow)
    bool tight_barriers = true;   // layout transitions wait only for the stages that use the image (not ALL_COMMANDS both ways)
    bool barrier_dst_fragment = false;  // settings: barrier_dst_fragment (experiment, needs tight_barriers): a transition to SHADER_READ_ONLY blocks only the fragment stage that follows, not the vertex stage too, so the next pass's vertex/binning work can overlap the previous pass's fragment work. Risk: a vertex shader that samples that texture
    bool trim_targets = true;     // leave render targets a draw does not write out of its pass (less tile memory traffic)
    int texture_drop = 1;         // BC textures decoded on the CPU (GPUs without BC): skip the top mip level(s) of big
                                  // ones (0 = keep all; 1 = 2048+ lose one level; 2 = also 1024 lose one, 2048+ two)
};

struct Runtime {
    RuntimeConfig config;
    loader::NsoImage main_nso;
    loader::NsoImage sdk_nso;          // parsed (not mapped) to source data constants such as nn::util tables
    bool have_sdk = false;
    loader::Module main;

    // Guest allocator entry points exported by main (the game replaces malloc & co).
    uintptr_t guest_malloc = 0, guest_free = 0, guest_calloc = 0, guest_realloc = 0, guest_aligned_alloc = 0;
};

Runtime& GetRuntime();

// Loads main (and optionally sdk for data), binds imports. Returns false with *err on failure.
bool LoadGame(const RuntimeConfig& cfg, std::string* err);

// Runs the guest startup sequence (nninitStartup, static constructors, nnMain) on a dedicated
// thread sized like the Switch main thread. Blocks until nnMain returns.
int RunGame();

// Patches engine functions of this game build (log/panic output, frame rate). Called by LoadGame.
void InstallGameHooks();
// The game's current per-frame time step in seconds (1/30 unless the 60 fps patches are active).
float GameFrameTime();
// The game's movie player shows one video frame per game frame (30 fps on the Switch): while a video
// plays, frames are paced at 30 instead of the configured rate (at 60 the video ran at double speed and
// stopped every few frames to wait for its sound).
void SetMoviePlaying(bool playing);
int FrameRateNow();  // the configured rate (30..60), or 30 while a movie plays

// Prints an import binding summary (implemented / unimplemented / data) to the log.
void LogImportReport(bool list_unimplemented);

// Guest heap helpers used by HLE code that must hand memory to the game (strdup, operator new, ...).
void* GuestMalloc(size_t size);
void GuestFree(void* p);
void* GuestAlignedAlloc(size_t align, size_t size);

}  // namespace dsr
