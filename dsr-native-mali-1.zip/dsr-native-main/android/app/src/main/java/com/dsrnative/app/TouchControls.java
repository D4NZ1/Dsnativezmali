package com.dsrnative.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.hardware.input.InputManager;
import android.util.SparseIntArray;
import android.view.HapticFeedbackConstants;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;

/**
 * On-screen gamepad drawn over the game. Left: movement stick, d-pad, L3. Right: face buttons, R1/R2, R3 (lock-on),
 * and a floating camera stick (drag anywhere in the middle-right area). The state goes to native code
 * (TouchControls.nativeTouchPad), which merges it with any physical controller. Hidden when a real gamepad is
 * connected.
 */
public class TouchControls extends View {
    // nn::hid::NpadButton bits (same as hle/input.h).
    private static final long A = 1L << 0, B = 1L << 1, X = 1L << 2, Y = 1L << 3, L3 = 1L << 4, R3 = 1L << 5,
            L = 1L << 6, R = 1L << 7, ZL = 1L << 8, ZR = 1L << 9, PLUS = 1L << 10, MINUS = 1L << 11,
            LEFT = 1L << 12, UP = 1L << 13, RIGHT = 1L << 14, DOWN = 1L << 15;

    private static final int STICK_L = -1, CAMERA = -2;

    // NativeActivity dlopen()s libdsr.so itself, which does not register it with this class loader, so the JNI
    // lookup of nativeTouchPad fails (UnsatisfiedLinkError) until the library is also loaded the normal way.
    private static boolean sNativeOk = false;
    static {
        try {
            System.loadLibrary("dsr");
            sNativeOk = true;
        } catch (Throwable t) {
            android.util.Log.e("DSR/touch", "System.loadLibrary(dsr) failed", t);
        }
    }

    private static final class Ctl {
        final String label;
        final long bit;
        final float px, py, pr;  // position and radius as fractions (x of width, y of height, r of height)
        float cx, cy, r;
        Ctl(String label, long bit, float px, float py, float pr) {
            this.label = label; this.bit = bit; this.px = px; this.py = py; this.pr = pr;
        }
    }

    private final Ctl[] ctls = {
        new Ctl("A", A, 0.86f + 0.0f, 0.68f, 0.065f),   // adjusted in layout(): east
        new Ctl("B", B, 0.86f, 0.68f, 0.065f),          // south
        new Ctl("X", X, 0.86f, 0.68f, 0.065f),          // north
        new Ctl("Y", Y, 0.86f, 0.68f, 0.065f),          // west
        new Ctl("L", L, 0.07f, 0.27f, 0.055f),
        new Ctl("ZL", ZL, 0.07f, 0.10f, 0.055f),
        new Ctl("R", R, 0.93f, 0.27f, 0.055f),
        new Ctl("ZR", ZR, 0.93f, 0.10f, 0.055f),
        new Ctl("-", MINUS, 0.46f, 0.07f, 0.045f),
        new Ctl("+", PLUS, 0.54f, 0.07f, 0.045f),
        new Ctl("^", UP, 0.40f, 0.73f, 0.05f),
        new Ctl("v", DOWN, 0.40f, 0.95f, 0.05f),
        new Ctl("<", LEFT, 0.40f, 0.84f, 0.05f),   // shifted in layout()
        new Ctl(">", RIGHT, 0.40f, 0.84f, 0.05f),  // shifted in layout()
        new Ctl("L3", L3, 0.29f, 0.84f, 0.055f),
        new Ctl("R3", R3, 0.71f, 0.84f, 0.06f),
    };

    private final SparseIntArray owner = new SparseIntArray();  // pointer id -> ctl index, STICK_L or CAMERA
    private float lcx, lcy, lR;                // left stick centre and radius (px)
    private float camX0, camY0, camX1, camY1;  // camera zone
    private float camOx, camOy, camX, camY, camR;
    private float lsx, lsy, rsx, rsy;
    private long pressed;
    private long sentB = -1;
    private int sentLx, sentLy, sentRx, sentRy;
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG),
            text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    public TouchControls(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setColor(0xB4FFFFFF);
        fill.setStyle(Paint.Style.FILL);
        text.setColor(0xDCFFFFFF);
        text.setTextAlign(Paint.Align.CENTER);
        text.setFakeBoldText(true);
        setFocusable(false);
        setFocusableInTouchMode(false);
        refresh();
    }

    /** Hides the overlay while a physical gamepad is connected. */
    public void refresh() {
        boolean pad = false;
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice d = InputDevice.getDevice(id);
            if (d != null && !d.isVirtual() && (d.getSources() & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD)
                pad = true;
        }
        setVisibility(pad ? View.GONE : View.VISIBLE);
        if (pad) releaseAll();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        for (Ctl c : ctls) {
            c.cx = c.px * w;
            c.cy = c.py * h;
            c.r = c.pr * h;
        }
        // Face-button diamond (Nintendo layout: A east, B south, X north, Y west).
        float d = 0.15f * h;
        ctls[0].cx += d;
        ctls[2].cy -= d;
        ctls[1].cy += d;
        ctls[3].cx -= d;
        ctls[12].cx -= 0.075f * h * 1.0f + 0.04f * h;  // d-pad left
        ctls[13].cx += 0.075f * h * 1.0f + 0.04f * h;  // d-pad right
        lR = 0.17f * h;
        lcx = 0.15f * w;
        lcy = 0.66f * h;
        camX0 = 0.35f * w;
        camX1 = 0.72f * w;
        camY0 = 0.14f * h;
        camY1 = 0.70f * h;
        camR = 0.13f * h;
        text.setTextSize(0.05f * h);
        stroke.setStrokeWidth(Math.max(2f, 0.006f * h));
    }

    private void releaseAll() {
        owner.clear();
        pressed = 0;
        lsx = lsy = rsx = rsy = 0;
        send();
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        final int a = e.getActionMasked(), idx = e.getActionIndex();
        switch (a) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                down(e.getPointerId(idx), e.getX(idx), e.getY(idx));
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) move(e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                up(e.getPointerId(idx));
                break;
            case MotionEvent.ACTION_CANCEL:
                releaseAll();
                return true;
            default:
                break;
        }
        send();
        invalidate();
        return true;
    }

    private void down(int id, float x, float y) {
        int best = -1;
        float bestD = Float.MAX_VALUE;
        for (int i = 0; i < ctls.length; i++) {
            Ctl c = ctls[i];
            float dd = (float) Math.hypot(x - c.cx, y - c.cy);
            if (dd <= c.r * 1.3f && dd < bestD) { best = i; bestD = dd; }
        }
        if (best >= 0) {
            owner.put(id, best);
            pressed |= ctls[best].bit;
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            return;
        }
        if (Math.hypot(x - lcx, y - lcy) <= lR * 1.6f) {
            owner.put(id, STICK_L);
            move(id, x, y);
        } else if (x >= camX0 && x <= camX1 && y >= camY0 && y <= camY1) {
            owner.put(id, CAMERA);
            camOx = camX = x;
            camOy = camY = y;
            rsx = rsy = 0;
        }
    }

    private void move(int id, float x, float y) {
        int o = owner.get(id, Integer.MIN_VALUE);
        if (o == STICK_L) {
            float[] v = norm((x - lcx) / lR, (y - lcy) / lR);
            lsx = v[0];
            lsy = v[1];
        } else if (o == CAMERA) {
            camX = x;
            camY = y;
            float[] v = norm((x - camOx) / camR, (y - camOy) / camR);
            rsx = v[0];
            rsy = v[1];
        }
    }

    private void up(int id) {
        int o = owner.get(id, Integer.MIN_VALUE);
        if (o == Integer.MIN_VALUE) return;
        owner.delete(id);
        if (o == STICK_L) lsx = lsy = 0;
        else if (o == CAMERA) rsx = rsy = 0;
        else recomputePressed();
    }

    private void recomputePressed() {
        long p = 0;
        for (int i = 0; i < owner.size(); i++) {
            int o = owner.valueAt(i);
            if (o >= 0) p |= ctls[o].bit;
        }
        pressed = p;
    }

    /** Clamp to the unit circle with a small dead zone. */
    private static float[] norm(float dx, float dy) {
        float len = (float) Math.hypot(dx, dy);
        if (len > 1f) { dx /= len; dy /= len; len = 1f; }
        if (len < 0.12f) return new float[] {0f, 0f};
        float s = (len - 0.12f) / 0.88f / len;
        return new float[] {dx * s, dy * s};
    }

    private void send() {
        final int lx = Math.round(lsx * 32767f), ly = Math.round(-lsy * 32767f);  // +y = up
        final int rx = Math.round(rsx * 32767f), ry = Math.round(-rsy * 32767f);
        if (pressed == sentB && lx == sentLx && ly == sentLy && rx == sentRx && ry == sentRy) return;
        sentB = pressed; sentLx = lx; sentLy = ly; sentRx = rx; sentRy = ry;
        if (!sNativeOk) return;
        try {
            nativeTouchPad(pressed, lx, ly, rx, ry);
        } catch (UnsatisfiedLinkError t) {
            sNativeOk = false;
            android.util.Log.e("DSR/touch", "nativeTouchPad not found", t);
        }
    }

    private static native void nativeTouchPad(long buttons, int lx, int ly, int rx, int ry);

    @Override
    protected void onDraw(Canvas c) {
        // Left stick.
        fill.setColor(0x28FFFFFF);
        c.drawCircle(lcx, lcy, lR, fill);
        c.drawCircle(lcx, lcy, lR, stroke);
        fill.setColor(0x78FFFFFF);
        c.drawCircle(lcx + lsx * lR * 0.7f, lcy + lsy * lR * 0.7f, lR * 0.38f, fill);
        // Camera stick (only while in use).
        if (owner.indexOfValue(CAMERA) >= 0) {
            fill.setColor(0x20FFFFFF);
            c.drawCircle(camOx, camOy, camR, fill);
            c.drawCircle(camOx, camOy, camR, stroke);
            fill.setColor(0x78FFFFFF);
            c.drawCircle(camOx + rsx * camR * 0.8f, camOy + rsy * camR * 0.8f, camR * 0.35f, fill);
        }
        // Buttons.
        for (Ctl b : ctls) {
            boolean on = (pressed & b.bit) != 0;
            fill.setColor(on ? 0x78FFFFFF : 0x28FFFFFF);
            c.drawCircle(b.cx, b.cy, b.r, fill);
            c.drawCircle(b.cx, b.cy, b.r, stroke);
            c.drawText(b.label, b.cx, b.cy + text.getTextSize() * 0.35f, text);
        }
    }
}
