// Decodificador BC1-BC5 (UNORM) em software, para GPUs sem textureCompressionBC (Mali etc.).
// Saida: RGBA8 (BC1/2/3), R8 (BC4) ou RG8 (BC5), linhas compactas.
#pragma once
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>

namespace dsr::bc {

enum Kind { kNone = 0, kBC1, kBC2, kBC3, kBC4, kBC5 };

// NVN format -> tipo BC suportado por este decodificador. `opaque`: BC1 sem alfa (RGB).
inline Kind KindOf(int nvn, bool* opaque) {
    *opaque = false;
    switch (nvn) {
        case 65: case 69: *opaque = true; return kBC1;
        case 66: case 70: return kBC1;
        case 67: case 71: return kBC2;
        case 68: case 72: return kBC3;
        case 73: return kBC4;
        case 75: return kBC5;
        default: return kNone;
    }
}
inline int OutBytes(Kind k) { return k == kBC4 ? 1 : k == kBC5 ? 2 : 4; }
inline int BlockBytes(Kind k) { return (k == kBC1 || k == kBC4) ? 8 : 16; }

inline void Rgb565(uint16_t c, uint8_t o[3]) {
    const int r = (c >> 11) & 31, g = (c >> 5) & 63, b = c & 31;
    o[0] = uint8_t((r << 3) | (r >> 2));
    o[1] = uint8_t((g << 2) | (g >> 4));
    o[2] = uint8_t((b << 3) | (b >> 2));
}

// Bloco de cor BC1 (8 bytes) -> 16 pixels RGBA. four_color: BC2/BC3 sempre usam o modo de 4 cores.
inline void ColorBlock(const uint8_t* s, bool four_color, uint8_t px[16][4]) {
    const uint16_t c0 = uint16_t(s[0] | s[1] << 8), c1 = uint16_t(s[2] | s[3] << 8);
    uint8_t pal[4][4];
    Rgb565(c0, pal[0]);
    Rgb565(c1, pal[1]);
    pal[0][3] = pal[1][3] = pal[2][3] = pal[3][3] = 255;
    if (c0 > c1 || four_color) {
        for (int i = 0; i < 3; i++) {
            pal[2][i] = uint8_t((2 * pal[0][i] + pal[1][i]) / 3);
            pal[3][i] = uint8_t((pal[0][i] + 2 * pal[1][i]) / 3);
        }
    } else {
        for (int i = 0; i < 3; i++) {
            pal[2][i] = uint8_t((pal[0][i] + pal[1][i]) / 2);
            pal[3][i] = 0;
        }
        pal[3][3] = 0;
    }
    uint32_t idx = uint32_t(s[4]) | uint32_t(s[5]) << 8 | uint32_t(s[6]) << 16 | uint32_t(s[7]) << 24;
    for (int i = 0; i < 16; i++, idx >>= 2) memcpy(px[i], pal[idx & 3], 4);
}

// Bloco de valor unico (alfa BC3 / canal BC4/BC5), 8 bytes -> 16 valores.
inline void ValueBlock(const uint8_t* s, uint8_t out[16]) {
    uint8_t v[8];
    v[0] = s[0];
    v[1] = s[1];
    if (v[0] > v[1]) {
        for (int k = 1; k <= 6; k++) v[1 + k] = uint8_t(((7 - k) * v[0] + k * v[1]) / 7);
    } else {
        for (int k = 1; k <= 4; k++) v[1 + k] = uint8_t(((5 - k) * v[0] + k * v[1]) / 5);
        v[6] = 0;
        v[7] = 255;
    }
    uint64_t bits = 0;
    for (int i = 0; i < 6; i++) bits |= uint64_t(s[2 + i]) << (8 * i);
    for (int i = 0; i < 16; i++, bits >>= 3) out[i] = v[bits & 7];
}

inline void DecodeBlock(Kind k, bool opaque, const uint8_t* s, uint8_t px[16][4]) {
    switch (k) {
        case kBC1:
            ColorBlock(s, false, px);
            if (opaque)
                for (int i = 0; i < 16; i++) px[i][3] = 255;
            break;
        case kBC2: {
            ColorBlock(s + 8, true, px);
            for (int i = 0; i < 16; i++) {
                const int n = (s[i >> 1] >> ((i & 1) * 4)) & 15;
                px[i][3] = uint8_t(n * 17);
            }
            break;
        }
        case kBC3: {
            ColorBlock(s + 8, true, px);
            uint8_t a[16];
            ValueBlock(s, a);
            for (int i = 0; i < 16; i++) px[i][3] = a[i];
            break;
        }
        case kBC4: {
            uint8_t r[16];
            ValueBlock(s, r);
            for (int i = 0; i < 16; i++) { px[i][0] = r[i]; px[i][1] = 0; px[i][2] = 0; px[i][3] = 255; }
            break;
        }
        case kBC5: {
            uint8_t r[16], g[16];
            ValueBlock(s, r);
            ValueBlock(s + 8, g);
            for (int i = 0; i < 16; i++) { px[i][0] = r[i]; px[i][1] = g[i]; px[i][2] = 0; px[i][3] = 255; }
            break;
        }
        default: break;
    }
}

// Um nivel inteiro. src: blocos linearizados (row_bytes por linha de blocos, rows linhas, depth fatias).
// dst: w*h*depth*OutBytes(k) bytes.
inline void DecodeLevel(Kind k, bool opaque, const uint8_t* src, int row_bytes, int rows, int w, int h, int depth,
                        uint8_t* dst) {
    const int bpp = OutBytes(k), bb = BlockBytes(k);
    const int bw = (w + 3) / 4;
    for (int z = 0; z < depth; z++)
        for (int by = 0; by < rows; by++)
            for (int bx = 0; bx < bw; bx++) {
                uint8_t px[16][4];
                DecodeBlock(k, opaque, src + (size_t(z) * rows + by) * row_bytes + size_t(bx) * bb, px);
                for (int y = 0; y < 4 && by * 4 + y < h; y++)
                    for (int x = 0; x < 4 && bx * 4 + x < w; x++)
                        memcpy(dst + ((size_t(z) * h + by * 4 + y) * w + bx * 4 + x) * bpp, px[y * 4 + x], bpp);
            }
}

}  // namespace dsr::bc
