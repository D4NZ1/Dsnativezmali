# Notas do porte para GPU Mali (mali-19)

Objetivo: Dark Souls Remastered (loader nativo) em celular com GPU Mali, chegando a **30 fps** (33 ms por frame).

## O que já descobrimos

1. **Controles.** O jogo usa os controles na tela. O atalho L3+R3 só era lido no controle físico; desde o mali-18 também vale pelos botões L3/R3 da tela (log: `L3 + R3 (touch)`).
2. **Capturas automáticas enganam.** A captura que aparece sozinha vem do vídeo de abertura (8 s depois de abrir o vídeo): é a tela de carregamento, 164 draws, ~5 ms de GPU. Não serve para medir.
3. **Cena pesada medida** (~770 draws, 41 passes, ~22 fps): base = **46,17 ms por lista**.
   - sem blended: 45,16 (−1,0 ms)
   - sem pós p18/p19: 42,46 (−3,7 ms)
   - Só isso não chega nem perto de 33 ms.
4. **Captura da cena pesada** (62,3 ms, inflados pelos timestamps; escala real ≈ 0,74):
   - **p10 = 23,9 ms (38%)**: passe principal, 4 alvos de cor, 314 draws, corte de faces ligado.
   - sombra p2 = 4,3 ms; p25 + p27 = 5,4 ms; 31 passes pequenos de pós = 16,2 ms.
5. **Em p10**, três vertex shaders dominam: `45772890` (151 draws), `d4e93697` (98), `3e147b0e` (45, malhas com ossos, até ~4 mil índices). Cada draw leva paleta de 4 KB.
6. **Suspeita (não confirmada):** na Mali, as queries de oclusão parecem booleanas (draw único dá `1/1`). Se for isso, só 94 dos 314 draws de p10 produzem pixels e ~220 pagam vértice à toa.

## Conta para 30 fps

Hoje ~46 ms; meta 33 ms (−13 ms). Pós + blended dão ~−4,7 ms. Faltam ~8 a 9 ms, que só podem vir do p10 (~17 ms reais). Se cortar os draws invisíveis tirar metade do custo do p10, a meta fecha. Se o custo estiver nos poucos draws visíveis (fragmento), não fecha só com isso.

## O que o mali-19 faz

- `diag_cycle = 1` no `settings.txt`: o ciclo A/B começa **sozinho** depois de 30 s numa cena pesada (400+ draws). L3+R3 (tela ou controle) também inicia.
- 5 fases de 8 s (2 s de acomodação cada): base, sem os 3 vs da cena principal juntos, sem os passes pequenos de pós (alvo <= 640 px), sem o passe da sombra, base de novo.
- (v20: no mali-19 as fases eram um vs por vez; deu resultado instável, dentro do ruído de ~5 ms da base.)
- Resultado no log: `diag_cycle: SUMMARY ms per list` com o custo de cada grupo (vértice + fragmento dos draws pulados, em todos os passes onde aparecem).
- A imagem fica bagunçada de propósito por ~40 s. Não saia do app, senão a fase é cortada.

## Plano depois do mali-19

1. Ler o SUMMARY. Se os 3 grupos somam bem mais que ~9 ms: 30 fps é viável, seguir para cortar draws invisíveis (frustum/oclusão no CPU ou predicação com o resultado do frame anterior).
2. Se o custo for pequeno: olhar fragmento do p10 (4 alvos de cor na Mali, tamanho de tile) e a paleta de ossos de 4 KB por draw.
3. Reduzir o pós (p18/p19 e vizinhos) e o blended onde o ganho compensar.
4. Repetir a medição a cada passo, na mesma cena.
