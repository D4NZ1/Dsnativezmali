#pragma once
// Clock readout for the touch-boost investigation: logs the GPU and CPU frequencies where /sys lets the app read
// them (often it does not on recent Android: SELinux). The first call reports which files could be opened.
#ifdef __ANDROID__
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

#include <string>
#include <vector>

#include "common/log.h"

namespace dsr::clocks {

inline bool ReadLine(const std::string& path, std::string* out, int* err) {
    FILE* f = fopen(path.c_str(), "r");
    if (!f) {
        *err = errno;
        return false;
    }
    char buf[256] = {0};
    const bool ok = fgets(buf, sizeof(buf), f) != nullptr;
    if (!ok) *err = errno ? errno : EIO;
    fclose(f);
    if (!ok) return false;
    *out = buf;
    while (!out->empty() && (out->back() == '\n' || out->back() == '\r' || out->back() == ' ')) out->pop_back();
    return true;
}

inline std::vector<std::string> Candidates() {
    std::vector<std::string> v = {
        "/sys/kernel/ged/hal/current_freqency",  // MediaTek GED (the spelling is the driver's)
        "/sys/kernel/ged/hal/gpu_utilization",
        "/sys/kernel/gpu/gpu_clock",
        "/proc/gpufreqv2/gpufreq_status",
        "/proc/gpufreq/gpufreq_var_dump",
        "/sys/module/ged/parameters/gpu_cust_boost_freq",
        "/sys/kernel/debug/ged/hal/current_freqency",
    };
    // devfreq nodes whose name mentions the GPU
    if (DIR* d = opendir("/sys/class/devfreq")) {
        while (dirent* e = readdir(d)) {
            if (e->d_name[0] == '.') continue;
            const std::string n = e->d_name;
            if (n.find("mali") != std::string::npos || n.find("gpu") != std::string::npos) {
                v.push_back("/sys/class/devfreq/" + n + "/cur_freq");
                v.push_back("/sys/class/devfreq/" + n + "/max_freq");
            }
        }
        closedir(d);
    }
    for (int c : {0, 4, 6, 7}) v.push_back("/sys/devices/system/cpu/cpu" + std::to_string(c) + "/cpufreq/scaling_cur_freq");
    return v;
}

// Once: lists the small readable files of the directories where the GPU driver exposes its state (the first run showed
// /sys/kernel/gpu/gpu_clock is readable by the app), so max clock, governor and load files can be found.
inline void DumpDirs() {
    for (const char* dir : {"/sys/kernel/gpu", "/sys/class/misc/mali0/device", "/sys/kernel/ged/hal"}) {
        DIR* d = opendir(dir);
        if (!d) {
            LOGI("clocks", "dir %s: %s", dir, strerror(errno));
            continue;
        }
        std::string all;
        int n = 0;
        while (dirent* e = readdir(d)) {
            if (e->d_name[0] == '.' || !strcmp(e->d_name, "uevent") || n >= 40) continue;
            std::string val;
            int err = 0;
            const std::string p = std::string(dir) + "/" + e->d_name;
            if (ReadLine(p, &val, &err)) all += std::string(" [") + e->d_name + ": " + val.substr(0, 70) + "]";
            else all += std::string(" [") + e->d_name + ": (" + strerror(err) + ")]";
            n++;
        }
        closedir(d);
        LOGI("clocks", "dir %s:%s", dir, all.c_str());
    }
}

// Call every 10 s. Logs "clocks: name=value ..." for readable files; the first call also names the unreadable ones.
inline void Log() {
    static bool first = true;
    static std::vector<std::string> paths = Candidates();
    std::string line, blocked;
    for (const std::string& p : paths) {
        std::string val;
        int err = 0;
        if (ReadLine(p, &val, &err)) {
            std::string shortname = p;
            if (shortname.compare(0, 5, "/sys/") == 0) shortname = shortname.substr(5);
            line += " [" + shortname + ": " + val.substr(0, 60) + "]";
        } else if (first) {
            blocked += " " + p + "(" + strerror(err) + ")";
        }
    }
    if (first) {
        LOGI("clocks", "not readable:%s", blocked.empty() ? " none" : blocked.c_str());
        DumpDirs();
    }
    first = false;
    LOGI("clocks", "%s", line.empty() ? "no clock file is readable by the app" : line.c_str());
}

}  // namespace dsr::clocks
#else
namespace dsr::clocks {
inline void Log() {}
}  // namespace dsr::clocks
#endif
