# DSR Native — fork Mali (Galaxy A07 / Helio G99, Mali-G57 MC2)

Dark Souls Remastered (Switch) rodando nativo no Android via Vulkan (HLE do NVN). Alvo: **30 fps estáveis**.
Hoje: ~30 fps em áreas fechadas, **18–26 fps em áreas abertas** (média ~22).

## O que foi descoberto
- O gargalo é a **GPU** (ocupada ~9,9 s a cada 10 s). Não é CPU, nem calor (35 °C, "térmico: leve").
- **Não** eram o problema: texturas, anisotropia, descarte de mip (`texture_drop`), `trim_targets`, `tight_barriers`. Nenhum mexeu no FPS.
- Cada frame: ~1.100–1.300 draws, ~45–62 passes, ~98 barreiras de imagem. Base medida: **~40–46 ms por lista** (meta: ~33 ms).
- Custo medido pelo `diag_cycle` (corta um grupo por vez e mede a queda):

| Grupo cortado | Ganho por lista |
|---|---|
| Passes pequenos de pós-processamento (alvos ≤ 640 px, ~31 passes) | **−18 a −21 ms** |
| Desenhos da cena principal (3 vertex shaders) | −8 a −11 ms |
| Passe de sombra (2048², `shadow_size` 1024) | −2 a −8 ms (ruidoso) |

- Dentro dos passes pequenos (mali-22, 3 ciclos, ruidoso): **320x180 ≈ −10 ms**, 640x360 ≈ −5 ms, ≤160 px ≈ −3 ms.
- O pós-processamento é uma cadeia (cada passe lê o anterior), então o custo vem da **quantidade de passes**, não das barreiras.
- Piscada: só no menu do jogo. Suspeitas: texturas de substituição pretas, leitura de vértice fora do buffer, alvo 1920x1080 visto uma vez.

## O que já está no zip (mali-22)
- Decodificador BC ~2,3x mais rápido (saída idêntica).
- Opções no `settings.txt`: `anisotropy`, `texture_drop`, `trim_targets`, `tight_barriers`.
- `diag_cycle` por tamanho de alvo (640x360 / 320x180 / ≤160 px).
- Este zip ainda **não foi compilado**: se der erro no Actions, me mande a mensagem.

## O que pretendo fazer
1. **mali-23 (pronto, no zip)**: `diag_cycle` por hash do shader de fragmento nos passes 320x180/640x360, para achar quais são opcionais (bloom, profundidade de campo, etc.).
2. Opção `skip_post` no `settings.txt` para cortar ou fundir esses passes (ex.: menos iterações de desfoque).
3. Testar `render_scale` 0.7–0.75 junto, e `shadow_size` 512 se a sombra pesar.
4. Capturar o menu aberto (L3+R3) para achar a causa da piscada.
5. Meta: base ≤ 33 ms por lista = 30 fps estáveis em área aberta.

## settings.txt atual
`fps=30, async_pipelines=1, present_mode=fifo, render_scale=0.75, shadow_size=1024, skip_depth_prepass=1, texture_drop=2, trim_targets=1, tight_barriers=1, diag_cycle=1` (ponha `diag_cycle=0` para jogar).

## Como compilar
Suba `dsr-native-main/` num repositório GitHub e baixe o APK em Actions → Artifacts. Arquivos do jogo ficam em `Download/DSRNative/game/` (não suba).

## mali-24: resolução dinâmica (`dyn_res`, não compilado)
- Alvos 1280x720 são alocados em `render_scale` (teto); só o canto `[0,live]` é desenhado. Muda só no `Present` (limite de frame).
- Controlador: 1x/s compara GPU ms/frame com `dyn_target_ms` (31) e move `live_scale` em passos de 1/40, entre `dyn_min` (0,6) e `render_scale`.
- Settings novos: `dyn_res=0` (sem ganho medido; glitch de canto), `dyn_min=0.6`, `dyn_target_ms=31` (acrescentados ao settings.txt se faltarem). Sugestão: `render_scale=0.8`.
- Log: `dyn_res: GPU xx ms/frame -> scale ...`. Push constants: 4 -> 6 floats (fator das UVs normalizadas).
- Riscos a olhar: borda direita/inferior (bilinear lê fora do canto), passes que lerem alvo escalado de forma não prevista.

## mali-25: `skip_writeback` (experimento)
- Log do mali-24: dyn_res não reduziu a GPU (33–36 ms/frame em 0,65 e 0,60): o custo é fixo por passe (~40 passes, ~90 barreiras/frame).
- `skip_writeback`: 0 = tudo (padrão), 1 = só R32F (formato NVN 10, luminância da exposição automática), 2 = nenhum (imagem mais escura). Medir "GPU busy ... ms per list".

## mali-26: `adpf` (dicas de desempenho ao Android)
- Teste: parado 20–22 fps; com um dedo na tela 26 estáveis, ou seja, o clock sobe com o toque (touch boost).
- `adpf = 1` (padrão): `src/common/adpf.h` cria uma sessão APerformanceHint (API 33+, via dlsym) com a thread de gravação e a thread do Present e reporta o intervalo entre frames contra 33,3 ms. Abaixo de 30 fps o sistema sobe os clocks; em 30 relaxa (bom para o térmico).
- Log: `adpf: performance hints available/not available`, `hint session with N thread(s): ok`.

## mali-27: ADPF 2 (CPU+GPU)
- Log do mali-26: sessão ok, mas cena pesada seguiu a ~47 ms/frame com GPU 100% ocupada. Aparelho: Android 17.
- `FrameDone` agora reporta total, CPU (tempo de CPU da thread do Present) e GPU (timestamps das submissões) via `APerformanceHint_reportActualWorkDuration2`; se a GPU passa de 33,3 ms por ~1 s, chama `notifyWorkloadIncrease(gpu)`. Cai para o relatório simples se a API faltar.
- Log: `adpf: performance hints available; CPU+GPU durations (ADPF 2): yes ...` e `adpf: frame N: total.. cpu.. gpu.. report2 rc 0 notify rc 0`.

## mali-28: `diag_world` (diagnóstico do passe do mundo)
- Log do mali-27: ADPF 2 aceito (`report2 rc 0`, `notify rc 0`), mas a cena pesada seguiu em 39–44 ms por lista: o aparelho não liga o hint de GPU ao clock.
- `diag_world = 1`: como `diag_cycle`, mas os fragment shaders testados são os que desenham o mundo (alvo > 640 px, depth test ligado, algum canal de cor escrito). Começa sozinho após ~30 s numa cena pesada (≥ 400 draws/lista) ou com L3+R3.
- 8 fases de 8 s: base, os 6 shaders mais usados (um por fase, descartado), base de novo. Log: `diag_cycle: world-pass fragment shader XXXXXXXX ...` e `diag_cycle: SUMMARY no fs XXXXXXXX ... ms (-N)`. Imagem quebra de propósito. Não mexer a câmera durante o teste.

## mali-29: correção do `diag_world`
- No mali-28 o filtro exigia depth write e a máscara de RT0; o log mostrou "fewer shaders found" (nenhum shader coletado) e as 6 fases ficaram iguais (~52 ms por lista).
- Agora conta draws em alvo > 640 px com depth test ligado e qualquer canal de cor escrito (a máscara do passe do mundo vem como 0xffff0008: só o alfa de RT0).

## mali-30: log dos formatos dos alvos de cor (MRT)
- `diag_world` (mali-29) mostrou que nenhum shader do mundo domina: descartar cada um dos 6 mais usados rende 0–2 ms (um deles, `9bc1c5c1`, deu −4,1 ms numa rodada e −0,6 na outra).
- A/B de escala no mesmo ponto: 0.65 ≈ 53 ms/lista, 0.50 ≈ 42 ms. ATENÇÃO: `render_scale 0.50` colide com os alvos nativos 640x360 do jogo (o tamanho "escalado" é igual ao deles), a imagem encolhe para 320x180 e o número subestima o custo real. Use 0.55 ou mais.
- Novo log: `colour targets: [0: nvn .. vk .. WxH N bit, write mask ..] ... | total N bits per pixel`, uma vez por combinação de alvos.

## mali-36: `barrier_dst_fragment`
- mali-35: ligar o pré-passe (`skip_depth_prepass 0`) deu 41,6–41,8 ms por lista contra 41–42 sem ele: sem ganho. Voltar a `skip_depth_prepass = 1`.
- `barrier_dst_fragment = 1` (padrão 0, exige `tight_barriers = 1`): a barreira de layout para SHADER_READ_ONLY espera só o estágio de fragmento (antes: vértice + fragmento), para o tiler do passe seguinte poder começar cedo.
- Se aparecer imagem errada ou piscando, volte a 0. O log mostra `settings: diag_tiny_scissor ..., barrier_dst_fragment on/off`.

## mali-41: VS x FS (diagnóstico)
- O contador de texturas que quebram passe agora diz `stage VS` ou `stage FS`. Nos logs de 2026-11-13 só aparece FS (0 linhas VS). Detalhes em `MALI-41-VS-FS-DIAG.md` e no README 3.4k.

## mali-42: `diag_cycle` com 12 candidatas e `skip_targets`
- `kShaderPhases` 6 -> 12 e fases de 7 s (14 fases, ~100 s). Resultado (README 3.4l): nenhuma shader isolada passa de −1,5 ms; cortar uma shader não remove o passe.
- Novo setting `skip_targets = 320x180,160x90` (mali-42b: aceita formato, `320x180:5`). Rodada com `320x180`: −10,5 ms por lista (47 -> 36,5) mas imagem escura (README 3.4m). Por formato (3.4n): `:5` quase nada, `:17` imagem muito escura, `:37` ganho bom e imagem boa; falta base na cena de 1.487 draws. descarta os draws em alvos desses tamanhos, o passe nem começa. Teste do README 1b. Nunca `16x16` (exposição).
- Aviso: a captura de frame quebra passes em grupos de até 4 draws; a contagem de passes dela não vale (README 3.4k).
- Não compilado localmente; depende do GitHub Actions.

## mali-42c: bisseção de `640x360:37`
- Resultados (README 3.4o): base ~49,5 ms por lista; r2 `320x180:37,160x90:37` ~39,8; r3 + `640x360:37` ~31 mas **imagem preto e branco**. O custo é por passe (~1,4 ms por passe de 640x360).
- `skip_targets` aceita filtro por shader (`640x360:37@0fbd542c`); o log de `diag_cycle` lista até 64 shaders com formato (`f37`). Plano no README 1b. Não compilado localmente.
