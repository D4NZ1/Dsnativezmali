# Mali-41 — diagnóstico de leituras de textura por estágio

## O que mudou

O contador `textures that broke a render pass to become readable` agora identifica se a textura estava sendo preparada para leitura pelo `VS` (Vertex Shader) ou pelo `FS` (Fragment Shader).

Exemplo esperado no log:

`stage FS fmt 37 640x360 from layout 2: 120`

Isso permite separar transições causadas por amostragem no vertex shader das causadas pelo fragment shader.

## O que não mudou

- Nenhuma barreira Vulkan foi removida ou estreitada.
- `barrier_dst_fragment` permanece desligado (`0`) no settings de teste.
- Não há promessa de aumento de FPS nesta etapa: ela coleta evidência para escolher uma otimização segura.

## Teste

1. Instale a build com esta instrumentação.
2. Reproduza a mesma área/câmera usada no log anterior por pelo menos 60 segundos.
3. Envie o novo `dsr_*.txt`.
4. Compare as contagens `stage VS` e `stage FS`, junto com tempo GPU, passes e barreiras.

## Resultado (2026-11-13)

Nos logs `dsr_20261113_062909` e `dsr_20261113_063518` há 0 linhas `stage VS`: todas as leituras que quebram passe são por `FS`. Ver README-MALI.md 3.4k.
