package com.dsrnative.app;

import android.Manifest;
import android.app.NativeActivity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

/**
 * The native activity, full screen: the status and navigation bars are hidden while the game runs (immersive
 * mode: a swipe from the screen edge shows them for a moment), and the game may draw under a display cutout.
 */
public class GameActivity extends NativeActivity {
    // Access to Download/DSRNative (game files, saves, settings): 0 = waiting for the player's answer,
    // 1 = granted, 2 = refused (the game then falls back to the app's private folder). Read by native code.
    private static volatile int sStorage = 0;
    private boolean mAsked = false, mPausedSinceAsk = false;
    private TouchControls mTouch;

    public static int storageAccess() {
        return sStorage;
    }

    /**
     * Clock tests (settings boost_gamemode / boost_sustained), called by native code once settings.txt is read.
     * Results go to logcat (tag dsrboost), which the game mirrors into its log file.
     */
    public static void applyBoost(final android.app.Activity a, final int gameMode, final int sustained) {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (gameMode != 0) {
                    try {
                        if (Build.VERSION.SDK_INT >= 34) {
                            android.app.GameManager gm = a.getSystemService(android.app.GameManager.class);
                            if (gm != null) {
                                android.util.Log.i("dsrboost", "GameManager: current game mode " + gm.getGameMode());
                                gm.setGameState(new android.app.GameState(false, android.app.GameState.MODE_GAMEPLAY_UNINTERRUPTIBLE));
                                android.util.Log.i("dsrboost", "GameManager: game state set to gameplay (uninterrupted)");
                            } else {
                                android.util.Log.i("dsrboost", "GameManager: not available");
                            }
                        } else {
                            android.util.Log.i("dsrboost", "GameManager game state needs Android 14 (API 34)");
                        }
                    } catch (Throwable t) {
                        android.util.Log.w("dsrboost", "GameManager failed: " + t);
                    }
                }
                if (sustained != 0) {
                    try {
                        android.os.PowerManager pm = (android.os.PowerManager) a.getSystemService(Context.POWER_SERVICE);
                        boolean ok = pm != null && pm.isSustainedPerformanceModeSupported();
                        android.util.Log.i("dsrboost", "sustained performance mode supported: " + ok);
                        if (ok) a.getWindow().setSustainedPerformanceMode(true);
                    } catch (Throwable t) {
                        android.util.Log.w("dsrboost", "sustained performance failed: " + t);
                    }
                }
            }
        });
    }

    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStorageAccess() {
        if (hasStorageAccess()) {
            sStorage = 1;
            return;
        }
        mAsked = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Exception e2) {
                    sStorage = 2;
                }
            }
        } else {
            requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        sStorage = hasStorageAccess() ? 1 : 2;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mAsked) mPausedSinceAsk = true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestStorageAccess();
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
        lockRefreshRate();
        hideSystemBars();
    }

    /**
     * Pins the panel to a fixed 60 Hz mode. On panels with an adaptive rate (60/90 Hz LCDs) the system switches
     * the refresh rate while the game runs at 30 fps, which makes dark scenes (loading, menus) flicker.
     */
    private void lockRefreshRate() {
        try {
            android.view.Display d = getWindowManager().getDefaultDisplay();
            android.view.Display.Mode cur = d.getMode();
            int best = cur.getModeId();
            float bestDiff = Float.MAX_VALUE;
            for (android.view.Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() != cur.getPhysicalWidth() || m.getPhysicalHeight() != cur.getPhysicalHeight())
                    continue;
                float diff = Math.abs(m.getRefreshRate() - 60f);
                if (diff < bestDiff) {
                    bestDiff = diff;
                    best = m.getModeId();
                }
            }
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.preferredDisplayModeId = best;
            lp.preferredRefreshRate = 60f;
            getWindow().setAttributes(lp);
        } catch (Exception ignored) {
        }
    }

    // The game owns this window's surface (NativeActivity), so views inside it are never drawn: the on-screen
    // controls live in their own panel window on top of it.
    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (mTouch != null) return;
        try {
            mTouch = new TouchControls(this);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_PANEL,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    android.graphics.PixelFormat.TRANSLUCENT);
            lp.token = getWindow().getDecorView().getWindowToken();
            lp.gravity = android.view.Gravity.TOP | android.view.Gravity.START;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindowManager().addView(mTouch, lp);
        } catch (Exception e) {
            mTouch = null;
        }
    }

    @Override
    protected void onDestroy() {
        if (mTouch != null) {
            try {
                getWindowManager().removeView(mTouch);
            } catch (Exception ignored) {
            }
            mTouch = null;
        }
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Back from the "All files access" settings screen: the answer is final for this launch.
        if (mAsked && mPausedSinceAsk && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            sStorage = hasStorageAccess() ? 1 : 2;
        hideSystemBars();
        if (mTouch != null) mTouch.refresh();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }
}
