# dsr-native no Mali-G57: o que descobrimos

Notas de otimização do port nativo para Android (Galaxy A07, Helio G99, Mali-G57 MC2, Android 17).
Meta: **30 fps estáveis** com boa qualidade e, depois, **pouco calor e pouco consumo de bateria**.

> Tudo abaixo vem dos logs `dsr_*.txt` e capturas de frame (L3+R3) enviados nos testes mali-23 a mali-26.
> O `mali-30` (formatos dos alvos de cor) foi testado: ver 3.4c. Nenhuma versão foi compilada fora do GitHub Actions do projeto.

---

## 1. Resumo em 8 linhas

1. Áreas fechadas já fecham 30 fps. O problema são cenas abertas pesadas (20–26 fps).
2. A GPU fica ~100% ocupada nessas cenas e o jogo espera por ela.
3. Na cena pesada, **um único passe** (o mundo, com 4 alvos de cor) custa ~28 ms de ~60 ms numa captura. O pós-processamento custa ~14 ms em ~30 passes.
4. A resolução quase não muda o resultado nas cenas leves (0,65 → 0,60 não reduziu a GPU), mas a cena pesada responde a `render_scale` (0,65: 36–41 ms; 0,75: 38–48 ms por lista).
5. O clock do aparelho é um fator grande: **parado 20–22 fps, com um dedo na tela 26 estáveis** (efeito de *touch boost*).
6. Resolução dinâmica funciona, mas dá glitch de canto e não trouxe ganho: fica **desligada**.
7. Cortar o write-back de alvos pequenos não ajudou: fica em **0**.
8. Pistas abertas: dicas de desempenho ao Android (ADPF) e o custo do passe principal de 4 alvos.

---

## 2. Ponto de partida (README anterior)

- 30 fps em área fechada, 22–26 em área aberta.
- GPU ocupada ~9,9 s a cada 10 s, ou seja, gargalo de GPU.
- Por lista: pós-processamento ~18–21 ms, cena principal ~8–11 ms, sombra ~2–8 ms.
- As shaders de fragmento `527cbc3c` e `a4224b32` custam ~5 ms cada; cortá-las dá −4 a −5 ms por lista.
- Configuração de referência com boa imagem: `skip_shaders = 527cbc3c,a4224b32`, `shadow_size = 1024`, `render_scale = 0.75`.

---

## 3. Experimentos e resultados

### 3.1 Resolução dinâmica (`dyn_res`, mali-24)

**Como funciona:** os alvos 1280x720 são alocados em `render_scale` (teto) e só o canto `[0,live]` é desenhado. O controlador roda 1x/s, compara os ms de GPU por frame com `dyn_target_ms` (31) e move a escala em passos de 1/40 entre `dyn_min` e `render_scale`. Só troca no `Present`.

**Resultado:**
- Mecanicamente funcionou: 0,65 → 0,625 → 0,60 em 2 s.
- Não ajudou: GPU 33–36 ms por frame em 0,65 e ~35 ms em 0,60.
- Deixou **glitch**: a cena 3D aparece em ~73% da imagem, com moldura cinza e restos de frames antigos. Algum passe lê ou escreve o canto escalado sem o fator certo. Causa **não confirmada**.
- Conclusão: nas cenas testadas, resolução não era o gargalo. `dyn_res = 0` por padrão.

### 3.2 Write-back dos alvos pequenos (`skip_writeback`, mali-25)

O jogo lê de volta, por lista, alvos de até 64x64 (cerca de 5 por lista) para a exposição automática.
- `0` = copia todos (padrão e seguro). `1` = só R32F (formato NVN 10). `2` = nenhum (imagem mais escura).
- Com `1`, os write-backs caíram só de ~1.310 para ~1.250 por 10 s (quase todos já eram R32F) e a GPU ficou em 38–41 ms por lista: sem ganho. Manter em `0`.

### 3.3 Custo fixo por passe

- ~10.000 passes e ~24.000 barreiras de imagem a cada 10 s: cerca de **38–40 passes** e **~95 barreiras por frame**.
- ~680 draws por frame na cena pesada.
- Várias quebras de passe só para ler alvos pequenos (320x180, 640x360, 160x90) numa GPU de tiles.

### 3.4 Capturas da cena pesada (fogueira, mali-25/26)

| Parte | Captura 2 | Captura 3 |
|---|---|---|
| Total (inflado pela captura) | 64,3 ms | 58,9 ms |
| Opaco (cor, tela) | 35,8 ms (7 passes, 240 draws) | 33,3 ms (6 passes, 142 draws) |
| Passes pequenos (pós) | 14,2 ms (32 passes) | 14,5 ms (30 passes) |
| Blended | 3,6 ms | 2,2 ms |
| Cópias/clears | 10,3 ms (19 passes) | 8,4 ms (17 passes) |
| Sombra (`shadow_size 512`) | 0,5 ms | 0,6 ms |

- O passe do mundo (4 alvos de cor, até 234 draws, lendo a sombra 2048) leva **~28 ms** nas duas capturas.
- **Hipótese não verificada:** na Mali, MRT acima de ~128 bits por pixel reduz o tamanho do tile e piora muito o desempenho. Faltam os formatos dos 4 alvos para confirmar.
- Estatística do período: o jogo esperou o render 1.550–3.100 ms a cada 10 s e a GPU ficou ~100% ocupada.

### 3.4b `diag_world` e teste de escala (mali-29)

- Cena muito pesada (56 ms por lista na base). Descartar, um por vez, os 6 fragment shaders mais usados do mundo (25–55 draws cada) rendeu 0 a 2 ms cada. Um deles (`9bc1c5c1`) deu −4,1 ms numa rodada e −0,6 na outra: o ruído das medições é de ~1–3 ms. **Nenhum shader isolado domina; o custo está espalhado por centenas de draws.**
- A/B de escala no mesmo ponto: `render_scale 0.65` ≈ 53 ms por lista; `0.50` ≈ 42 ms. **Cuidado:** em 0.50 o tamanho escalado (640x360) coincide com alvos nativos do jogo, a imagem encolhe para um canto (320x180) e o número subestima o custo real. Evite 0.50 (e 0.25); use 0.55 ou mais.
- Ordem de grandeza: reduzir ~40% dos pixels tirou só ~20% do tempo, então boa parte do custo é fixa (draws e passes), e só resolução não fecha 33 ms nessa cena.

### 3.4c Formatos dos alvos de cor (mali-30)

- Combinações logadas: RGBA8 1280x720 (32 bpp, o resto sem uso), R32F 640x360 (32), RG16F 320x180 (32), 4x R16F 320x180 (64).
- **Máximo 64 bits por pixel, abaixo dos ~128.** Nenhuma combinação nova apareceu em ~55 s de cena pesada. Com `trim_targets` ligado, os alvos extras do mundo (máscara 0) saem do passe. **Hipótese do MRT refutada**: a Mali não encolhe tiles por causa disso.
- Cena pesada deste teste (`render_scale 0.65`, `shadow 512`): 1.173 draws, ~45 passes e ~105 barreiras por frame; GPU 49–55 ms por lista (~18–19 fps), ~98% ocupada. Mais pesada que a do 3.4 (~680 draws).
- Quebras de passe para ler texturas, por frame: 320x180 ~8, 640x360 ~6, 160x90 ~4, 1280x720 ~4 (~25 quebras em ~45 passes).
- A captura L3+R3 pegou uma tela leve (6 draws, 3,6 ms); não serve para a cena pesada.
- ADPF aceito (`rc 0`), sem efeito.

### 3.4d A/B `diag_tiny_scissor` (mali-30, mesma cena: 631 draws, 61 trocas de alvo por frame)

| | Sem diagnóstico | Scissor 1x1 nos opacos |
|---|---|---|
| GPU por lista (regime) | 39–42 ms (~41,5) | 37–39 ms (~38,5) |
| Captura, total (inflado) | 63,1 ms | 57,0 ms |
| Passe 10 (156 draws, alpha test) | 24,5 ms | 9,5 ms |
| Opaco (7 passes) | 31,2 ms | 16,4 ms |
| Blended (3 passes) | 4,2 ms | 8,5 ms |
| Pós (32 passes) | 16,9 ms | 19,6 ms |
| Cópias/clears (19 passes) | 10,2 ms | 11,6 ms |
| Sombra | 0,6 ms | 0,8 ms |

- Tirar todo o fragmento opaco derruba o passe 10 em ~15 ms, mas o tempo ao vivo cai só ~3 ms (~7%) e o total da captura ~6 ms: os outros passes "engordam" (+9 ms) porque antes corriam em paralelo com o fragmento do passe 10.
- Leitura (hipótese): a GPU tem duas filas quase equilibradas, fragmento (~41 ms) e vértice/tiler/passes (~38 ms). Cortar só uma fila rende pouco (~3 ms). Para 33 ms é preciso cortar as duas em ~20%.
- O passe 10 sem fragmento ainda custa 9,5 ms por 156 draws (~60 µs por draw; a sombra faz 66 draws em 0,8 ms): custo de vértice/tiler.
- Passes pequenos do pós (1 draw): 0,2–0,9 ms cada, ~17–20 ms no total; 19 passes de cópia/clear com ~10 ms.
- **Teste `render_scale 0.55` (mesma cena, sem diagnóstico):** GPU 40,5–42,4 ms por lista, igual aos ~41,5 ms de 0,65. Previsão da hipótese das duas filas era ~38 ms: **refutada**. Na captura, o passe 10 caiu de 24,5 para 20,3 ms, mas o total foi 65,1 ms (63,1 em 0,65): o tempo reaparece em outros passes.
- Novo palpite: o clock da GPU se ajusta à carga (DVFS). Menos pixels, clock menor, mesmo tempo por frame. Combina com o touch boost (3.5): 20–22 fps parado e 26 com dedo. Todos os A/B (resolução, scissor, ADPF) ficam pequenos por isso. Para testar: repetir 0,65 vs 0,55 com o dedo apoiado na tela o tempo todo (clock alto fixo); se a resolução passar a render, o DVFS escondia o ganho.

- Primeiros ~20 s da cena: 45–46 ms por lista; depois estabiliza em ~41 ms.

### 3.5 Clock e touch boost

Teste do usuário, mesma cena, câmera parada:
- Sem dedo: **20–22 fps**.
- Com um dedo apoiado na tela: **26 fps cravados**.

Interpretação: o toque faz o sistema subir o clock de CPU/GPU. A diferença também explica por que segurar o analógico direito parecia melhorar o FPS.

### 3.6 ADPF (dicas de desempenho ao Android)

- **mali-26:** sessão criada com 2 threads (`ok`), reportando o intervalo entre frames contra 33,3 ms. Cenas leves: 33,5 ms por frame (30 fps). Cena pesada: ~47 ms, GPU 100%. **Inconclusivo**: o teste usou `render_scale 0.75` (o anterior era 0,65) e o FPS parado não foi anotado.
- **mali-27:** reporta total, CPU e GPU via `APerformanceHint_reportActualWorkDuration2` e chama `notifyWorkloadIncrease(gpu)` quando a GPU passa de 33,3 ms por ~1 s. Resultado: o sistema **aceitou** (`report2 rc 0`, `notify rc 0`), mas a cena pesada seguiu em 39–44 ms por lista (22–25 fps) com a GPU a ~100%. Nesse aparelho o hint de GPU não vira clock; o touch boost é um caminho do sistema que o app não alcança.
- **Comparação `adpf 1` vs `0` (mali-26, `render_scale 0.65`):** ~39,8 vs ~41,9 ms por lista, ≈ 4%, dentro do ruído. O `adpf` fica ligado por ser inofensivo e útil ao térmico.

---

### 3.5b Clock fixo (dedo apoiado) x `render_scale`, mesma cena (631 draws)

| | Sem dedo | Dedo fixo |
|---|---|---|
| `render_scale 0.65` | ~41,5 ms por lista (24 fps) | 34,7–35,7 ms, oscila entre 26 e 30 fps |
| `render_scale 0.55` | ~41–42 ms (24 fps) | 32,3–33,7 ms, **30 fps cravados** (33,5 ms de média, 0 hitches) |

- **O clock é o fator dominante:** só o dedo na tela tira ~6 ms (41,5 para ~35). Com o clock fixo, a resolução passa a render (~2,4 ms de 0,65 para 0,55); sem ele, o ganho some (DVFS).
- Sem dedo, nenhuma variável testada (resolução, scissor, ADPF) moveu o tempo de forma útil.
- Atenção: com controle físico (Bluetooth) não há toque na tela, então o boost pode não acontecer e o FPS cair para ~24.
- Próximo: fazer o sistema subir o clock sem dedo (ver 6.0).

## 4. Referência de settings

| Chave | Padrão | Efeito |
|---|---|---|
| `render_scale` | 0.75 | Escala de renderização (teto quando `dyn_res=1`) |
| `shadow_size` | 1024 | Resolução da sombra |
| `skip_shaders` | lista | Corta shaders de fragmento por hash |
| `dyn_res` | 0 | Resolução dinâmica (glitch de canto, sem ganho) |
| `dyn_min` / `dyn_target_ms` | 0.6 / 31 | Piso e alvo do controlador |
| `skip_writeback` | 0 | 0 tudo, 1 só R32F, 2 nenhum |
| `adpf` | 1 | Dicas de desempenho ao Android |
| `diag_cycle` | 0 | Diagnóstico por shader dos passes pequenos de pós (L3+R3) |
| `boost_gamemode` | 0 | Teste de clock: avisa o GameManager do Android (estado de jogo, Android 14+) |
| `boost_sustained` | 0 | Teste de clock: modo de desempenho sustentado da janela (pode BAIXAR o clock) |
| `adpf_target_ms` | 33.3 | Alvo de tempo de frame da sessão ADPF (10–40); menor, ex. 25, faz o sistema achar que está atrasado |
| `adpf_graphics` | 0 | Teste de clock: sessão ADPF marcada como pipeline gráfico com a janela anexada (Android 16+) |
| `frame_rate_hint` | 0 | 0 = informa `fps` à janela, 1 = não informa, 2 = informa 60 |
| `clock_log` | 1 | Loga clocks de GPU/CPU a cada 10 s onde o app conseguir ler |
| `diag_tiny_scissor` | 0 | Diagnóstico: draws opacos do mundo com scissor 1x1 (separa custo de fragmento do resto) |
| `diag_world` | 0 | Diagnóstico por shader do passe do mundo (começa sozinho após ~30 s em cena pesada, ou L3+R3) |

Medidor na tela (toque nele para esconder): linha 1 = FPS, temperatura da bateria e status térmico; linha 2 (mali-32) = `GPU X% (Y ms)` (tempo ocupado da GPU e ms por frame), `CPU X% (pico Y% nome)` (processo em % de todos os núcleos e a thread mais carregada) e `RAM X GB (livre Y)` (residente do jogo e memória disponível no aparelho). Atualiza a cada ~1 s.

Captura de frame: **L3+R3** (com `diag_cycle = 0`).

---

## 5. Como ler o log

- `GPU busy X ms in the last 10 s (Y ms per list)`: Y acima de 33 ms = abaixo de 30 fps.
- `frame times: ... game waited for the render thread N ms`: N alto = jogo esperando a GPU.
- `last 10 s: N render passes, M image barriers`: custo fixo por passe.
- `capture N GPU ms per pass` e `SUMMARY`: custo de cada passe; compare as partes (a captura infla o total).
- `adpf: ...`: disponibilidade da API, `rc` dos reports (0 = aceito).

**Protocolo de teste que funcionou:** mesma posição e câmera, sem tocar na tela por 30 s, anotar o FPS; depois 10 s com um dedo apoiado; repetir com uma variável alterada por vez (mesmo `render_scale`).

---

## 6. Próximos passos

0. **Clock sem dedo (prioridade; implementado no mali-31, ver tabela de settings):** testar, um por vez, `GameManager` (modo/estado de jogo), `setSustainedPerformanceMode`, `setFrameRate`/`Surface.setFrameRate` e `setPreferPowerEfficiency(false)` do ADPF; medir por lista parado 30 s. O clock vai para o log (`clocks:`) se o `/sys` for legível; a linha `not readable:` mostra o que foi bloqueado. Protocolo: mesma cena, `render_scale 0.65`, sem dedo 30 s, um setting por vez (`boost_gamemode 1`; `boost_sustained 1`; `adpf_target_ms 25`; `adpf_graphics 1`; `frame_rate_hint 1` e `2`), e comparar os ms por lista com os ~41,5 ms sem dedo.

1. **Geometria e passes (resultado em 3.4d: não é fragmento).** A/B na mesma sessão com `diag_tiny_scissor` 0 e 1; depois um diagnóstico que pule os draws do passe p10 para confirmar o custo por draw. (Texto antigo:) **Fragmento ou vértice/draw?** Na cena pesada, medir com `diag_tiny_scissor = 1` (draws opacos do mundo com scissor 1x1: vértices ficam, fragmentos saem), parado por 30 s, contra a base de 49–55 ms por lista. Queda grande = custo de fragmento (overdraw, shaders, alpha test). Queda pequena = custo de vértices/tiler/draws; aí reduzir a contagem de draws. (O formato dos alvos já foi descartado, ver 3.4c.)
2. **Custo fixo por draw/passe:** ~680 draws, ~57 trocas de alvo e ~38 passes por frame. (`trim_targets`, `anisotropy 1` e `texture_drop 2` já estão em uso.)
3. **Custo fixo do pós:** fundir ou cortar passes pequenos (~30 passes, ~14 ms).
4. **Glitch do `dyn_res`:** só vale retomar se a cena pesada responder bem à resolução.

### Térmico e bateria (depois dos 30 fps)

- Medir antes de mexer: temperatura da bateria, status térmico, `getThermalHeadroom` e corrente em mA, a cada 10 s, em sessões de 15–20 min.
- CPU: cache em disco das texturas BC já decodificadas; rever espera ocupada e número de threads.
- Dicas ao sistema (ADPF, modo sustentado) para clocks estáveis em vez de picos.
- Adaptar ao calor: reduzir `render_scale` ou efeitos opcionais quando o headroom cair.
- Modo econômico opcional (limite de 20–25 fps ou sombra menor).
- Medidas até agora: bateria em 32–37 °C com status "leve" em sessões curtas; o aquecimento forte deve aparecer em sessões longas.
