#pragma once
// Android Dynamic Performance Framework (APerformanceHint, API 33+, resolved at run time so minSdk 29 still loads).
// The frame interval is reported against a 30 fps target: while the game runs below it the system raises CPU (and,
// on some devices, GPU) clocks, the same boost a touch on the screen gives; at or above it the system relaxes again.
#include <cstddef>
#include <cstdint>

#ifdef __ANDROID__
#include <dlfcn.h>
#include <unistd.h>

#include <algorithm>
#include <chrono>
#include <mutex>
#include <vector>

#include "common/log.h"

namespace dsr::adpf {

struct State {
    std::mutex m;
    void* (*get_manager)() = nullptr;
    void* (*create)(void*, const int32_t*, size_t, int64_t) = nullptr;
    void (*close)(void*) = nullptr;
    int (*report)(void*, int64_t) = nullptr;
    void* mgr = nullptr;
    void* session = nullptr;
    bool tried = false;
    std::vector<int32_t> tids;
    std::chrono::steady_clock::time_point last{};
    int64_t target_ns = 33333333;
};

inline State& S() {
    static State s;
    return s;
}

inline void Ensure(State& s) {
    if (s.tried) return;
    s.tried = true;
    void* h = dlopen("libandroid.so", RTLD_NOW);
    if (!h) return;
    s.get_manager = reinterpret_cast<void* (*)()>(dlsym(h, "APerformanceHint_getManager"));
    s.create = reinterpret_cast<void* (*)(void*, const int32_t*, size_t, int64_t)>(dlsym(h, "APerformanceHint_createSession"));
    s.close = reinterpret_cast<void (*)(void*)>(dlsym(h, "APerformanceHint_closeSession"));
    s.report = reinterpret_cast<int (*)(void*, int64_t)>(dlsym(h, "APerformanceHint_reportActualWorkDuration"));
    if (s.get_manager && s.create && s.close && s.report) s.mgr = s.get_manager();
    LOGI("adpf", "performance hints %s", s.mgr ? "available" : "not available on this device");
}

// Adds the calling thread to the hint session (once per thread).
inline void AddCurrentThread() {
    State& s = S();
    std::lock_guard<std::mutex> lk(s.m);
    Ensure(s);
    if (!s.mgr) return;
    const int32_t tid = int32_t(gettid());
    if (std::find(s.tids.begin(), s.tids.end(), tid) != s.tids.end()) return;
    s.tids.push_back(tid);
    if (s.session) s.close(s.session);
    s.session = s.create(s.mgr, s.tids.data(), s.tids.size(), s.target_ns);
    LOGI("adpf", "hint session with %zu thread(s): %s", s.tids.size(), s.session ? "ok" : "refused");
}

// Call once per presented frame.
inline void FrameDone() {
    State& s = S();
    std::lock_guard<std::mutex> lk(s.m);
    if (!s.session) return;
    const auto now = std::chrono::steady_clock::now();
    if (s.last.time_since_epoch().count() != 0) {
        int64_t ns = std::chrono::duration_cast<std::chrono::nanoseconds>(now - s.last).count();
        ns = std::clamp<int64_t>(ns, 1000000, 500000000);
        s.report(s.session, ns);
    }
    s.last = now;
}

}  // namespace dsr::adpf
#else
namespace dsr::adpf {
inline void AddCurrentThread() {}
inline void FrameDone() {}
}  // namespace dsr::adpf
#endif
